#!/usr/bin/env python
# -*- coding: cp936 -*- 
import tkFont
#from Tkinter import *  

from subprocess import call
from tkMessageBox import  askokcancel
from os.path import exists
from ConfigParser import ConfigParser
import sys
from subprocess import Popen, PIPE
from re import search,findall
from os import getpid,kill
from pexpect import spawn,EOF
from multiprocessing import Process

from Tkinter import *
import threading
import Queue
import ttk
from tkMessageBox import showinfo

class _Tk(object):
    """
    Wrapper for underlying attribute tk of class Tk.
    """

    def __init__(self, tk, mtDebug = 0, mtCheckPeriod = 10):
        self._tk = tk

        # Create the incoming event queue.
        self._eventQueue = Queue.Queue(1)

        # Identify the thread from which this object is being created so we can
        # tell later whether an event is coming from another thread.
        self._creationThread = threading.currentThread()

        # Store remaining values.
        self._debug = mtDebug
        self._checkPeriod = mtCheckPeriod

    def __getattr__(self, name):
        # Divert attribute accesses to a wrapper around the underlying tk
        # object.
        return _TkAttr(self, getattr(self._tk, name))

class _TkAttr(object):
    """
    Thread-safe callable attribute wrapper.
    """

    def __init__(self, tk, attr):
        self._tk = tk
        self._attr = attr

    def __call__(self, *args, **kwargs):
        """
        Thread-safe method invocation.
        Diverts out-of-thread calls through the event queue.
        Forwards all other method calls to the underlying tk object directly.
        """

        # Check if we're in the creation thread.
        if threading.currentThread() == self._tk._creationThread:
            # We're in the creation thread; just call the event directly.
            if self._tk._debug >= 8 or \
               self._tk._debug >= 3 and self._attr.__name__ == 'call' and \
               len(args) >= 1 and args[0] == 'after':
                print 'Calling event directly:', \
                    self._attr.__name__, args, kwargs
            return self._attr(*args, **kwargs)
        else:
            # We're in a different thread than the creation thread; enqueue
            # the event, and then wait for the response.
            responseQueue = Queue.Queue(1)
            if self._tk._debug >= 1:
                print 'Marshalling event:', self._attr.__name__, args, kwargs
            self._tk._eventQueue.put((self._attr, args, kwargs, responseQueue))
            isException, response = responseQueue.get()

            # Handle the response, whether it's a normal return value or
            # an exception.
            if isException:
                exType, exValue, exTb = response
                raise exType, exValue, exTb
            else:
                return response

# Define a hook for class Tk's __init__ method.
def _Tk__init__(self, *args, **kwargs):
    # We support some new keyword arguments that the original __init__ method
    # doesn't expect, so separate those out before doing anything else.
    new_kwnames = ('mtCheckPeriod', 'mtDebug')
    new_kwargs = {}
    for name, value in kwargs.items():
        if name in new_kwnames:
            new_kwargs[name] = value
            del kwargs[name]

    # Call the original __init__ method, creating the internal tk member.
    self.__original__init__mtTkinter(*args, **kwargs)

    # Replace the internal tk member with a wrapper that handles calls from
    # other threads.
    self.tk = _Tk(self.tk, **new_kwargs)

    # Set up the first event to check for out-of-thread events.
    self.after_idle(_CheckEvents, self)

# Replace Tk's original __init__ with the hook.
Tk.__original__init__mtTkinter = Tk.__init__
Tk.__init__ = _Tk__init__

def _CheckEvents(tk):
    "Event checker event."

    used = False
    try:
        # Process all enqueued events, then exit.
        while True:
            try:
                # Get an event request from the queue.
                method, args, kwargs, responseQueue = \
                    tk.tk._eventQueue.get_nowait()
            except:
                # No more events to process.
                break
            else:
                # Call the event with the given arguments, and then return
                # the result back to the caller via the response queue.
                used = True
                if tk.tk._debug >= 2:
                    print 'Calling event from main thread:', \
                        method.__name__, args, kwargs
                try:
                    responseQueue.put((False, method(*args, **kwargs)))
                except SystemExit, ex:
                    raise SystemExit, ex
                except Exception, ex:
                    # Calling the event caused an exception; return the
                    # exception back to the caller so that it can be raised
                    # in the caller's thread.
                    from sys import exc_info
                    exType, exValue, exTb = exc_info()
                    responseQueue.put((True, (exType, exValue, exTb)))
    finally:
        # Schedule to check again. If we just processed an event, check
        # immediately; if we didn't, check later.
        if used:
            tk.after_idle(_CheckEvents, tk)
        else:
            tk.after(tk.tk._checkPeriod, _CheckEvents, tk)


path_info,error = Popen('ls /bin/http_gui -la',shell=True,stdout=PIPE).communicate()
if search('-> (.+)http_gui_.+.py',path_info) is not None:
    INITXT = '%shttp_gui.ini' % search('-> (.+)http_gui_.+.py',path_info).group(1)
else:
   
    INITXT = 'http_gui.ini'

p1 = r'\d+\.\d+\.\d+\.\d+'
title_host = ''
hostip_info,error = Popen('ip addr',shell=True,stdout=PIPE).communicate()
host_list = findall(p1,hostip_info)
for i in host_list:
    if not i.startswith('127') and not i.startswith('169') and not i.endswith('255'):
        title_host = i
        break
if title_host:
    title_host = 'from %s' % title_host

s_script_name = 'http_test'
s_vs_ip = '10.71.8.6'
s_vs_port = '80'
s_req_num = '1'
s_session_num = '1'
s_interval = '1.0'
s_start_ip = '1.1.1.1'
s_end_ip = '1.1.1.3'
s_post_user_pass = 'admin|pass'
s_post_url = 'authentication.php'
s_get_url = 'index.php'

s_ca_name = 'ca_138.pem'
s_client_cert = 'legal_138_cert.pem'
s_client_key = 'legal_138_key.pem'
s_re_pattern = '(rs|RS)\d+'
s_cookie_key = 'CookieKey^0'
s_cookie_value = 'CookieValue^3'
s_query_key = 'QueryName^1'
s_query_value = 'QueryValue^2'
s_header_key = 'HeaderName^2'
s_header_value = 'HeaderValue^2'
s_cache_ip = 'ADC_IP&VDOM'
s_cache_port = 'port2:vlan777'
s_sniffer_key =  'tcp and host 1.1.1.1'
s_multi_server = '1.1.1.1,2.2.2.2,www.baidu.com'
s_custom_cache_header = 'random_cache_id'

s_user_name = 'ldapuser1'
s_password = 'fortinet'
s_user_prefix = 'user'
s_pass_prefix = 'pass'
s_user_num = '2'
s_rs_ip_header = 'ip'
s_xss_str = 'x=<script>alert(1);<script>'
s_sql_str = 'x=1--'

max_line_num = 5000
output_text_height = 25
output_text_width = 152
cmd_text_width = 154
tab_width = 800
tab_height = 140
run_width = 13
run_height = 8
run_font_size = 12

if exists(INITXT):
    config = ConfigParser()
    config.readfp(open(INITXT))
    if config.has_option('GUI','max_line_num'):
        max_line_num = float(config.get('GUI','max_line_num'))  
      
    if config.has_option('GUI','OUTPUT_TEXT_HEIGHT'):
        output_text_height = int(config.get('GUI','OUTPUT_TEXT_HEIGHT'))
    if config.has_option('GUI','output_text_width'):
        output_text_width = int(config.get('GUI','output_text_width'))
    if config.has_option('GUI','cmd_text_width'):
        cmd_text_width = int(config.get('GUI','cmd_text_width'))
    if config.has_option('GUI','tab_width'):
        tab_width = int(config.get('GUI','tab_width'))
    if config.has_option('GUI','tab_height'):
        tab_height = config.get('GUI','tab_height')    
    if config.has_option('GUI','run_width'):
        run_width = config.get('GUI','run_width')   
    if config.has_option('GUI','run_height'):
        run_height = config.get('GUI','run_height')  
    if config.has_option('GUI','run_font_size'):
        run_font_size = config.get('GUI','run_font_size')          
    if config.has_option('Setting','vs'):
        s_vs_ip = config.get('Setting','vs')
    if config.has_option('Setting','vs_port'):
        s_vs_port = config.get('Setting','vs_port')
    if config.has_option('Setting','start_ip'):
        s_start_ip = config.get('Setting','start_ip')
    if config.has_option('Setting','end_ip'):
        s_end_ip = config.get('Setting','end_ip')
    if config.has_option('Setting','post_user_pass'):
        s_post_user_pass = config.get('Setting','post_user_pass')
    if config.has_option('Setting','post_url'):
        s_post_url = config.get('Setting','post_url')
    if config.has_option('Setting','get_url'):
        s_get_url = config.get('Setting','get_url')
    if config.has_option('Setting','ca_name'):
        s_ca_name = config.get('Setting','ca_name')
    if config.has_option('Setting','client_cert'):
        s_client_cert = config.get('Setting','client_cert')
    if config.has_option('Setting','client_key'):
        s_client_key = config.get('Setting','client_key')
    if config.has_option('Setting','re_pattern'):
        s_re_pattern = config.get('Setting','re_pattern')   
    if config.has_option('Setting','cookie_key'):
        s_cookie_key = config.get('Setting','cookie_key')
    if config.has_option('Setting','cookie_value'):
        s_cookie_value = config.get('Setting','cookie_value')
    if config.has_option('Setting','query_key'):
        s_query_key = config.get('Setting','query_key')
    if config.has_option('Setting','query_value'):
        s_query_value = config.get('Setting','query_value')
    if config.has_option('Setting','header_key'):
        s_header_key = config.get('Setting','header_key')   
    if config.has_option('Setting','header_value'):
        s_header_value = config.get('Setting','header_value')
    if config.has_option('Setting','cache_ip'):
        s_cache_ip = config.get('Setting','cache_ip')
    if config.has_option('Setting','cache_port'):
        s_cache_port =  config.get('Setting','cache_port')
    if config.has_option('Setting','sniffer_key'):
        s_sniffer_key = config.get('Setting','sniffer_key')
    if config.has_option('Setting','custom_cache_header'):
        s_custom_cache_header = config.get('Setting','custom_cache_header')
    if config.has_option('Setting','user_name'):
        s_user_name = config.get('Setting','user_name')
    if config.has_option('Setting','password'):
        s_password = config.get('Setting','password')
    if config.has_option('Setting','user_prefix'):
        s_user_prefix = config.get('Setting','user_prefix')
    if config.has_option('Setting','pass_prefix'):
        s_pass_prefix = config.get('Setting','pass_prefix')   
    if config.has_option('Setting','user_num'):
        s_user_num = config.get('Setting','user_num')  
    if config.has_option('Setting','rs_ip_header'):
        s_rs_ip_header = config.get('Setting','rs_ip_header')
 
    if config.has_option('Setting','update_user_pass'):
        s_update_user = config.get('Setting','update_user_pass')  
    if config.has_option('Setting','update_server_path'):
        s_update_server_path = config.get('Setting','update_server_path')
    if config.has_option('Setting','sql_injection'):
        s_sql_str = config.get('Setting','sql_injection')
    if config.has_option('Setting','xss_injection'):
        s_xss_str = config.get('Setting','xss_injection')    
  
g_concurrent_bool = True
g_onebyone_bool = False
g_middle_bool = False
g_srcport_bool = False
g_reuse_bool = False
g_l4_weight_bool = False
g_l7_weight_bool = False
g_l4_warm_bool = False
g_l7_warm_bool = False
g_timeout_bool = False
#g_no_print_time_bool = False
g_debug_all_bool = False
g_fullnat_bool = False
g_content_rewrite_bool =False
g_l2_src_dst_bool = False
g_l2_dst_bool = False
g_l2_src_bool = False
g_l2_session_bool = False

g_disableip_bool = True
g_randomip_bool = False
g_startip_bool = False
g_endip_bool = False
g_overip_bool = False
g_eth_bool = False
g_dst_ip_port_bool = False

g_get_bool = True
g_post_bool = False
g_put_bool = False
g_delete_bool= False
g_trace_bool= False
g_option_bool= False
g_head_bool= False
g_connect_bool= False
g_custom_method_bool = False

g_url_weight_bool = False


g_hash_cookie = False
g_hash_query = False
g_hash_header = False
g_real_cookie = False
g_fix_cookie = False

g_ssl_disable = True
g_ssl_enable = False
g_ssl_verify = False
g_ssl_domain = False
g_ssl_client = False
g_pyopenssl = False
g_sslv3_bool = False
g_tlsv1_bool = True
g_tlsv11_bool = False
g_tlsv12_bool = False
g_sslv2_bool = False
g_ticket_bool = False
g_sni_bool = False
g_ssl_reuse_bool = False
g_encryp_bool = False
g_random_cache_bool =False
g_load_file_bool =False
g_custom_header_bool =False
g_random_expire_bool =False
g_cache_bool = False
g_cache_debug_bool = False

g_max_url_len_bool,g_legal_host_bool,g_http_version_bool,g_max_cookie_num_bool,g_max_header_num_bool,g_max_header_name_bool = False,False,False,False,False,False,
g_max_header_value_bool,g_max_url_name_bool,g_max_url_value_bool,g_max_request_header_bool,g_max_request_body_bool = False,False,False,False,False

g_sql_referer_bool = False
g_sql_cookie_bool = False
g_sql_url_bool = False
g_sql_body_bool = False
g_sql_bool = False

g_xss_referer_bool = False
g_xss_cookie_bool = False
g_xss_url_bool = False
g_xss_body_bool = False
g_xss_bool = False


g_rs_ip_header_bool = False
g_cusum_re_bool = False
g_no_print_all_bool = False
g_client_timeout_bool = False
g_request_timeout_bool = False
g_speed_bool = False
g_discontinus_bool =  False
g_multi_server_bool = False
g_no_auth_bool, g_single_user_bool, g_multi_user_bool,g_brower_bool = True,False,False,False
g_update_bool = False

g_header_bool = False



def header_cmd():
    cmd = ''
    if g_header_bool:
        header_str = header_text.get(0.0, END)
   
        if '\n' in header_str:
            header_list = header_str.split('\n')
            for i in header_list:
                if i.strip():
                    if ':' in i:
                        cmd += '-H "%s" ' % i
                    else:
                        output_text.insert("end",'Header syntax error, ":" is necessary')
        else:
            if header_str.strip():
                if ':' in i:
                    cmd += '-H "%s" ' % i
                else:
                    output_text.insert("end", 'Header syntax error, ":" is necessary')             
    return cmd

def cache_cmd():
    cmd = ''
    if g_random_cache_bool:
        cmd += '--cache '
        if g_custom_header_bool:
            cmd += '--cache-id %s ' % cache_custom_head_entry.get()
        if g_random_expire_bool:
            cmd += '--cache-expire %s ' % cache_expire_entry.get()
        if g_load_file_bool:
            cmd += '--no-cache-load '
    if g_cache_bool:
        cmd += '-T "%s|%s|%s" ' % (adcip_entry.get(), adcport_entry.get(), sniffer_entry.get())

    if g_cache_bool or g_random_cache_bool:
        if g_cache_debug_bool:
            cmd += '--cache-debug '
    return cmd
   

def advance_cmd():
    cmd = ''
    if g_rs_ip_header_bool:
        cmd += ' --rs-ip-header %s ' % rs_ip_header_entry_v.get()
    if g_multi_server_bool:
        cmd += '-M %s ' % vs_ip_value
    if g_cusum_re_bool:
        cmd += '-R "%s" ' % re_value_entry.get()
    if g_no_print_all_bool:
        cmd += '-N '
    if g_speed_bool:
        cmd += '--speed-up %s ' % speed_user_entry.get()
    return cmd
def auth_cmd():
    cmd = ''
    if not g_no_auth_bool:
        if g_single_user_bool:
            if g_brower_bool:
                cmd += '-u %s:%s:b ' % (user_name_v.get(),password_v.get())
            else:
                cmd += '-u %s:%s:s ' % (user_name_v.get(),password_v.get())
        if g_multi_user_bool:
            cmd += '-u %s:%s:%s ' % (user_prefix_v.get(),pass_prefix_v.get(),user_num_v.get())
    return cmd
def http_constraint_cmd():
    cmd = ''
    cmd_list = []
    if g_max_url_len_bool:
        cmd_list.append('max_url_len=%s' % max_url_entry_url_v.get())
    if g_legal_host_bool:
        cmd_list.append('hostname=%s' % legal_host_entry_url_v.get())
    if g_http_version_bool:
        cmd_list.append('ver=%s' % http_version_entry_url_v.get())
    if g_max_cookie_num_bool:
        cmd_list.append('max_cookie_num=%s' % max_cookie_num_entry_url_v.get())
    if g_max_header_num_bool:
        cmd_list.append('max_head_num=%s' % max_header_num_entry_url_v.get())
        
    if g_max_header_name_bool:
        cmd_list.append('max_head_name_len=%s' % max_header_name_entry_url_v.get())
    if g_max_header_value_bool:
        cmd_list.append('max_head_value_len=%s' % max_header_value_entry_url_v.get())
    if g_max_url_name_bool:
        cmd_list.append('max_url_name_len=%s' % max_url_name_entry_url_v.get())
    if g_max_url_value_bool:
        cmd_list.append('max_url_value_len=%s' % max_url_value_entry_url_v.get())
    if g_max_request_header_bool:
        cmd_list.append('max_req_head=%s' % max_request_header_entry_url_v.get())
    if g_max_request_body_bool:
        cmd_list.append('max_req_body=%s' % max_request_body_entry_url_v.get())
    if g_client_timeout_bool:
        cmd_list.append('client_time=%s' % client_timeout_entry_v.get())
    if g_request_timeout_bool:
        cmd_list.append('request_time=%s' % request_timeout_entry_v.get())
    str_cmd = '|'.join(cmd_list)
    if str_cmd:
        cmd += '--protocol "%s" ' % str_cmd
    return cmd
def sql_xss_cmd():
    cmd = ''
    str = ''
    if g_sql_bool:
        if g_sql_cookie_bool:
            str += 'c'
        if g_sql_referer_bool:
            str += 'r'
        if g_sql_url_bool:
            str += 'u'
        if g_sql_body_bool:
            str += 'b'
        if str:
            cmd += '--injection "sql|%s|%s"' % (str,sql_injection_entry_v.get())
    if g_xss_bool:
        if g_xss_cookie_bool:
            str += 'c'
        if g_xss_referer_bool:
            str += 'r'
        if g_xss_url_bool:
            str += 'u'
        if g_xss_body_bool:
            str += 'b'        
        if str:
            cmd += '--injection "xss|%s|%s"' % (str,xss_injection_entry_v.get())
    return cmd
def cert_cmd():
    cmd = ''
    version_list = []
    result_cipher = ''
    if g_ssl_enable or g_pyopenssl:
        cmd += '-S '
        if g_ssl_verify:
            cmd += '-f %s ' % ca_entry.get()
            if g_ssl_domain:
                cmd += '-v '
        if g_ssl_client:
            if g_multi_cert:
                cmd += '-F %s:%s:%s ' % (client_cert_entry.get(), client_key_entry.get(),multi_cert_v.get())
            else:
                cmd += '-F %s:%s ' % (client_cert_entry.get(), client_key_entry.get())

    if g_pyopenssl:
     
        if g_sslv2_bool:
            version_list.append('ssl_v2')
        if g_sslv3_bool:
            version_list.append('ssl_v3')
        if g_tlsv1_bool:
            version_list.append('tls_v1')
        if g_tlsv11_bool:
            version_list.append('tls_v1_1')
        if g_tlsv12_bool:
            version_list.append('tls_v1_2')
        if not g_sslv2_bool and not g_sslv3_bool and not g_tlsv1_bool and not g_tlsv11_bool and not g_tlsv12_bool:
            version_list.append('tls_v1')
        if len(version_list) == 1:
            version_value = version_list[0]
        else:
            version_value = ','.join(version_list)
        result_version = 'version=%s' % version_value
        if g_ticket_bool:
            ticket_value = 'ticket=1'
        else:
            ticket_value = 'ticket=0'
        if g_ssl_reuse_bool:
            ssl_reuse_value = 'reuse=1'
        else:
            ssl_reuse_value = 'reuse=0'
        if g_sni_bool:
            sni_value = 'sni=1'
        else:
            sni_value = 'sni=0'
        if g_encryp_bool:
            result_cipher_list = []
            
            begin_cipher= encryp_text.get(1.0, END).strip()
            if '\n' in begin_cipher:
                begin_cipher_list = begin_cipher.split('\n')
            else:
                begin_cipher_list = [begin_cipher]
            for i in begin_cipher_list:
                if i.strip():
                    result_cipher_list.append(i.strip())
            if result_cipher_list:
                result_cipher = ','.join(result_cipher_list)
         
    
        if g_encryp_bool:
            if result_cipher:
                add_result_cipher = 'encryption=%s' % result_cipher
                
                cmd += '--pyopenssl "%s|%s|%s|%s|%s" '% (result_version,sni_value,ssl_reuse_value,ticket_value,add_result_cipher)
            else:
                cmd += '--pyopenssl "%s|%s|%s|%s" ' % (result_version,sni_value,ssl_reuse_value,ticket_value)

        else:
            cmd += '--pyopenssl "%s|%s|%s|%s" ' % (result_version,sni_value,ssl_reuse_value,ticket_value)


    return cmd
def hash_persistence():
    cmd = ''
    if g_hash_cookie:
        cmd += '-C %s=%s ' % (hashcookie_key_entry.get(), hashcookie_value_entry.get())
        if g_fix_cookie:
            if cookie_fix_value == 'fix-prefix':
                cmd = cmd.strip() + ':1 '
            elif cookie_fix_value == 'fix-suffix':
                cmd = cmd.strip() + ':2 '
    if g_hash_query:
        cmd += '-q %s=%s ' % (hashquery_key_entry.get(), hashquery_value_entry.get())
    if g_hash_header:
        cmd += '-a %s=%s ' % (hashheader_key_entry.get(), hashheader_value_entry.get())
    if g_real_cookie:
        cmd += '-c '
        
    return cmd

def method_cmd():
    cmd = ''
    if g_get_bool:
        cmd += '--method "GET" '
        if get_url_entry.get().strip():
            cmd += '-s %s ' % get_url_entry.get().strip()

    if g_post_bool:
        cmd += '--method "POST:%s:%s" ' % (post_user_pass_entry.get(), post_url_entry.get())
    if g_put_bool:
        cmd += '--method "PUT:%s" ' % put_url_entry.get()
    if g_delete_bool:
        cmd += '--method "DELETE:%s" ' % delete_url_entry.get()
    if g_trace_bool:
        cmd += '--method "TRACE:%s" ' % trace_url_entry.get()
    if g_head_bool:
        cmd += '--method "HEAD:%s" ' % head_url_entry.get()
    if g_option_bool:
        cmd += '--method "OPTIONS:%s" ' % option_url_entry.get()
    if g_connect_bool:
        cmd += '--method "CONNECT:%s" ' % connect_url_entry.get()
    if g_custom_method_bool:
        cmd += '--method "CUSTOM:%s" ' % custom_url_entry.get()

        
    if zip_value == 'gzip_only':
        cmd += '-z g '
    elif zip_value == 'deflate_only':
        cmd += '-z d '
    elif zip_value == 'unsupport':
        cmd += '-z n '
    elif zip_value == 'identity':
        cmd += '-z i '
    elif zip_value == 'mix':
        cmd += '-z m '
    if g_url_weight_bool:
        cmd += '-U '
        
    
    return cmd

def ip_cmd():
    cmd = ''
    if g_randomip_bool:
        cmd += '-i %s ' % random_num_entry.get()
    if g_discontinus_bool:
        cmd += '-i %s ' % discontinuous_ip_entry.get()
    if g_startip_bool:
        cmd += '-i %s ' % range_ip_start_entry.get()
        if g_endip_bool:
            cmd = cmd.strip() + '-%s ' % range_ip_end_entry.get()
    
    if g_eth_bool:
        if ethname_list_v.get():
            cmd += '-e %s ' % ethname_list_v.get()
    if g_overip_bool:
        cmd += '-D %s ' % ip_interval_entry.get()
    if g_dst_ip_port_bool:
        cmd += '--random-dst-port '
    return cmd
        

def frequent_cmd():
    cmd = ''
    if g_l4_warm_bool:
        cmd += '-l '
    if g_l7_warm_bool:
        cmd += '-L '    
    if g_l4_weight_bool:
        cmd += '-w '
    if g_l7_weight_bool:
        cmd += '-W '
    if g_timeout_bool:
        cmd += '-t %s ' % timeout_value_entry.get()
#    if g_no_print_time_bool:
#        cmd += '-n '
    if g_debug_all_bool:
        cmd += '--debug '
    if g_fullnat_bool:
        cmd += '--fullnat '
    if g_content_rewrite_bool:
        cmd += '--rewrite '
    if g_l2_src_dst_bool: 
        cmd += '--l2-src-dst '    
    if g_l2_dst_bool: 
        cmd += '--l2-dst ' 
    if g_l2_src_bool: 
        cmd += '--l2-src ' 
    if g_l2_session_bool:
        cmd += '--l2-ses '
    return cmd
    
def session_cmd():

    cmd = ''
    if g_onebyone_bool:
  
        cmd += '-o ' + interval_onebyone_entry.get() + ' '
    if g_middle_bool:
    
        cmd += '-m ' + interval_middle_entry.get() + ' '
    
        
    if g_srcport_bool:
        cmd += '-p ' + sport_entry.get() + ' '
        if g_reuse_bool:
            cmd += '-r ' 
            
    return cmd
            
def result_cmd():
    global vs_ip_value,g_multi_server_bool
    vs_ip_value = server_entry.get()
    if ',' in vs_ip_value or '-' in vs_ip_value:
        g_multi_server_bool = True
        if ',' in vs_ip_value:
            vs_ip = vs_ip_value.split(',')[0]
        elif '-' in vs_ip_value:
            vs_ip = vs_ip_value.split('-')[0]
    else:
        g_multi_server_bool = False
        vs_ip = vs_ip_value
     
    vs_port = port_entry.get()
    req_num = request_number_entry.get()
    session_num = session_number_entry.get()
    interval = request_interval_entry.get()
    cmd = 'http_test' + ' ' + vs_ip + ' ' + "'" + vs_port + "'" + ' ' + session_num + ' ' + req_num + ' ' + interval + ' '
    ses_cmd = session_cmd()
    cmd += ses_cmd 
    fre_cmd = frequent_cmd()
    cmd += fre_cmd   
    ipresult_cmd = ip_cmd()
    cmd += ipresult_cmd  
    mth_cmd = method_cmd()
    cmd += mth_cmd
    hash_cmd = hash_persistence()
    cmd += hash_cmd 
    crt_cmd = cert_cmd()
    cmd += crt_cmd 
    cache_func_cmd = cache_cmd()
    cmd += cache_func_cmd
    authentication_cmd = auth_cmd()
    cmd += authentication_cmd 
    protol_constrain_cmd = http_constraint_cmd()
    cmd += protol_constrain_cmd
    sql_xss_cmd_str = sql_xss_cmd()
    cmd += sql_xss_cmd_str
    adv_cmd = advance_cmd()
    cmd += adv_cmd 
    h_cmd = header_cmd()
    cmd += h_cmd
    return cmd
def show_result(a=None, b=None, c=None):
    global result_txt, cmd
    cmd = result_cmd()
    result_txt.delete(1.0, END)
    result_txt.insert(1.0, cmd)

class Std_redirector(object): 
    def __init__(self,widget): 
        self.widget = widget 
    def write(self,string): 
        
       #self.widget.insert("end",)
       # print list(string)

        mystring = string.replace('\r','')
        self.widget.insert("end",mystring)
#        self.widget.insert("end",list(mystring))
    
    #self.widget.insert("end",list(string))
    
   # self.widget.insert('end',self.widget.index(END))
        current_index = float(self.widget.index(END))
 #       print 'current_index is %s,%s' % (current_index, max_line_num)
        if current_index > max_line_num:
            
     
            self.widget.delete(1.0, (1.0 + current_index - max_line_num))
        self.widget.see(END)
    def flush(self):
        pass

root = Tk()  
root.title("http_test (Author: Jiasheng Zhang. Version: 6.8 %s )" % title_host) 
#root.iconbitmap('./t.ico')

#root.geometry('800x600')   

necessary_frame = LabelFrame(text='Necessary Parameter')


label_server_name = Label(necessary_frame, text='VS_IP_Range:') 
label_server_name.grid(row=0, column=0, sticky='w')
server_name_v = StringVar()
server_entry = Entry(necessary_frame, width=59, textvariable=server_name_v) 
server_name_v.set(s_vs_ip)
server_entry.grid(row=0,columnspan=3, column=1)
server_name_v.trace('w', show_result)

label_port_name = Label(necessary_frame, text='VS_Port_Range:') 
label_port_name.grid(row=0, column=4, sticky='w')
port_v = StringVar()
port_entry = Entry(necessary_frame,width=24, textvariable=port_v) 
port_v.set(s_vs_port)
port_entry.grid(row=0, column=5)
port_v.trace('w', show_result)

session_number_label = Label(necessary_frame, text='Session_Number:') 
session_number_label.grid(row=1, column=0)
session_number_v = StringVar()
session_number_entry = Entry(necessary_frame,width=15, textvariable=session_number_v) 
session_number_v.set(s_session_num)
session_number_entry.grid(row=1, column=1)
session_number_v.trace('w', show_result)
request_number_label = Label(necessary_frame, text='Request_Number_In_Single_Session:') 
request_number_label.grid(row=1, column=2, sticky='w')
request_number_v = StringVar()
request_number_entry = Entry(necessary_frame,width=15, textvariable=request_number_v) 
request_number_v.set(s_req_num)
request_number_entry.grid(row=1, column=3, sticky='w')
request_number_v.trace('w', show_result)

request_interval_label = Label(necessary_frame, text='Request_Interval(s):') 
request_interval_label.grid(row=1, column=4)
request_interval_v = StringVar()
request_interval_entry = Entry(necessary_frame, width=24,textvariable=request_interval_v) 
request_interval_v.set(s_interval)
request_interval_entry.grid(row=1, column=5)
request_interval_v.trace('w', show_result)

#necessary_frame.pack(fill = X,ipadx = 10)
def btn_release(event):
    pass
# 
#    x, y, widget = event.x, event.y, event.widget
# 
#  
#    if not widget.instate(['pressed']):
#        return
#
#    elem =  widget.identify(x, y)
#
#    index = widget.index("@%d,%d" % (x, y))
#
#
#    if "close" in elem and widget.pressed_index == index:
#        widget.forget(index)
#        widget.event_generate("<<NotebookClosedTab>>")
#
#    widget.state(["!pressed"])
#    widget.pressed_index = None

root.bind_class("TNotebook", "<ButtonRelease-1>", btn_release)
nb = ttk.Notebook(width=tab_width, height=tab_height)
nb.pressed_index = None
general_frame = Frame()
session_frame = LabelFrame(general_frame,text='Session')

def sport_check():
    global g_srcport_bool, g_reuse_bool  
    if sport_check_v.get() == 1:
        sport_entry['state'] = 'normal' 
        g_srcport_bool = True
        if session_how_to_v.get() == 1:
            
            sport_reuse_check_checkbuttion['state'] = 'normal' 
            if sport_reuse_check_v.get() == 1:
                g_reuse_bool = True
            else:
                g_reuse_bool = False
    else:
        g_reuse_bool = False
        g_srcport_bool = False
        sport_entry['state'] = 'disable'
        sport_reuse_check_checkbuttion['state'] = 'disable' 
    show_result()

def sport_reuse_check():
    global g_reuse_bool
    if sport_reuse_check_v.get() == 1:
        g_reuse_bool = True
    else:
        g_reuse_bool = False
    show_result()
def concurrent():
    global g_concurrent_bool, g_onebyone_bool, g_middle_bool, g_srcport_bool, g_reuse_bool
    g_concurrent_bool = True
    g_onebyone_bool, g_middle_bool, g_reuse_bool = False, False, False
    
    interval_onebyone_entry['state'] = 'disable'
    interval_middle_entry['state'] = 'disable'
    sport_reuse_check_v.set(0)
    sport_reuse_check_checkbuttion['state'] = 'disable'
    
    show_result()
        
def onebyone():
    global g_concurrent_bool, g_onebyone_bool, g_middle_bool, g_srcport_bool   
    interval_onebyone_entry['state'] = 'normal'
    interval_middle_entry['state'] = 'disable'
    if sport_check_v.get() == 1:
        g_srcport_bool = True
        sport_reuse_check_checkbuttion['state'] = 'normal'
    g_onebyone_bool = True
    g_concurrent_bool, g_middle_bool = False, False
    show_result()
def middle():
    global g_concurrent_bool, g_onebyone_bool, g_middle_bool, g_reuse_bool
    interval_middle_entry['state'] = 'normal'
    interval_onebyone_entry['state'] = 'disable'
    sport_reuse_check_v.set(0)
    sport_reuse_check_checkbuttion['state'] = 'disable'
    g_middle_bool = True
    g_concurrent_bool, g_onebyone_bool, g_reuse_bool = False, False, False
    show_result()


session_how_to_v = IntVar() 
session_how_to_v.set(0)
concurrent_radio = Radiobutton(session_frame, variable=session_how_to_v, value=0, text='Concurrent', command=concurrent)
     
onebyone_radio = Radiobutton(session_frame, variable=session_how_to_v, value=1, text='One_over_next_start', command=onebyone)

middle_radio = Radiobutton(session_frame, variable=session_how_to_v, value=2, text='One_start_interval_next_start', command=middle)

interval_onebyone_v = StringVar()
interval_onebyone_entry = Entry(session_frame,width=8, textvariable=interval_onebyone_v,state='disable') 
interval_onebyone_v.set('1.0')
interval_onebyone_v.trace('w', show_result)
interval_middle_v = StringVar()
interval_middle_entry = Entry(session_frame, width=8,textvariable=interval_middle_v, state='disable') 
interval_middle_v.set('1.0')
interval_middle_v.trace('w', show_result)
sport_check_v = IntVar()
sport_check_checkbuttion = Checkbutton(session_frame, text='Source_Port_start:', variable=sport_check_v, command=sport_check)

sport_entry_v = StringVar()
sport_entry = Entry(session_frame, width=8,textvariable=sport_entry_v, state='disable') 
sport_entry_v.set('50000')
sport_entry_v.trace('w', show_result)
sport_reuse_check_v = IntVar()
sport_reuse_check_checkbuttion = Checkbutton(session_frame, state='disable', text='Reuse', variable=sport_reuse_check_v, command=sport_reuse_check)


concurrent_radio.grid(row=0, column=0, sticky='w',columnspan=2)
middle_radio.grid(row=1, column=0, sticky='w')
interval_middle_entry.grid(row=1, column=1, sticky='w')
onebyone_radio.grid(row=2, column=0, sticky='w')
interval_onebyone_entry.grid(row=2, column=1, sticky='w')
sport_check_checkbuttion.grid(row=3, column=0, sticky='w')
sport_entry.grid(row=3, column=1, sticky='w')
sport_reuse_check_checkbuttion.grid(row=3, column=2, sticky='w')

frequently_used_frame = LabelFrame(general_frame,text='Frequently_used')
def disable_warm():
    global g_l4_warm_bool,g_l7_warm_bool
    g_l4_warm_bool = False
    g_l7_warm_bool = False
    show_result()
def l4_warm():
    global g_l4_warm_bool,g_l7_warm_bool
    g_l4_warm_bool = True
    g_l7_warm_bool = False
    show_result()
def l7_warm():
    global g_l7_warm_bool,g_l4_warm_bool
    g_l7_warm_bool = True
    g_l4_warm_bool = False
    show_result()
def disable_account():
    global g_l4_weight_bool,g_l7_weight_bool
    g_l4_weight_bool = False
    g_l7_weight_bool = False
    show_result()
def l4_account():
    global g_l4_weight_bool,g_l7_weight_bool
    g_l4_weight_bool = True
    g_l7_weight_bool = False
    show_result()
def l7_account():
    global g_l4_weight_bool,g_l7_weight_bool
    g_l7_weight_bool = True
    g_l4_weight_bool = False
    show_result() 

warm_check_v = IntVar()
warm_check_v.set(0)
disable_warm_checkbuttion = Radiobutton(frequently_used_frame, text='General output',value=0, variable=warm_check_v, command=disable_warm)
l4_warm_checkbuttion = Radiobutton(frequently_used_frame, text='Output by CPS',value=1, variable=warm_check_v, command=l4_warm)
l7_warm_checkbuttion = Radiobutton(frequently_used_frame, text='Output by TPS',value=2, variable=warm_check_v, command=l7_warm)

weight_check_v = IntVar() 
weight_check_v.set(0)

no_weight_radio = Radiobutton(frequently_used_frame, variable=weight_check_v, value=0, text='Disable account', command=disable_account)
l4_weight_radio = Radiobutton(frequently_used_frame, variable=weight_check_v, value=1, text='Account by TCP session', command=l4_account)
l7_weight_radio = Radiobutton(frequently_used_frame, variable=weight_check_v, value=2, text='Account by Transaction', command=l7_account)


#def check_notime():
#    global g_no_print_time_bool
#    if no_time_check_v.get() == 1:
#        g_no_print_time_bool = True
#    else:
#        g_no_print_time_bool = False
#    show_result()
   
def check_timeout():
    global g_timeout_bool
    if timeout_check_v.get() == 1:
        g_timeout_bool = True
        timeout_value_entry['state'] = 'normal'
    else:
        g_timeout_bool = False
        timeout_value_entry['state'] = 'disable'
    show_result()
    
def check_debug_all():
    global g_debug_all_bool
    if debug_all_v.get() == 1:
        g_debug_all_bool = True
    else:
        g_debug_all_bool = False
    show_result()
    
def check_fullnat():
    global g_fullnat_bool
    global g_l2_src_bool,g_l2_dst_bool,g_l2_src_dst_bool,g_l2_session_bool
    if fullnat_v.get() == 1:
        g_fullnat_bool = True
    else:
        g_fullnat_bool = False
        g_l2_src_bool,g_l2_dst_bool,g_l2_src_dst_bool,g_l2_session_bool = False,False,False,False
        l2_dst_v.set(0)
        l2_src_v.set(0)
        l2_src_dst_v.set(0)
        l2_session_v.set(0)
    show_result()
    
def check_content_rewrite():
    global g_content_rewrite_bool
    if content_rewrite_v.get() == 1:
        g_content_rewrite_bool = True
    else:
        g_content_rewrite_bool = False
    show_result()
 

timeout_check_v = IntVar()
timeout_checkbuttion = Checkbutton(frequently_used_frame, text='Timeout:', variable=timeout_check_v, command=check_timeout)

timeout_value_entry_v = StringVar()
timeout_value_entry = Entry(frequently_used_frame, width=8,textvariable=timeout_value_entry_v, state='disable') 
timeout_value_entry_v.set('1.0')
timeout_value_entry_v.trace('w', show_result)

#no_time_check_v = IntVar()
#no_time_checkbuttion = Checkbutton(frequently_used_frame, text='No print time and sport', variable=no_time_check_v, command=check_notime)

debug_all_v = IntVar()
debug_all_checkbuttion = Checkbutton(frequently_used_frame, text='Print PKG info', variable=debug_all_v, command=check_debug_all)

fullnat_v = IntVar()
fullnat_checkbuttion = Checkbutton(frequently_used_frame, text='Display LB IP', variable=fullnat_v, command=check_fullnat)

content_rewrite_v = IntVar()
content_rewrite_checkbuttion = Checkbutton(frequently_used_frame, text='Display rewrting info', variable=content_rewrite_v, command=check_content_rewrite)

def check_l2_src():
    global g_l2_src_bool  
    if l2_src_v.get() == 1:
        if not g_fullnat_bool:
            g_l2_src_bool = False
            showinfo("Setting config prompt", "Please enable 'Display LB IP' firstly")
            l2_src_v.set(0)
           
        else:
            g_l2_src_bool = True
    else:
        g_l2_src_bool = False
    show_result()
    
def check_l2_dst():
    global g_l2_dst_bool  
    if l2_dst_v.get() == 1:
        if not g_fullnat_bool:
            g_l2_dst_bool = False
            showinfo("Setting config prompt", "Please enable 'Display LB IP' firstly")
            l2_dst_v.set(0)
           
        else:
            g_l2_dst_bool = True
    else:
        g_l2_dst_bool = False
    show_result()

def check_l2_src_dst():
    global g_l2_src_dst_bool  
    if l2_src_dst_v.get() == 1:
        if not g_fullnat_bool:
            g_l2_src_dst_bool = False
            showinfo("Setting config prompt", "Please enable 'Display LB IP' firstly")
            l2_src_dst_v.set(0)
           
        else:
            g_l2_src_dst_bool = True
    else:
        g_l2_src_dst_bool = False
    show_result()
def check_l2_session():
    global g_l2_session_bool  
    if l2_session_v.get() == 1:
        if not g_fullnat_bool:
            g_l2_session_bool = False
            showinfo("Setting config prompt", "Please enable 'Display LB IP' firstly")
            l2_session_v.set(0)
           
        else:
            g_l2_session_bool = True
    else:
        g_l2_session_bool = False
    show_result()

l2_src_v = IntVar()
l2_src_checkbuttion = Checkbutton(frequently_used_frame, text='Account_SRC_LLB', variable=l2_src_v, command=check_l2_src)

l2_dst_v = IntVar()
l2_dst_checkbuttion = Checkbutton(frequently_used_frame, text='Account_DST_LLB', variable=l2_dst_v, command=check_l2_dst)


l2_src_dst_v = IntVar()
l2_src_dst_checkbuttion = Checkbutton(frequently_used_frame, text='Account_SRC_DST_LLB', variable=l2_src_dst_v, command=check_l2_src_dst)

l2_session_v = IntVar()
l2_session_checkbuttion = Checkbutton(frequently_used_frame, text='Account_SESSION_LLB', variable=l2_session_v, command=check_l2_session)



no_weight_radio.grid(row=0, column=0, sticky='w')
l4_weight_radio.grid(row=0, column=1, sticky='w')
l7_weight_radio.grid(row=0, column=2, sticky='w')
disable_warm_checkbuttion.grid(row=1, column=0, sticky='w')
l4_warm_checkbuttion.grid(row=1, column=1, sticky='w')
l7_warm_checkbuttion.grid(row=1, column=2, sticky='w')
debug_all_checkbuttion.grid(row=2, column=0, sticky='w')
fullnat_checkbuttion.grid(row=2, column=1, sticky='w')
content_rewrite_checkbuttion.grid(row=2, column=2, sticky='w')
l2_src_checkbuttion.grid(row=3, column=0, sticky='w')
l2_dst_checkbuttion.grid(row=3, column=1, sticky='w')
l2_src_dst_checkbuttion.grid(row=3, column=2, sticky='w')

timeout_checkbuttion.grid(row=4, column=0, sticky='w')
timeout_value_entry.grid(row=4, column=1, sticky='w')
l2_session_checkbuttion.grid(row=4, column=2, sticky='w')
#no_time_checkbuttion.grid(row=4, column=2, sticky='w')


session_frame.grid(row=0, column=0, sticky='w',ipadx=30,ipady=15)
frequently_used_frame.grid(row=0, column=1, sticky='w',ipadx=5,ipady=5)



ip_frame = Frame()
def disable_ip():
    global g_disableip_bool, g_randomip_bool, g_startip_bool, g_endip_bool, g_overip_bool, g_eth_bool,g_discontinus_bool,g_dst_ip_port_bool
    
    g_disableip_bool = True
    g_discontinus_bool,g_randomip_bool, g_startip_bool, g_endip_bool, g_overip_bool, g_eth_bool,g_dst_ip_port_bool= False,False, False, False, False, False,False
    random_num_entry['state'] = 'disable'
    range_ip_start_entry['state'] = 'disable'
    range_ip_end_entry['state'] = 'disable'
 #   check_end_ip_v.set(0)
    check_end_checkbuttion['state'] = 'disable'
    order_ip_checkbuttion['state'] = 'disable'
    ethname_checkbuttion['state'] = 'disable'
    check_random_dst_ip_port_checkbuttion['state'] = 'disable'
    check_random_dst_ip_port_v.set(0)
    if ethname_bool_v.get() == 1:
        ethname_list['state'] = 'disable'
    if order_ip_v.get() == 1:
        ip_interval_entry['state'] = 'disable'
    show_result()
    
def discontinuous_ip():
    global g_disableip_bool, g_randomip_bool,g_discontinus_bool, g_startip_bool, g_endip_bool, g_eth_bool, g_overip_bool
 
    g_discontinus_bool = True
    g_randomip_bool,g_disableip_bool, g_startip_bool, g_endip_bool = False, False, False,False
    discontinuous_ip_entry['state'] = 'normal'
    random_num_entry['state'] = 'disable'
    range_ip_start_entry['state'] = 'disable'
    range_ip_end_entry['state'] = 'disable'
  #  check_end_ip_v.set(0)
    check_end_checkbuttion['state'] = 'disable'
    check_random_dst_ip_port_checkbuttion['state'] = 'normal'
    order_ip_checkbuttion['state'] = 'normal'
    ethname_checkbuttion['state'] = 'normal'
    if ethname_bool_v.get() == 1:
        ethname_list['state'] = 'normal'
        g_eth_bool = True
    else:
        g_eth_bool = False
    if order_ip_v.get() == 1:
        g_overip_bool = True
        ip_interval_entry['state'] = 'normal'
    else:
        g_overip_bool = False
    show_result()
    pass
def random_num():
    global g_discontinus_bool, g_disableip_bool,g_randomip_bool, g_startip_bool, g_endip_bool, g_eth_bool, g_overip_bool
    g_randomip_bool = True
    g_discontinus_bool, g_startip_bool, g_endip_bool,g_disableip_bool = False, False, False,False
    random_num_entry['state'] = 'normal'
    discontinuous_ip_entry['state'] = 'disable'
    range_ip_start_entry['state'] = 'disable'
    range_ip_end_entry['state'] = 'disable'
  #  check_end_ip_v.set(0)
    check_end_checkbuttion['state'] = 'disable'
    order_ip_checkbuttion['state'] = 'normal'
    ethname_checkbuttion['state'] = 'normal'
    check_random_dst_ip_port_checkbuttion['state'] = 'normal'
    if ethname_bool_v.get() == 1:
        ethname_list['state'] = 'normal'
        g_eth_bool = True
    else:
        g_eth_bool = False
    if order_ip_v.get() == 1:
        g_overip_bool = True
        ip_interval_entry['state'] = 'normal'
    else:
        g_overip_bool = False
    show_result()



def range_ip():
    
    global g_discontinus_bool,g_disableip_bool, g_randomip_bool, g_startip_bool, g_endip_bool, g_eth_bool, g_overip_bool
    g_startip_bool = True
    g_disableip_bool, g_randomip_bool,g_discontinus_bool = False, False, False
    random_num_entry['state'] = 'disable'
    discontinuous_ip_entry['state'] = 'disable'
    range_ip_start_entry['state'] = 'normal'
    check_end_checkbuttion['state'] = 'normal'
    range_ip_end_entry['state'] = 'disable'
    order_ip_checkbuttion['state'] = 'normal'
    ethname_checkbuttion['state'] = 'normal'
    check_random_dst_ip_port_checkbuttion['state'] = 'normal'
    if ethname_bool_v.get() == 1:
        ethname_list['state'] = 'normal'
        g_eth_bool = True
    else:
        g_eth_bool = False  
    if check_end_ip_v.get() == 1:
        g_endip_bool = True
        range_ip_end_entry['state'] = 'normal'
    else:
        g_endip_bool = False
        range_ip_end_entry['state'] = 'disable'
        
    if order_ip_v.get() == 1:
        g_overip_bool = True
    else:
        g_overip_bool = False
    show_result()      

def check_end_ip(): 
    global g_endip_bool


    if check_end_ip_v.get() == 1:
        g_endip_bool = True
        range_ip_end_entry['state'] = 'normal'
    else:
        g_endip_bool = False
        range_ip_end_entry['state'] = 'disable'
    show_result()
def get_all_eth():
    
    ethall, error = Popen('ifconfig', shell=True, stdout=PIPE).communicate()
    list1 = ethall.split('\n')
    list2 = []
    list3 = ['']
    for i in list1:
        list2.append(i.strip())
    for i in list2:        
        if 'Link encap' in i:
            list3.append(i.split(' ')[0])
    return list3
def printOption(tmp1, tmp2, tmp3):
    show_result()
            
def check_ethname():
    global g_eth_bool
    
    global ethname_list, ethname_list_v
    if ethname_bool_v.get() == 1:
        g_eth_bool = True
        ethname_all_names = get_all_eth()
        ethname_list_v = StringVar(root)
        ethname_list_v.set('')

#tlist = ['Python','PHP','CPP','C','Java','JavaScript','VBScript']
        ethname_list = apply(OptionMenu, (ip_frame, ethname_list_v) + tuple(ethname_all_names))
        ethname_list_v.trace('w', printOption)
     #   ethname_list.bind('<Button-1>',printOption)
        
    #    ethname_list['state'] = 'normal'
        ethname_list.grid(row=4, column=3, stick='w')
    else:
        ethname_list.grid_forget()
        g_eth_bool = False
    show_result()    
        
   
def check_order():
    global g_overip_bool
    if order_ip_v.get() == 1:
        g_overip_bool = True
        ip_interval_entry['state'] = 'normal'
    else:
        g_overip_bool = False
        ip_interval_entry['state'] = 'disable'
    show_result()

ip_v = IntVar() 
ip_v .set(0)
disable_radio = Radiobutton(ip_frame, variable=ip_v, value=0, text='Disable', command=disable_ip)
     
random_num_radio = Radiobutton(ip_frame, variable=ip_v, value=1, text='Random_Num', command=random_num)

discontinuous_ip_radio= Radiobutton(ip_frame, variable=ip_v, value=2, text='Discontinuous IP', command=discontinuous_ip)

range_ip_radio = Radiobutton(ip_frame, variable=ip_v, value=3, text='Single or Start IP', command=range_ip)

random_num_v = StringVar()
random_num_entry = Entry(ip_frame,textvariable=random_num_v, state='disable',width=10) 
random_num_v.set('10')
random_num_v.trace('w', show_result)

discontinuous_ip_v = StringVar()
discontinuous_ip_entry = Entry(ip_frame,textvariable=discontinuous_ip_v, state='disable',width=89) 
discontinuous_ip_v.set('1.1.1.1,2.2.2.2,3.3.3.3,4.4.4.4')
discontinuous_ip_v.trace('w', show_result)
range_ip_start_v = StringVar()
range_ip_start_entry = Entry(ip_frame, textvariable=range_ip_start_v, width=40,state='disable') 
range_ip_start_v.set(s_start_ip)
range_ip_start_v.trace('w', show_result)

check_end_ip_v = IntVar()     
check_end_checkbuttion = Checkbutton(ip_frame, text='End_IP', state='disable', variable=check_end_ip_v, command=check_end_ip)

range_ip_end_v = StringVar()
range_ip_end_entry = Entry(ip_frame,width=39, textvariable=range_ip_end_v, state='disable')
range_ip_end_v.set(s_end_ip)
range_ip_end_v.trace('w', show_result)

ethname_bool_v = IntVar()
ethname_checkbuttion = Checkbutton(ip_frame, text='NIC:', state='disable', variable=ethname_bool_v, command=check_ethname)

order_ip_v = IntVar()     
order_ip_checkbuttion = Checkbutton(ip_frame, text='One_IP_Over_Another_Start', state='disable', variable=order_ip_v, command=check_order)
ip_interval_v = StringVar()
ip_interval_entry = Entry(ip_frame, textvariable=ip_interval_v, state='disable')
ip_interval_v.set('1.0')
ip_interval_v.trace('w', show_result)

def check_dst_ip_port():
    global g_dst_ip_port_bool
    if check_random_dst_ip_port_v.get() == 1:
        g_dst_ip_port_bool = True
    else:
        g_dst_ip_port_bool= False
    show_result()
check_random_dst_ip_port_v = IntVar()     
check_random_dst_ip_port_checkbuttion= Checkbutton(ip_frame, text='Random_DST_IP_PORT', state='disable', variable=check_random_dst_ip_port_v, command=check_dst_ip_port)

disable_radio.grid(row=0, column=0, sticky='w')
random_num_radio.grid(row=1, column=0, sticky='w')
random_num_entry.grid(row=1, column=1, sticky='w')
discontinuous_ip_radio.grid(row=2, column=0, sticky='w')
discontinuous_ip_entry.grid(row=2, column=1, sticky='w',columnspan=3)

range_ip_radio.grid(row=3, column=0, sticky='w')
range_ip_start_entry.grid(row=3, column=1, sticky='w')
check_end_checkbuttion.grid(row=3, column=2, stick='w')
range_ip_end_entry.grid(row=3, column=3, sticky='w')
order_ip_checkbuttion.grid(row=4, column=0, stick='w')
ip_interval_entry.grid(row=4, column=1, stick='w')
ethname_checkbuttion.grid(row=4, column=2, stick='w')
check_random_dst_ip_port_checkbuttion.grid(row=5, column=0, stick='w')
#ethname_entry.grid(row=3,column=3,sticky='w')
#ethname_list.grid(row=3,column=3,stick='w')
#ip_frame.pack(fill = X,ipadx = 10)


method_url_frame = Frame()
def check_method_get():
    global g_get_bool
    if get_method_v.get()==1:
        g_get_bool = True     
        get_url_entry['state'] = 'normal'    
    else:
        
        g_get_bool = False
        get_url_entry['state'] = 'disable'
    show_result()

def check_method_post():
    global g_post_bool
    if post_method_v.get()==1:
        g_post_bool = True
        post_user_pass_entry['state'] = 'normal'
        post_url_entry['state'] = 'normal'
    else:
        g_post_bool = False
        post_user_pass_entry['state'] = 'disable'
        post_url_entry['state'] = 'disable'        
    show_result()
def check_method_put():
    global g_put_bool
    if put_method_v.get()==1:
        g_put_bool = True
        put_url_entry['state'] = 'normal'
    else:
        g_put_bool = False
        put_url_entry['state'] = 'disable'        
    show_result()
def check_method_delete():
    global g_delete_bool
    if delete_method_v.get()==1:
        g_delete_bool = True
        delete_url_entry['state'] = 'normal'
    else:
        g_delete_bool = False
        delete_url_entry['state'] = 'disable'        
    show_result()
def check_method_trace():
    global g_trace_bool
    if trace_method_v.get()==1:
        g_trace_bool = True
        trace_url_entry['state'] = 'normal'
    else:
        g_trace_bool = False
        trace_url_entry['state'] = 'disable'        
    show_result()
def check_method_option():
    global g_option_bool
    if option_method_v.get()==1:
        g_option_bool = True
        option_url_entry['state'] = 'normal'
    else:
        g_option_bool = False
        option_url_entry['state'] = 'disable'        
    show_result()
def check_method_connect():
    global g_connect_bool
    if connect_method_v.get()==1:
        g_connect_bool = True
        connect_url_entry['state'] = 'normal'
    else:
        g_connect_bool = False
        connect_url_entry['state'] = 'disable'        
    show_result()

def check_method_head():
    global g_head_bool
    if head_method_v.get()==1:
        g_head_bool = True
        head_url_entry['state'] = 'normal'
    else:
        g_head_bool = False
        head_url_entry['state'] = 'disable'        
    show_result()
def check_method_custom():
    global g_custom_method_bool
    if custom_method_v.get()==1:
        g_custom_method_bool = True
        custom_url_entry['state'] = 'normal'
    else:
        g_custom_method_bool = False
        custom_url_entry['state'] = 'disable'        
    show_result()
def check_URI():
    global g_url_bool
    if check_url_v.get() == 1:
        g_url_bool = True
        url_entry['state'] = 'normal'
        uri_account_checkbuttion['state'] = 'normal'
        if uri_account_check_v.get() == 1:
            g_url_weight_bool = True
        else:
            g_url_weight_bool = False
    else:
        g_url_bool = False
        url_entry['state'] = 'disable'
        uri_account_checkbuttion['state'] = 'disable'
    show_result()

def check_uriaccount():
    global g_url_weight_bool
    if uri_account_check_v.get() == 1:
        g_url_weight_bool = True
    else:
        g_url_weight_bool = False
    show_result()

zip_value = ''
def change_zip(event):
    global zip_value
    if event.widget.current(): # value #0 is not a theme
        zip_value = event.widget.get()
    else:
        zip_value = ''
    show_result()
    
content_type_value = ''    
def change_content_type(event):
    global content_type_value
    content_type_value = event.widget.get()
    if '/' in content_type_value:
        get_current_value = get_entry_url_v.get()
        if search('\?.+=.+?',get_current_value) is not None:
            if 'Content_Type=' not in get_current_value:
                get_current_value = get_current_value + '&' + 'Content_Type=%s' % content_type_value
            else:
                prefix,suffix = get_current_value.split('Content_Type=')
                get_current_value = prefix + 'Content_Type=%s' % content_type_value
        else:
            get_current_value = get_current_value + '?' + 'Content_Type=%s' % content_type_value
    else:
        get_current_value = get_entry_url_v.get()
        if 'Content_Type=' in get_current_value:
            prefix,suffix = get_current_value.split('Content_Type=')
            if prefix.endswith('?'):
                get_current_value = prefix[0:-1]
        
    get_entry_url_v.set(get_current_value)
    show_result()

    

get_method_v = IntVar()
get_method_checkbuttion = Checkbutton(method_url_frame, text='GET', variable=get_method_v, command=check_method_get)
get_method_v.set(1)
get_entry_url_v = StringVar()
get_url_entry = Entry(method_url_frame, textvariable=get_entry_url_v, state='normal', width=44) 
get_entry_url_v.set(s_get_url)
get_entry_url_v.trace('w', show_result)

compress_label = Label(method_url_frame,text='Content_Type:') 
compress_type = ['none','application/soap+xml','application/xml','text/html','text/plain','text/css','application/x-javascript','application/javascript','text/javascript','text/xml','application/pdf','image/jpeg']

compress_combo = ttk.Combobox(method_url_frame,values=compress_type,width=17)
compress_combo.set(compress_type[0])

compress_combo.bind("<<ComboboxSelected>>", change_content_type)

zip_label = Label(method_url_frame, text='Compress:')
zip_list = ['gzip_and_deflate', 'gzip_only', 'deflate_only', 'identity', 'unsupport','mix']
zip_combo = ttk.Combobox(method_url_frame,values=zip_list,width=13)
zip_combo.set(zip_list[0])
zip_combo.bind("<<ComboboxSelected>>", change_zip)

post_method_v = IntVar()
post_method_checkbuttion = Checkbutton(method_url_frame, text='POST', variable=post_method_v, command=check_method_post)
entry_postuser_pass_v = StringVar()
post_user_pass_entry = Entry(method_url_frame,width=10, textvariable=entry_postuser_pass_v, state='disable') 

entry_postuser_pass_v.set(s_post_user_pass)
entry_postuser_pass_v.trace('w', show_result)

post_entry_url_v = StringVar()
post_url_entry = Entry(method_url_frame, textvariable=post_entry_url_v, state='disable', width=32) 
post_entry_url_v.set(s_post_url)
post_entry_url_v.trace('w', show_result)
#post_label = Label(method_url_frame, text='sub/sub[10-100].php') 


put_method_v = IntVar()
put_method_checkbuttion = Checkbutton(method_url_frame, text='PUT', variable=put_method_v, command=check_method_put)

put_entry_url_v = StringVar()
put_url_entry = Entry(method_url_frame, textvariable=put_entry_url_v, state='disable', width=44) 
put_entry_url_v.set('sub/sub[10-100].html')
put_entry_url_v.trace('w', show_result)


delete_method_v = IntVar()
delete_method_checkbuttion = Checkbutton(method_url_frame, text='DELETE', variable=delete_method_v, command=check_method_delete)

delete_entry_url_v = StringVar()
delete_url_entry = Entry(method_url_frame, textvariable=delete_entry_url_v, state='disable', width=45) 
delete_entry_url_v.set('sub/sub[10-100].html')
delete_entry_url_v.trace('w', show_result)


head_method_v = IntVar()
head_method_checkbuttion = Checkbutton(method_url_frame, text='HEAD', variable=head_method_v, command=check_method_head)

head_entry_url_v = StringVar()
head_url_entry = Entry(method_url_frame, textvariable=head_entry_url_v, state='disable', width=44) 
head_entry_url_v.set('sub/sub[10-100].html')
head_entry_url_v.trace('w', show_result)

trace_method_v = IntVar()
trace_method_checkbuttion = Checkbutton(method_url_frame, text='TRACE', variable=trace_method_v, command=check_method_trace)

trace_entry_url_v = StringVar()
trace_url_entry = Entry(method_url_frame, textvariable=trace_entry_url_v, state='disable', width=45) 
trace_entry_url_v.set('sub/sub[10-100].html')
trace_entry_url_v.trace('w', show_result)


option_method_v = IntVar()
option_method_checkbuttion = Checkbutton(method_url_frame, text='OPTIONS', variable=option_method_v, command=check_method_option)

option_entry_url_v = StringVar()
option_url_entry = Entry(method_url_frame, textvariable=option_entry_url_v, state='disable', width=45) 
option_entry_url_v.set('sub/sub[10-100].html')
option_entry_url_v.trace('w', show_result)

connect_method_v = IntVar()
connect_method_checkbuttion = Checkbutton(method_url_frame, text='CONNECT', variable=connect_method_v, command=check_method_connect )

connect_entry_url_v = StringVar()
connect_url_entry = Entry(method_url_frame, textvariable=connect_entry_url_v, state='disable', width=44) 
connect_entry_url_v.set('1.1.1.[2-10]:8080')
connect_entry_url_v.trace('w', show_result)


custom_method_v = IntVar()
custom_method_checkbuttion = Checkbutton(method_url_frame, text='CUSTOM', variable=custom_method_v, command=check_method_custom)

custom_entry_url_v = StringVar()
custom_url_entry = Entry(method_url_frame, textvariable=custom_entry_url_v, state='disable', width=45) 
custom_entry_url_v.set('MY_METHOD:abc.html')
custom_entry_url_v.trace('w', show_result)




uri_account_check_v = IntVar()
uri_account_checkbuttion = Checkbutton(method_url_frame, text='URI Account', variable=uri_account_check_v, command=check_uriaccount)

#zip_list_menu = apply(OptionMenu, (method_url_frame, zip_list_v) + tuple(zip_list))

#method_url_frame.pack(side = LEFT)

get_method_checkbuttion.grid(row=0, column=0, sticky='w')
get_url_entry.grid(row=0, column=1, sticky='w',columnspan=3)
zip_label.grid(row=0, column=4, sticky='w')
zip_combo.grid(row=0, column=5, sticky='w')
compress_label.grid(row=0, column=6, sticky='w')
compress_combo.grid(row=0, column=7, sticky='e')

post_method_checkbuttion.grid(row=1, column=0, sticky='w')
post_user_pass_entry.grid(row=1, column=1, sticky='w')
post_url_entry.grid(row=1, column=2, sticky='w',columnspan=2)
#post_label.grid(row=1, column=4, sticky='w',columnspan=3)
option_method_checkbuttion.grid(row=1, column=4, sticky='w')
option_url_entry.grid(row=1, column=5, sticky='w',columnspan=3)
put_method_checkbuttion.grid(row=2, column=0, sticky='w')
put_url_entry.grid(row=2, column=1, sticky='w',columnspan=3)
delete_method_checkbuttion.grid(row=2, column=4, sticky='w')
delete_url_entry.grid(row=2, column=5, sticky='w',columnspan=3)

head_method_checkbuttion.grid(row=3, column=0, sticky='w')
head_url_entry.grid(row=3, column=1, sticky='w',columnspan=3)

trace_method_checkbuttion.grid(row=3, column=4, sticky='w')
trace_url_entry.grid(row=3, column=5, sticky='w',columnspan=3)

connect_method_checkbuttion.grid(row=4, column=0, sticky='w')
connect_url_entry.grid(row=4, column=1, sticky='w',columnspan=3)

#url_entry.grid(row=2, column=1, sticky='w', columnspan=2)
custom_method_checkbuttion.grid(row=4, column=4, sticky='w')
custom_url_entry.grid(row=4, column=5, sticky='w',columnspan=3)
uri_account_checkbuttion.grid(row=5, column=0, sticky='w')




cert_frame = Frame()
def method_https_pyssl():
    global g_ssl_disable, g_ssl_enable, g_ssl_verify, g_ssl_client, g_ssl_d,g_pyopenssl
    g_ssl_disable = False
    g_ssl_enable = False
    g_pyopenssl = True

    verify_server_checkbuttion['state'] = 'normal'
    client_cert_checkbuttion ['state'] = 'normal'

    client_key_entry ['state'] = 'normal'
    sslv2_checkbuttion['state'] = 'normal'
    sslv3_checkbuttion['state'] = 'normal'
    tlsv1_checkbuttion['state'] = 'normal'
    tlsv11_checkbuttion['state'] = 'normal'
    tlsv12_checkbuttion['state'] = 'normal'
    
    sni_checkbuttion['state'] = 'normal'
    reuse_checkbuttion['state'] = 'normal'
    ticket_checkbuttion['state'] = 'normal'
    encryp_checkbuttion['state'] = 'normal'
    
    global g_multi_cert


    if check_ca_v.get() == 1:
        g_ssl_verify = True
        ca_entry['state'] = 'normal'  
        verify_host_checkbuttion['state'] = 'normal'        
    else:
        g_ssl_verify = False
        ca_entry ['state'] = 'disable'
        verify_host_checkbuttion['state'] = 'disable' 
    if check_client_cert_v.get() == 1:
        g_ssl_client = True
        client_cert_entry['state'] = 'normal'
        client_key_entry['state'] = 'normal'
        multi_cert_check_checkbuttion['state'] = 'normal'
        if multi_cert_check_v.get() == 1:
            multi_cert_entry['state'] = 'normal'
            g_multi_cert = True
        
        else:
            multi_cert_entry['state'] = 'disable'
            g_multi_cert = False
    else:
        g_ssl_client = False
        client_cert_entry['state'] = 'disable'
        client_key_entry['state'] = 'disable'
    if verify_host_v.get() == 1:
        g_ssl_domain = True
    else:
        g_ssl_domain = False
    if check_encryp_v.get() == 1:
        encryp_text['state'] = 'normal'
        ciphers_combo['state'] = 'readonly'
    else:
        encryp_text['state'] = 'disable'
        ciphers_combo['state'] = 'disable'
    port_v.set('443')
    check_tlsv1_v.set(1)
   
    show_result()
  
    
def method_https_normal():
    global g_ssl_disable, g_ssl_enable, g_ssl_verify, g_ssl_client, g_ssl_domain,g_pyopenssl
    g_ssl_disable = False
    g_ssl_enable = True
    g_pyopenssl = False
    verify_server_checkbuttion['state'] = 'normal'

    client_cert_checkbuttion ['state'] = 'normal'
    sslv2_checkbuttion['state'] = 'disable'
    sslv3_checkbuttion['state'] = 'disable'
    tlsv1_checkbuttion['state'] = 'disable'
    tlsv11_checkbuttion['state'] = 'disable'
    tlsv12_checkbuttion['state'] = 'disable'
    
    sni_checkbuttion['state'] = 'disable'
    reuse_checkbuttion['state'] = 'disable'
    ticket_checkbuttion['state'] = 'disable'
    encryp_checkbuttion['state'] = 'disable'
    ciphers_combo['state'] = 'disable'
    global g_multi_cert


    if check_ca_v.get() == 1:
        g_ssl_verify = True
        ca_entry['state'] = 'normal'  
        verify_host_checkbuttion['state'] = 'normal'        
    else:
        g_ssl_verify = False
        ca_entry ['state'] = 'disable'
        verify_host_checkbuttion['state'] = 'disable' 
    if check_client_cert_v.get() == 1:
        g_ssl_client = True
        client_cert_entry['state'] = 'normal'
        client_key_entry['state'] = 'normal'
        multi_cert_check_checkbuttion['state'] = 'normal'
        if multi_cert_check_v.get() == 1:
            multi_cert_entry['state'] = 'normal'
            g_multi_cert = True

        else:
             multi_cert_entry['state'] = 'disable'
             g_multi_cert = False
    else:
        g_ssl_client = False
        client_cert_entry['state'] = 'disable'
        client_key_entry['state'] = 'disable'
    if verify_host_v.get() == 1:
        g_ssl_domain = True
    else:
        g_ssl_domain = False
    port_v.set('443')
    show_result()

def method_https_off():
    global g_ssl_disable, g_ssl_enable, g_ssl_verify, g_ssl_domain, g_ssl_client,g_pyopenssl
    g_ssl_disable = True
    g_ssl_enable = False
    g_ssl_verify = False
    g_ssl_domain = False
    g_ssl_client = False
    g_pyopenssl = False
    multi_cert_check_checkbuttion['state'] = 'disable'
    multi_cert_entry['state'] = 'disable'
    verify_server_checkbuttion['state'] = 'disable'
    client_cert_checkbuttion ['state'] = 'disable'
    ca_entry ['state'] = 'disable'
    client_cert_entry['state'] = 'disable'
    client_key_entry['state'] = 'disable'
    verify_host_checkbuttion['state'] = 'disable'
    sslv2_checkbuttion['state'] = 'disable'
    sslv3_checkbuttion['state'] = 'disable'
    tlsv1_checkbuttion['state'] = 'disable'
    tlsv11_checkbuttion['state'] = 'disable'
    tlsv12_checkbuttion['state'] = 'disable'
    
    sni_checkbuttion['state'] = 'disable'
    reuse_checkbuttion['state'] = 'disable'
    ticket_checkbuttion['state'] = 'disable'
    encryp_checkbuttion['state'] = 'disable'
    ciphers_combo['state'] = 'disable'
    port_v.set('80')
    
    show_result()

 
def check_ca(): 
    global g_ssl_verify, g_ssl_domain
    if check_ca_v.get() == 1:
        g_ssl_verify = True
        ca_entry['state'] = 'normal'  
        verify_host_checkbuttion['state'] = 'normal'        
    else:
        g_ssl_verify = False
        ca_entry ['state'] = 'disable'
        verify_host_checkbuttion['state'] = 'disable'

    if verify_host_v.get() == 1:
        g_ssl_domain = True
    else:
        g_ssl_domain = False
    show_result()
    
def check_host():
    global g_ssl_domain
    if verify_host_v.get() == 1:
        g_ssl_domain = True
    else:
        g_ssl_domain = False
    show_result()

 
def check_client_cert(): 
    global g_ssl_client,g_multi_cert
    if check_client_cert_v.get() == 1:
        g_ssl_client = True
        
        client_cert_entry['state'] = 'normal'
        client_key_entry['state'] = 'normal'
        multi_cert_check_checkbuttion['state'] = 'normal'
        if multi_cert_check_v.get() == 1:
            multi_cert_entry['state']  = 'normal'
            g_multi_cert = True

        else:
            multi_cert_entry['state'] = 'disable'
            g_multi_cert = False
        
    else:
        g_ssl_client = False
        multi_cert_entry['state'] = 'disable'
        client_cert_entry['state'] = 'disable'
        client_key_entry['state'] = 'disable'
        multi_cert_check_checkbuttion['state'] = 'disable'
 

    show_result()
def multi_cert_check():
    global g_multi_cert
    if multi_cert_check_v.get() == 1:
        multi_cert_entry['state'] = 'normal'
        g_multi_cert = True

    else:
        multi_cert_entry['state'] = 'disable'
        g_multi_cert = False

    show_result()
        
https_switch_v = IntVar() 
https_switch_v .set(0)
https_off_radio = Radiobutton(cert_frame, variable=https_switch_v, value=0, text='Disable', command=method_https_off)
https_normal_radio = Radiobutton(cert_frame, variable=https_switch_v, value=1, text='Standard_SSL', command=method_https_normal)
https_pyssl_radio = Radiobutton(cert_frame, variable=https_switch_v, value=2, text='PyOpenssl', command=method_https_pyssl)



check_ca_v = IntVar()
verify_server_checkbuttion = Checkbutton(cert_frame, text='CA', variable=check_ca_v, command=check_ca, state='disable')
ca_entry_v = StringVar()
ca_entry = Entry(cert_frame, textvariable=ca_entry_v, state='disable',width=15) 
ca_entry_v.set(s_ca_name)
ca_entry_v.trace('w', show_result)

verify_host_v = IntVar()
verify_host_checkbuttion = Checkbutton(cert_frame, text='Verify_Server_Domain_Name', variable=verify_host_v, command=check_host, state='disable')
check_client_cert_v = IntVar()
client_cert_checkbuttion = Checkbutton(cert_frame, text='Client_Cert', variable=check_client_cert_v, command=check_client_cert, state='disable')

client_cert_entry_v = StringVar()
client_cert_entry = Entry(cert_frame, width=15,textvariable=client_cert_entry_v , state='disable') 
client_cert_entry_v .set(s_client_cert)
client_cert_entry_v.trace('w', show_result)

client_key_entry_v = StringVar()
client_key_entry = Entry(cert_frame, width=15,textvariable=client_key_entry_v , state='disable') 
client_key_entry_v .set(s_client_key)
client_key_entry_v.trace('w', show_result)


multi_cert_check_v = IntVar()
multi_cert_check_checkbuttion = Checkbutton(cert_frame, text='Multi:',state='disable', variable=multi_cert_check_v, command=multi_cert_check)
multi_cert_v = StringVar()
multi_cert_entry = Entry(cert_frame, width=5,textvariable=multi_cert_v, state='disable') 
multi_cert_v.set('2')
multi_cert_v.trace('w', show_result)

def check_sslv2():
    global g_sslv2_bool
    if check_sslv2_v.get() == 1:
        g_sslv2_bool =  True
    else:
        g_sslv2_bool =  False
    show_result()

def check_sslv3():
    global g_sslv3_bool
    if check_sslv3_v.get() == 1:
        g_sslv3_bool =  True
    else:
        g_sslv3_bool =  False
    show_result()
    
def check_tlsv1():
    global g_tlsv1_bool
    if check_tlsv1_v.get() == 1:
        g_tlsv1_bool =  True
    else:
        g_tlsv1_bool =  False
    show_result()
def check_tlsv11():
    global g_tlsv11_bool
    if check_tlsv11_v.get() == 1:
        g_tlsv11_bool =  True
    else:
        g_tlsv11_bool =  False
    show_result()
def check_tlsv12():
    global g_tlsv12_bool
    if check_tlsv12_v.get() == 1:
        g_tlsv12_bool =  True
    else:
        g_tlsv12_bool =  False
    show_result()
check_sslv2_v = IntVar()
sslv2_checkbuttion = Checkbutton(cert_frame, text='SSLV2', variable=check_sslv2_v, command=check_sslv2, state='disable')


check_sslv3_v = IntVar()
sslv3_checkbuttion = Checkbutton(cert_frame, text='SSLV3', variable=check_sslv3_v, command=check_sslv3, state='disable')


check_tlsv1_v = IntVar()

tlsv1_checkbuttion = Checkbutton(cert_frame, text='TLSV1', variable=check_tlsv1_v, command=check_tlsv1, state='disable')

check_tlsv11_v = IntVar()
tlsv11_checkbuttion = Checkbutton(cert_frame, text='TLSV1_1', variable=check_tlsv11_v, command=check_tlsv11, state='disable')


check_tlsv12_v = IntVar()
tlsv12_checkbuttion = Checkbutton(cert_frame, text='TLSV1_2', variable=check_tlsv12_v, command=check_tlsv12, state='disable')

def check_ticket():
    global g_ticket_bool
    if check_ticket_v.get() ==1:
        g_ticket_bool =  True
    else:
        g_ticket_bool = False
    show_result()
def check_reuse():
    global g_ssl_reuse_bool
    if check_reuse_v.get() ==1:
        g_ssl_reuse_bool = False
        if g_onebyone_bool and not (int(session_number_entry.get().strip()) > 1):
            showinfo("Setting config prompt", "Please set 'Session_Number' in 'Necessary Parameter' > 1 firstly")
            check_reuse_v.set(0)
        elif not g_onebyone_bool and  (int(session_number_entry.get().strip()) > 1):
            showinfo("Setting config prompt", "Please enable 'One_over_next_start' in tab 'General' firstly")
            check_reuse_v.set(0)
        elif not g_onebyone_bool and  not (int(session_number_entry.get().strip()) > 1):
            showinfo("Setting config prompt", "Please enable 'One_over_next_start' in tab 'General', and  set 'Session_Number' in 'Necessary Parameter' > 1 firstly")
            check_reuse_v.set(0)
        else:
            g_ssl_reuse_bool =  True
    else:
        g_ssl_reuse_bool = False
    show_result()

def check_sni():
    global g_sni_bool
    if check_sni_v.get() ==1:
        g_sni_bool =  True
    else:
        g_sni_bool = False
    show_result()
check_sni_v = IntVar()
sni_checkbuttion = Checkbutton(cert_frame, text='SNI', variable=check_sni_v, command=check_sni, state='disable')

check_reuse_v = IntVar()
reuse_checkbuttion = Checkbutton(cert_frame, text='SSL_ID_Reuse', variable=check_reuse_v, command=check_reuse, state='disable')

check_ticket_v = IntVar()
ticket_checkbuttion = Checkbutton(cert_frame, text='Ticket', variable=check_ticket_v, command=check_ticket, state='disable')

def check_encryp():
    global g_encryp_bool
    if check_encryp_v.get() == 1:
        g_encryp_bool = True
        encryp_text['state'] = 'normal'
        ciphers_combo['state'] = 'readonly'
    else:
        g_encryp_bool = False
        encryp_text['state'] = 'disable'
        ciphers_combo['state'] = 'disable'
    show_result()
        
    


def change_cipher(event):
    if event.widget.current(): # value #0 is not a theme
        ciphers = event.widget.get()
        if '--' not in ciphers:
            old_cmd = encryp_text.get(1.0, END)
            old_cmd = old_cmd[:-1]
            if old_cmd.endswith('\n'):
            
                new_cmd = old_cmd + ciphers
            else:
                if len(old_cmd.strip()) > 2:
                    new_cmd = old_cmd + ':' + ciphers
                else:
                    new_cmd = ciphers
          
            encryp_text.delete(1.0, END)
    
            encryp_text.insert(1.0, new_cmd)
            show_result()
        # change to the new theme and refresh all the widgets
def get_cipher_list():
    
    encrypt_common,error = Popen('openssl ciphers',shell=True,stdout=PIPE).communicate()
    encrypt_enull,error = Popen('openssl ciphers eNULL',shell=True,stdout=PIPE).communicate()
    encrypt_anull,error = Popen('openssl ciphers aNULL',shell=True,stdout=PIPE).communicate()
    return ['LOW','MEDIUM','HIGH'] + encrypt_common.split(':') + ['--------------------eNULL/NULL--------------------'] + ['NULL'] + encrypt_enull.split(':')  + ['--------------------aNULL--------------------'] + ['aNULL'] + encrypt_anull.split(':')
    
ciphers = get_cipher_list()
ciphers.insert(0, "---------The common cipher----------")
ciphers_combo = ttk.Combobox(cert_frame,values=ciphers, state='disable',
                            height=10,width=59)
ciphers_combo.set(ciphers[0])

ciphers_combo.bind("<<ComboboxSelected>>", change_cipher)

check_encryp_v = IntVar()
encryp_checkbuttion = Checkbutton(cert_frame, text='Encryption',state='disable', variable=check_encryp_v, command=check_encryp)

encryp_text= Text(cert_frame, width=41, height=8,state='disable')
#pre_encryp = ""
#encryp_text.insert(1.0, pre_encryp)
encryp_text.bind('<Return>', show_result)

https_off_radio.grid(row=0, column=0, sticky='w',columnspan=2)
https_normal_radio.grid(row=0, column=2, sticky='w',columnspan=2)
https_pyssl_radio.grid(row=0, column=4, sticky='w',columnspan=1)
verify_server_checkbuttion.grid(row=2, column=0, sticky='w')
ca_entry.grid(row=2, column=1, sticky='w')
verify_host_checkbuttion.grid(row=2, column=2,columnspan=3, sticky='w')
client_cert_checkbuttion.grid(row=3, column=0, sticky='w')
client_cert_entry.grid(row=3, column=1, sticky='w')
client_key_entry.grid(row=3, column=2, sticky='w')
multi_cert_check_checkbuttion.grid(row=3, column=3,  sticky='w')
multi_cert_entry.grid(row=3, column=4, sticky='w')
sslv2_checkbuttion.grid(row=4, column=0, sticky='w')
sslv3_checkbuttion.grid(row=4, column=1, sticky='w')
tlsv1_checkbuttion.grid(row=4, column=2, sticky='w')
tlsv11_checkbuttion.grid(row=4, column=3, sticky='w')
tlsv12_checkbuttion.grid(row=4, column=4,sticky='w')
sni_checkbuttion.grid(row=5, column=0, sticky='w')
reuse_checkbuttion.grid(row=5, column=1, sticky='w')
ticket_checkbuttion.grid(row=5, column=2, sticky='w')
encryp_checkbuttion.grid(row=6, column=0, sticky='w')
ciphers_combo.grid(row=6, column=1,columnspan=4, sticky='w')
encryp_text.grid(row=0,column=5,rowspan=7, sticky='w')










persistence_frame = Frame()
def check_real_cookie(): 
    global g_real_cookie
    if real_cookie_check_v.get() == 1:
        g_real_cookie = True    
    else:
        g_real_cookie = False
    show_result()
    
def check_hashquery(): 
    global g_hash_query 
    if hashquery_check_v.get() == 1:
        g_hash_query = True
        hashquery_key_entry['state'] = 'normal'  
        hashquery_value_entry['state'] = 'normal'        
    else:
        g_hash_query = False
        hashquery_key_entry['state'] = 'disable'  
        hashquery_value_entry['state'] = 'disable'
    show_result() 
def check_hashheader(): 
    global g_hash_header
    if hashheader_check_v.get() == 1:
        g_hash_header = True
        hashheader_key_entry['state'] = 'normal'  
        hashheader_value_entry['state'] = 'normal'        
    else:
        g_hash_header = False
        hashheader_key_entry['state'] = 'disable'  
        hashheader_value_entry['state'] = 'disable'  
    show_result()     

def check_hashcookie_fix():
    global g_fix_cookie
    if hashcookie_fix_check_v.get() == 1:
        g_fix_cookie = True
        hashcookie_fix_combo['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_fix_cookie = False
        hashcookie_fix_combo['state'] = 'disable'
    show_result()

def check_hashcookie(): 
    global g_hash_cookie, g_fix_cookie
    if hashcookie_check_v.get() == 1:
        g_hash_cookie = True
        hashcookie_key_entry['state'] = 'normal'  
        hashcookie_value_entry['state'] = 'normal'
        hashcookie_fix_checkbuttion['state'] = 'normal' 
        if hashcookie_fix_check_v.get() == 1:
            g_fix_cookie = True
            hashcookie_fix_combo['state'] = 'normal'
             
    else:
        g_hash_cookie = False
        g_fix_cookie = False
        hashcookie_key_entry['state'] = 'disable'  
        hashcookie_value_entry['state'] = 'disable'
        hashcookie_fix_checkbuttion['state'] = 'disable'
        hashcookie_fix_combo['state'] = 'disable'
    show_result()

cookie_fix_value = ''
def change_fix(event):
    global cookie_fix_value
    if event.widget.current(): # value #0 is not a theme
        cookie_fix_value = event.widget.get()
    else:
        cookie_fix_value = ''
    show_result()
hashcookie_check_v = IntVar()
hashcookie_checkbuttion = Checkbutton(persistence_frame, text='Hash_Cookie', variable=hashcookie_check_v, command=check_hashcookie)

hashcookie_key_entry_v = StringVar()
hashcookie_key_entry = Entry(persistence_frame, textvariable=hashcookie_key_entry_v, state='disable') 
hashcookie_key_entry_v.set(s_cookie_key)
hashcookie_key_entry_v.trace('w', show_result)

hashcookie_value_entry_v = StringVar()
hashcookie_value_entry = Entry(persistence_frame, textvariable=hashcookie_value_entry_v, state='disable') 
hashcookie_value_entry_v.set(s_cookie_value)
hashcookie_value_entry_v.trace('w', show_result)

hashcookie_fix_check_v = IntVar()
hashcookie_fix_checkbuttion = Checkbutton(persistence_frame, state='disable', text='Fix_Prefix_Value', variable=hashcookie_fix_check_v, command=check_hashcookie_fix)

hashcookie_fix_list = ['fix-prefix', 'fix-suffix']

hashcookie_fix_list.insert(0, "None")
hashcookie_fix_combo = ttk.Combobox(persistence_frame,values=hashcookie_fix_list, state='disable',width=7)
hashcookie_fix_combo.set(hashcookie_fix_list[0])

hashcookie_fix_combo.bind("<<ComboboxSelected>>", change_fix)
#hashcookie_fix_list_v = StringVar()
#hashcookie_fix_list_v.set('')
#hashcookie_fix_list_menu = apply(OptionMenu, (persistence_frame, hashcookie_fix_list_v) + tuple(hashcookie_fix_list))
#hashcookie_fix_list_menu['state'] = 'disable'
#hashcookie_fix_list_v.trace('w', show_result)


hashquery_check_v = IntVar()
hashquery_checkbuttion = Checkbutton(persistence_frame, text='Hash_Query', variable=hashquery_check_v, command=check_hashquery)

hashquery_key_entry_v = StringVar()
hashquery_key_entry = Entry(persistence_frame, textvariable=hashquery_key_entry_v, state='disable') 
hashquery_key_entry_v.set(s_query_key)
hashquery_key_entry_v.trace('w', show_result)

hashquery_value_entry_v = StringVar()
hashquery_value_entry = Entry(persistence_frame, textvariable=hashquery_value_entry_v, state='disable') 
hashquery_value_entry_v.set(s_query_value)
hashquery_value_entry_v.trace('w', show_result)

hashheader_check_v = IntVar()
hashheader_checkbuttion = Checkbutton(persistence_frame, text='Hash_Header', variable=hashheader_check_v, command=check_hashheader)

hashheader_key_entry_v = StringVar()
hashheader_key_entry = Entry(persistence_frame, textvariable=hashheader_key_entry_v, state='disable') 
hashheader_key_entry_v.set(s_header_key)
hashheader_key_entry_v.trace('w', show_result)


hashheader_value_entry_v = StringVar()
hashheader_value_entry = Entry(persistence_frame, textvariable=hashheader_value_entry_v, state='disable') 
hashheader_value_entry_v.set(s_header_value)
hashheader_value_entry_v.trace('w', show_result)


real_cookie_check_v = IntVar()
real_cookie_checkbuttion = Checkbutton(persistence_frame, text='Real_Cookie', variable=real_cookie_check_v, command=check_real_cookie)


hashcookie_checkbuttion.grid(row=0, column=0, sticky='w')
hashcookie_key_entry.grid(row=0, column=1, sticky='w')
hashcookie_value_entry.grid(row=0, column=2, sticky='w')
hashcookie_fix_checkbuttion.grid(row=0, column=3, sticky='w')
hashcookie_fix_combo.grid(row=0, column=4, sticky='w')
hashquery_checkbuttion.grid(row=1, column=0, sticky='w')
hashquery_key_entry.grid(row=1, column=1, sticky='w')
hashquery_value_entry.grid(row=1, column=2, sticky='w')
hashheader_checkbuttion.grid(row=2, column=0, sticky='w')
hashheader_key_entry.grid(row=2, column=1, sticky='w')
hashheader_value_entry.grid(row=2, column=2, sticky='w')
real_cookie_checkbuttion.grid(row=3, column=0, sticky='w')








def cache_debug():
    global g_cache_debug_bool
    if debug_cache_v.get() == 1:

        g_cache_debug_bool = True
    else:
 
        g_cache_debug_bool = False
    show_result()
def sniffer_cache_check():
    global g_cache_bool,g_cache_debug_bool
    if cache_check_v.get() == 1:
        g_cache_bool = True      
        adcip_entry['state'] = 'normal'
        adcport_entry['state'] = 'normal'
        sniffer_entry['state'] = 'normal'
        debug_cache_checkbuttion['state'] = 'normal'
        if  debug_cache_v.get() == 1:
            g_cache_debug_bool = True
    else:
        g_cache_bool= False
        adcip_entry['state'] = 'disable'
        adcport_entry['state'] = 'disable'
        sniffer_entry['state'] = 'disable'
        if random_cache_v.get() == 0:
            debug_cache_checkbuttion['state'] = 'disable'
            g_cache_debug_bool = False
    show_result() 



cache_frame = Frame()
cache_check_v = IntVar()
cache_check_checkbuttion = Checkbutton(cache_frame, text='Sniffer_Mode:', variable=cache_check_v, command=sniffer_cache_check)

adcip_entry_v = StringVar()
adcip_entry = Entry(cache_frame,width=36,textvariable=adcip_entry_v, state='disable') 
adcip_entry_v.set(s_cache_ip)
adcip_entry_v.trace('w', show_result)

adcport_entry_v = StringVar()
adcport_entry = Entry(cache_frame, textvariable=adcport_entry_v,state='disable') 
adcport_entry_v.set(s_cache_port)
adcport_entry_v.trace('w', show_result)



sniffer_entry_v = StringVar()
sniffer_entry = Entry(cache_frame, width=32,textvariable=sniffer_entry_v, state='disable') 
sniffer_entry_v.set(s_sniffer_key)
sniffer_entry_v.trace('w', show_result)


def random_cache_check():
    global g_random_cache_bool,g_custom_header_bool,g_random_expire_bool,g_cache_debug_bool
    if random_cache_v.get() == 1:
        g_random_cache_bool = True   
        cache_expire_checkbuttion['state'] = 'normal'
        cache_custom_head_checkbuttion['state'] = 'normal'
        debug_cache_checkbuttion['state'] = 'normal'
        load_file_cache_checkbuttion['state'] = 'normal'
        if cache_custom_head_check_v.get() == 1:
            g_custom_header_bool= True
            cache_custom_head_entry['state'] = 'normal'  

        if load_file_cache_v.get() == 1:
            g_load_file_bool = True 
            g_random_expire_bool = False
            cache_expire_entry['state'] = 'disable'
        else:
            if cache_expire_check_v.get() == 1:
                g_random_expire_bool = True
                cache_expire_entry['state'] = 'normal'
        if debug_cache_v.get() == 1:
            g_cache_debug_bool = True
    else:
        g_random_cache_bool,g_custom_header_bool,g_random_expire_bool = False,False,False  
        cache_expire_checkbuttion['state'] = 'disable'
        cache_custom_head_checkbuttion['state'] = 'disable'
        load_file_cache_checkbuttion['state'] = 'disable'
        cache_custom_head_entry['state'] = 'disable'
        cache_expire_entry['state'] = 'disable'
        if cache_check_v.get() == 0:
            debug_cache_checkbuttion['state'] = 'disable'
            g_cache_debug_bool = False
    show_result() 
def custom_random_header():
    global g_custom_header_bool
    if cache_custom_head_check_v.get() == 1:
        g_custom_header_bool= True
        cache_custom_head_entry['state'] = 'normal'
    else:
        g_custom_header_bool = False
        cache_custom_head_entry['state'] = 'disable'
    show_result()
def random_expire_time():
    global g_random_expire_bool
    if cache_expire_check_v.get() == 1:
        g_random_expire_bool = True
        cache_expire_entry['state'] = 'normal'
    else:
        g_random_expire_bool = False
        cache_expire_entry['state'] = 'disable'
    show_result()
def load_cache_file():
    global g_load_file_bool,g_random_expire_bool
    if load_file_cache_v.get() == 1:
        g_load_file_bool = True
        g_random_expire_bool = False
        cache_expire_checkbuttion['state'] = 'disable'
        cache_expire_entry['state'] = 'disable'
        cache_expire_check_v.set(0)
    else:
        g_load_file_bool = False
        cache_expire_checkbuttion['state'] = 'normal'
        if cache_expire_check_v.get() == 1:
            g_random_expire_bool = True
            cache_expire_entry['state'] = 'normal'
    show_result()
 
      
random_cache_v = IntVar()
random_cache_checkbuttion = Checkbutton(cache_frame, text='Random_mode:', variable=random_cache_v, command=random_cache_check)


cache_custom_head_check_v = IntVar()
cache_custom_head_checkbuttion = Checkbutton(cache_frame, state='disable',text='Custom_header:', variable=cache_custom_head_check_v, command=custom_random_header)
cache_custom_head_entry_v = StringVar()
cache_custom_head_entry = Entry(cache_frame, state='disable',textvariable=cache_custom_head_entry_v) 
cache_custom_head_entry_v.set(s_custom_cache_header)
cache_custom_head_entry_v.trace('w', show_result)

load_file_cache_v = IntVar()
load_file_cache_checkbuttion = Checkbutton(cache_frame, state='disable',text='No_load_previous_cache', variable=load_file_cache_v, command=load_cache_file)

cache_expire_check_v = IntVar()
cache_expire_checkbuttion = Checkbutton(cache_frame, state='disable',text='Expire_Interval:', variable=cache_expire_check_v, command=random_expire_time)
cache_expire_entry_v = StringVar()
cache_expire_entry = Entry(cache_frame, state='disable', width=10,textvariable=cache_expire_entry_v) 
cache_expire_entry_v.set('86400')
cache_expire_entry_v.trace('w', show_result)


debug_cache_v = IntVar()
debug_cache_checkbuttion = Checkbutton(cache_frame, state='disable',height=2,text='Cache_Debug', variable=debug_cache_v, command=cache_debug)


random_cache_checkbuttion.grid(row=0, column=0, sticky='w')
cache_custom_head_checkbuttion.grid(row=0, column=1,sticky='w')
cache_custom_head_entry.grid(row=0, column=2, sticky='w')

cache_expire_checkbuttion.grid(row=0, column=3, sticky='w')
cache_expire_entry.grid(row=0, column=4, sticky='w')
load_file_cache_checkbuttion.grid(row=0, column=5, sticky='w')
debug_cache_checkbuttion.grid(row=0, column=6,rowspan=2, sticky='w')



cache_check_checkbuttion.grid(row=1, column=0, sticky='w')
adcip_entry.grid(row=1, column=1, columnspan=2, sticky='w')
adcport_entry.grid(row=1, column=3, sticky='w')
sniffer_entry.grid(row=1, column=4,columnspan=2, sticky='w')
debug_cache_checkbuttion.grid(row=2, column=0,sticky='w')



http_constraint_frame = Frame()
def check_max_url_len():
    global g_max_url_len_bool
    if max_url_v.get() == 1:
        g_max_url_len_bool = True
        max_url_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_url_len_bool = False
        max_url_entry['state'] = 'disable'
    show_result()


max_url_v = IntVar()
max_url_checkbuttion = Checkbutton(http_constraint_frame, text='URL_Length', variable=max_url_v, command=check_max_url_len)

max_url_entry_url_v = StringVar()
max_url_entry = Entry(http_constraint_frame, textvariable=max_url_entry_url_v, state='disable', width=10) 
max_url_entry_url_v.set('10')
max_url_entry_url_v.trace('w', show_result)

def check_legal_host():
    global g_legal_host_bool
    if legal_host_v.get() == 1:
        g_legal_host_bool = True
        legal_host_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_legal_host_bool = False
        legal_host_entry['state'] = 'disable'
    show_result()
legal_host_v = IntVar()
legal_host_checkbuttion = Checkbutton(http_constraint_frame, text='Illegal_Hostname', variable=legal_host_v, command=check_legal_host)

legal_host_entry_url_v = StringVar()
legal_host_entry = Entry(http_constraint_frame, textvariable=legal_host_entry_url_v, state='disable', width=40) 
legal_host_entry_url_v.set('$%^.com')
legal_host_entry_url_v.trace('w', show_result)

def check_http_version():
    global g_http_version_bool
    if http_version_v.get() == 1:
        g_http_version_bool = True
        http_version_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_http_version_bool = False
        http_version_entry['state'] = 'disable'
    show_result()
http_version_v = IntVar()
http_version_checkbuttion = Checkbutton(http_constraint_frame, text='HTTP_Version', variable=http_version_v, command=check_http_version)

http_version_entry_url_v = StringVar()
http_version_entry = Entry(http_constraint_frame, textvariable=http_version_entry_url_v, state='disable', width=10) 
http_version_entry_url_v.set('1.1')
http_version_entry_url_v.trace('w', show_result)

def check_max_cookie_num():
    global g_max_cookie_num_bool
    if max_cookie_num_v.get() == 1:
        g_max_cookie_num_bool = True
        max_cookie_num_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_cookie_num_bool = False
        max_cookie_num_entry['state'] = 'disable'
    show_result()
max_cookie_num_v = IntVar()
max_cookie_num_checkbuttion = Checkbutton(http_constraint_frame, text='Cookie_Num', variable=max_cookie_num_v, command=check_max_cookie_num)

max_cookie_num_entry_url_v = StringVar()
max_cookie_num_entry = Entry(http_constraint_frame, textvariable=max_cookie_num_entry_url_v, state='disable', width=10) 
max_cookie_num_entry_url_v.set('10')
max_cookie_num_entry_url_v.trace('w', show_result)


def check_max_header_num():
    global g_max_header_num_bool
    if max_header_num_v.get() == 1:
        g_max_header_num_bool = True
        max_header_num_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_header_num_bool = False
        max_header_num_entry['state'] = 'disable'
    show_result()
max_header_num_v = IntVar()
max_header_num_checkbuttion = Checkbutton(http_constraint_frame, text='Header_Num', variable=max_header_num_v, command=check_max_header_num)

max_header_num_entry_url_v = StringVar()
max_header_num_entry = Entry(http_constraint_frame, textvariable=max_header_num_entry_url_v, state='disable', width=10) 
max_header_num_entry_url_v.set('10')
max_header_num_entry_url_v.trace('w', show_result)

def check_max_header_name():
    global g_max_header_name_bool
    if max_header_name_v.get() == 1:
        g_max_header_name_bool = True
        max_header_name_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_header_name_bool = False
        max_header_name_entry['state'] = 'disable'
    show_result()
max_header_name_v = IntVar()
max_header_name_checkbuttion = Checkbutton(http_constraint_frame, text='Header_Name_Length', variable=max_header_name_v, command=check_max_header_name)

max_header_name_entry_url_v = StringVar()
max_header_name_entry = Entry(http_constraint_frame, textvariable=max_header_name_entry_url_v, state='disable', width=10) 
max_header_name_entry_url_v.set('10')
max_header_name_entry_url_v.trace('w', show_result)

def check_max_header_value():
    global g_max_header_value_bool
    if max_header_value_v.get() == 1:
        g_max_header_value_bool = True
        max_header_value_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_header_value_bool = False
        max_header_value_entry['state'] = 'disable'
    show_result()
max_header_value_v = IntVar()
max_header_value_checkbuttion = Checkbutton(http_constraint_frame, text='Header_Value_Length', variable=max_header_value_v, command=check_max_header_value)

max_header_value_entry_url_v = StringVar()
max_header_value_entry = Entry(http_constraint_frame, textvariable=max_header_value_entry_url_v, state='disable', width=10) 
max_header_value_entry_url_v.set('10')
max_header_value_entry_url_v.trace('w', show_result)
def check_max_url_name():
    global g_max_url_name_bool
    if max_url_name_v.get() == 1:
        g_max_url_name_bool = True
        max_url_name_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_url_name_bool = False
        max_url_name_entry['state'] = 'disable'
    show_result()
max_url_name_v = IntVar()
max_url_name_checkbuttion = Checkbutton(http_constraint_frame, text='URL_Name_Length', variable=max_url_name_v, command=check_max_url_name)

max_url_name_entry_url_v = StringVar()
max_url_name_entry = Entry(http_constraint_frame, textvariable=max_url_name_entry_url_v, state='disable', width=10) 
max_url_name_entry_url_v.set('10')
max_url_name_entry_url_v.trace('w', show_result)


def check_max_url_value():
    global g_max_url_value_bool
    if max_url_value_v.get() == 1:
        g_max_url_value_bool = True
        max_url_value_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_url_value_bool = False
        max_url_value_entry['state'] = 'disable'
    show_result()
max_url_value_v = IntVar()
max_url_value_checkbuttion = Checkbutton(http_constraint_frame, text='URL_Value_Length', variable=max_url_value_v, command=check_max_url_value)

max_url_value_entry_url_v = StringVar()
max_url_value_entry = Entry(http_constraint_frame, textvariable=max_url_value_entry_url_v, state='disable', width=10) 
max_url_value_entry_url_v.set('10')
max_url_value_entry_url_v.trace('w', show_result)


def check_max_request_header():
    global g_max_request_header_bool
    if max_request_header_v.get() == 1:
        g_max_request_header_bool = True
        max_request_header_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_request_header_bool = False
        max_request_header_entry['state'] = 'disable'
    show_result()
max_request_header_v = IntVar()
max_request_header_checkbuttion = Checkbutton(http_constraint_frame, text='Request_header_Length', variable=max_request_header_v, command=check_max_request_header)

max_request_header_entry_url_v = StringVar()
max_request_header_entry = Entry(http_constraint_frame, textvariable=max_request_header_entry_url_v, state='disable', width=10) 
max_request_header_entry_url_v.set('10:5')
max_request_header_entry_url_v.trace('w', show_result)


def check_max_request_body():
    global g_max_request_body_bool
    if max_request_body_v.get() == 1:
        g_max_request_body_bool = True
        max_request_body_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_max_request_body_bool = False
        max_request_body_entry['state'] = 'disable'
    show_result()
max_request_body_v = IntVar()
max_request_body_checkbuttion = Checkbutton(http_constraint_frame, text='Request_body_Length', variable=max_request_body_v, command=check_max_request_body)

max_request_body_entry_url_v = StringVar()
max_request_body_entry = Entry(http_constraint_frame, textvariable=max_request_body_entry_url_v, state='disable', width=10) 
max_request_body_entry_url_v.set('10')
max_request_body_entry_url_v.trace('w', show_result)





max_url_checkbuttion.grid(row=0, column=0, sticky='w')
max_url_entry.grid(row=0, column=1, sticky='w')
legal_host_checkbuttion.grid(row=0, column=2, sticky='w')
legal_host_entry.grid(row=0, column=3, columnspan=3,sticky='w')
http_version_checkbuttion.grid(row=1, column=0, sticky='w')
http_version_entry.grid(row=1, column=1, sticky='w')

max_cookie_num_checkbuttion.grid(row=1, column=2, sticky='w')
max_cookie_num_entry.grid(row=1, column=3, sticky='w')
max_header_num_checkbuttion.grid(row=1, column=4, sticky='w')
max_header_num_entry.grid(row=1, column=5, sticky='w')
max_header_name_checkbuttion.grid(row=2, column=0, sticky='w')
max_header_name_entry.grid(row=2, column=1, sticky='w')
max_header_value_checkbuttion.grid(row=2, column=2, sticky='w')
max_header_value_entry.grid(row=2, column=3, sticky='w')


max_url_name_checkbuttion.grid(row=2, column=4, sticky='w')
max_url_name_entry.grid(row=2, column=5, sticky='w')
max_url_value_checkbuttion.grid(row=3, column=0, sticky='w')
max_url_value_entry.grid(row=3, column=1, sticky='w')
max_request_header_checkbuttion.grid(row=3, column=2, sticky='w')
max_request_header_entry.grid(row=3, column=3, sticky='w')
max_request_body_checkbuttion.grid(row=3, column=4, sticky='w')
max_request_body_entry.grid(row=3, column=5, sticky='w')






sql_xss_frame = Frame()

def sql_check():
    global g_sql_bool,g_xss_bool
    if sql_injection_v.get() == 1:
        g_sql_bool= True
        g_xss_bool= False
        xss_injection_v.set(0)
        sql_injection_entry['state'] = 'normal'
        sql_url_injection_checkbuttion['state'] = 'normal'
        sql_referer_injection_checkbuttion['state'] = 'normal'
        sql_cookie_injection_checkbuttion['state'] = 'normal'
        sql_body_injection_checkbuttion['state'] = 'normal'
        xss_injection_entry['state'] = 'disable'
        xss_url_injection_checkbuttion['state'] = 'disable'
        xss_referer_injection_checkbuttion['state'] = 'disable'
        xss_cookie_injection_checkbuttion['state'] = 'disable'
        xss_body_injection_checkbuttion['state'] = 'disable'
                
    else:
        g_sql_bool= False
        sql_injection_entry['state'] = 'disable'
        sql_url_injection_checkbuttion['state'] = 'disable'
        sql_referer_injection_checkbuttion['state'] = 'disable'
        sql_cookie_injection_checkbuttion['state'] = 'disable'
        sql_body_injection_checkbuttion['state'] = 'disable'
        xss_injection_entry['state'] = 'disable'
        xss_url_injection_checkbuttion['state'] = 'disable'
        xss_referer_injection_checkbuttion['state'] = 'disable'
        xss_cookie_injection_checkbuttion['state'] = 'disable'
        xss_body_injection_checkbuttion['state'] = 'disable'
        
    show_result()
    
def check_sql_url():
    global g_sql_url_bool
    if sql_url_injection_v.get() == 1:
        g_sql_url_bool = True
    else:
        g_sql_url_bool = False
    show_result()
def check_sql_referer():
    global g_sql_referer_bool
    if sql_referer_injection_v.get() == 1:
        g_sql_referer_bool = True
    else:
        g_sql_referer_bool = False
    show_result()
def check_sql_cookie():
    global g_sql_cookie_bool
    if sql_cookie_injection_v.get() == 1:
        g_sql_cookie_bool = True
    else:
        g_sql_cookie_bool = False
    show_result()
def check_sql_body():
    global g_sql_body_bool
    if sql_body_injection_v.get() == 1:
        g_sql_body_bool = True
    else:
        g_sql_body_bool = False
    show_result()

sql_frame = LabelFrame(sql_xss_frame,text='SQL Injection')
sql_injection_v = IntVar()
sql_injection_checkbuttion = Checkbutton(sql_frame, text='SQL Pattern:', variable=sql_injection_v, command=sql_check)

sql_injection_entry_v = StringVar()
sql_injection_entry = Entry(sql_frame, textvariable=sql_injection_entry_v, state='disable', width=40) 
sql_injection_entry_v.set(s_sql_str)
sql_injection_entry_v.trace('w', show_result)

sql_url_injection_v = IntVar()
sql_url_injection_checkbuttion = Checkbutton(sql_frame, text='URL', variable=sql_url_injection_v,state='disable', command=check_sql_url)

sql_referer_injection_v = IntVar()
sql_referer_injection_checkbuttion = Checkbutton(sql_frame, text='Referer', variable=sql_referer_injection_v,state='disable', command=check_sql_referer)

sql_cookie_injection_v = IntVar()
sql_cookie_injection_checkbuttion = Checkbutton(sql_frame, text='Cookie', variable=sql_cookie_injection_v,state='disable', command=check_sql_cookie)

sql_body_injection_v = IntVar()
sql_body_injection_checkbuttion = Checkbutton(sql_frame, text='Body', variable=sql_body_injection_v, state='disable',command=check_sql_body)

sql_injection_checkbuttion.grid(row=0, column=0, sticky='w')
sql_injection_entry.grid(row=0, column=1, sticky='w')
sql_url_injection_checkbuttion.grid(row=1, column=0, sticky='w')
sql_referer_injection_checkbuttion.grid(row=2, column=0, sticky='w')
sql_cookie_injection_checkbuttion.grid(row=3, column=0, sticky='w')
sql_body_injection_checkbuttion.grid(row=4, column=0, sticky='w')


xss_frame = LabelFrame(sql_xss_frame,text='XSS Injection')
def xss_check():
    global g_sql_bool,g_xss_bool
    if xss_injection_v.get() == 1:
        g_xss_bool= True
        g_sql_bool= False
        sql_injection_v.set(0)
        xss_injection_entry['state'] = 'normal'
        xss_url_injection_checkbuttion['state'] = 'normal'
        xss_referer_injection_checkbuttion['state'] = 'normal'
        xss_cookie_injection_checkbuttion['state'] = 'normal'
        xss_body_injection_checkbuttion['state'] = 'normal'
        sql_injection_entry['state'] = 'disable'
        sql_url_injection_checkbuttion['state'] = 'disable'
        sql_referer_injection_checkbuttion['state'] = 'disable'
        sql_cookie_injection_checkbuttion['state'] = 'disable'
        sql_body_injection_checkbuttion['state'] = 'disable'
                
    else:
        g_xss_bool= False
        sql_injection_entry['state'] = 'disable'
        sql_url_injection_checkbuttion['state'] = 'disable'
        sql_referer_injection_checkbuttion['state'] = 'disable'
        sql_cookie_injection_checkbuttion['state'] = 'disable'
        sql_body_injection_checkbuttion['state'] = 'disable'
        xss_injection_entry['state'] = 'disable'
        xss_url_injection_checkbuttion['state'] = 'disable'
        xss_referer_injection_checkbuttion['state'] = 'disable'
        xss_cookie_injection_checkbuttion['state'] = 'disable'
        xss_body_injection_checkbuttion['state'] = 'disable'
        
    show_result()

def check_xss_url():
    global g_xss_url_bool
    if xss_url_injection_v.get() == 1:
        g_xss_url_bool = True
    else:
        g_xss_url_bool = False
    show_result()
def check_xss_referer():
    global g_xss_referer_bool
    if xss_referer_injection_v.get() == 1:
        g_xss_referer_bool = True
    else:
        g_xss_referer_bool = False
    show_result()
def check_xss_cookie():
    global g_xss_cookie_bool
    if xss_cookie_injection_v.get() == 1:
        g_xss_cookie_bool = True
    else:
        g_xss_cookie_bool = False
    show_result()
def check_xss_body():
    global g_xss_body_bool
    if xss_body_injection_v.get() == 1:
        g_xss_body_bool = True
    else:
        g_xss_body_bool = False
    show_result()


xss_injection_v = IntVar()
xss_injection_checkbuttion = Checkbutton(xss_frame, text='XSS Pattern:', variable=xss_injection_v, command=xss_check)

xss_injection_entry_v = StringVar()
xss_injection_entry = Entry(xss_frame, textvariable=xss_injection_entry_v, state='disable', width=40) 
xss_injection_entry_v.set(s_xss_str)
xss_injection_entry_v.trace('w', show_result)
xss_url_injection_v = IntVar()
xss_url_injection_checkbuttion = Checkbutton(xss_frame, text='URL', variable=xss_url_injection_v, state='disable',command=check_xss_url)

xss_referer_injection_v = IntVar()
xss_referer_injection_checkbuttion = Checkbutton(xss_frame, text='Referer', variable=xss_referer_injection_v, state='disable',command=check_xss_referer)

xss_cookie_injection_v = IntVar()
xss_cookie_injection_checkbuttion = Checkbutton(xss_frame, text='Cookie', variable=xss_cookie_injection_v, state='disable',command=check_xss_cookie)

xss_body_injection_v = IntVar()
xss_body_injection_checkbuttion = Checkbutton(xss_frame, text='Body', variable=xss_body_injection_v, state='disable',command=check_xss_body)

xss_injection_checkbuttion.grid(row=0, column=0, sticky='w')
xss_injection_entry.grid(row=0, column=1, sticky='w')
xss_url_injection_checkbuttion.grid(row=1, column=0, sticky='w')
xss_referer_injection_checkbuttion.grid(row=2, column=0, sticky='w')
xss_cookie_injection_checkbuttion.grid(row=3, column=0, sticky='w')
xss_body_injection_checkbuttion.grid(row=4, column=0, sticky='w')


sql_frame.grid(row=0, column=0, sticky='w',padx=5,ipadx=5)
xss_frame.grid(row=0, column=1, sticky='w',padx=5,ipadx=5)






def close_state():
    global g_update_bool
    if not g_update_bool:
        output_text.insert("end",'\n' + '#' * 130 + '\n')
        output_text.see("end")
        global aa,pause_str
        aa.set('RUN')
        pause_str.set('Pause output')
        
        
        if key_ip_button['state'] =='normal':
            key_ip_button['state'] = 'disable'
        if key_query_button['state'] == 'normal':
            key_query_button['state'] = 'disable'
        if key_header_button['state'] == 'normal':
            key_header_button['state'] = 'disable'
        if key_cookie_button['state'] == 'normal':
            key_cookie_button['state'] = 'disable'
        if key_vip_button['state'] == 'normal':
            key_vip_button['state'] = 'disable'
        if key_fullnat_button['state'] == 'normal':
            key_fullnat_button['state'] = 'disable'
      #  if key_l2_src_button['state'] == 'normal':
        key_l2_src_button['state'] = 'disable'
       # if key_l2_dst_button['state'] == 'normal':
        key_l2_dst_button['state'] = 'disable'
        #if key_l2_src_dst_button['state'] == 'normal':
        key_l2_src_dst_button['state'] = 'disable'
        force_command_button["state"] = 'disable'
        pause_button["state"] = 'disable'
        if g_speed_bool:
            speedup_command_button['state'] = 'disable'
            speeddown_command_button['state'] = 'disable'
        update_button["state"] = 'normal'
    else:
        run_command_button['state'] = 'normal'
        force_command_button["state"] = 'disable'
        g_update_bool = False
        
        
    
            
        
    

def just_show():
    if g_update_bool:
        update_process.expect(EOF,timeout=None)
    else:
        cmd_process.expect(EOF,timeout=None)
    
    close_state()
    
#    force_command_button["state"] = 'disable'


        
def get_thread():
  #  run_thread = threading.Thread(target=just_show,args=(cmd_process,))
    run_thread = threading.Thread(target=just_show)
    return run_thread





other_function_frame = Frame()
def rs_ip_header_check(): 
    global g_rs_ip_header_bool
    if rs_ip_header_check_v.get() == 1:
        g_rs_ip_header_bool = True
        rs_ip_header_entry['state'] = 'normal'
    else:
        g_rs_ip_header_bool = False
        rs_ip_header_entry['state'] = 'disable'
    show_result()
    
def speed_check(): 
    global g_speed_bool
    if speed_check_v.get() == 1:
        g_speed_bool = True
        speed_user_entry['state'] = 'normal'
    else:
        g_speed_bool = False
        speed_user_entry['state'] = 'disable'
    show_result()
def check_noany():
    global g_no_print_all_bool
    if no_any_check_v.get() == 1:
        g_no_print_all_bool = True
    else:
        g_no_print_all_bool = False
    show_result()

def check_re():
    global g_cusum_re_bool
    if re_check_v.get() == 1:
        g_cusum_re_bool = True
        re_value_entry['state'] = 'normal'
    else:
        g_cusum_re_bool = False
        re_value_entry['state'] = 'disable'
    show_result()
rs_ip_header_check_v = IntVar()
rs_ip_header_check_checkbuttion = Checkbutton(other_function_frame, text='RS_IP_Header:', variable=rs_ip_header_check_v, command=rs_ip_header_check)
rs_ip_header_entry_v = StringVar()
rs_ip_header_entry = Entry(other_function_frame, width=30,state='disable', textvariable=rs_ip_header_entry_v) 
rs_ip_header_entry_v.set(s_rs_ip_header)
rs_ip_header_entry_v.trace('w', show_result)

speed_check_v = IntVar()
speed_check_checkbuttion = Checkbutton(other_function_frame, text='Speed-up/down-step:', variable=speed_check_v, command=speed_check)
speed_user_entry_v = StringVar()
speed_user_entry = Entry(other_function_frame, state='disable', width=10,textvariable=speed_user_entry_v) 
speed_user_entry_v.set('10')
speed_user_entry_v.trace('w', show_result)


re_check_v = IntVar()
re_checkbuttion = Checkbutton(other_function_frame, text='Custom_RE', variable=re_check_v, command=check_re)

re_value_entry_v = StringVar()
re_value_entry = Entry(other_function_frame, textvariable=re_value_entry_v, width=30,state='disable') 
re_value_entry_v.set(s_re_pattern)
re_value_entry_v.trace('w', show_result)


no_any_check_v = IntVar()
no_any_checkbuttion = Checkbutton(other_function_frame, text='No print anything', variable=no_any_check_v, command=check_noany)



def set_output_height():
   output_height_value = height_entry_v.get()
   if output_height_value.isdigit():
       output_text['height'] =  int(output_height_value)
       
       
    
set_height_button = Button(other_function_frame, text = 'Set_output_box_height',command=set_output_height)

height_entry_v = StringVar()
height_entry = Entry(other_function_frame, width=10,textvariable=height_entry_v) 
height_entry_v.set(output_text_height)


def check_client_timeout():
    global g_client_timeout_bool
    if client_timeout_v.get() == 1:
        g_client_timeout_bool = True
        client_timeout_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_client_timeout_bool = False
        client_timeout_entry['state'] = 'disable'
    show_result()
client_timeout_v = IntVar()
client_timeout_checkbuttion = Checkbutton(other_function_frame, text='Client_timeout', variable=client_timeout_v, command=check_client_timeout)

client_timeout_entry_v = StringVar()
client_timeout_entry = Entry(other_function_frame, textvariable=client_timeout_entry_v, state='disable', width=30) 
client_timeout_entry_v.set('2')
client_timeout_entry_v.trace('w', show_result)


def check_request_timeout():
    global g_request_timeout_bool
    if request_timeout_v.get() == 1:
        g_request_timeout_bool = True
        request_timeout_entry['state'] = 'normal'
    #    hashcookie_fix_list_menu['state'] = 'normal'
    else:
        g_request_timeout_bool = False
        request_timeout_entry['state'] = 'disable'
    show_result()
request_timeout_v = IntVar()
request_timeout_checkbuttion = Checkbutton(other_function_frame, text='Request_timeout', variable=request_timeout_v, command=check_request_timeout)

request_timeout_entry_v = StringVar()
request_timeout_entry = Entry(other_function_frame, textvariable=request_timeout_entry_v, state='disable', width=10) 
request_timeout_entry_v.set('3')
request_timeout_entry_v.trace('w', show_result)



def update():
    
        #run_command_button['state'] = 'disable'
        global update_process, g_update_bool
        write_ini()
        g_update_bool = True
        change_state() 
        update_cmd = 'http_test --update'
        output_text.insert("end",update_cmd + '\n')
        output_text.insert("end",'-' * 150 + '\n' )
        update_process = spawn(update_cmd,logfile= Std_redirector(output_text))
        
        get_thread().start()

       
update_button = Button(other_function_frame, width=10,text = 'update',command=update)

update_path_entry_v = StringVar()
update_path_entry = Entry(other_function_frame, width=30,textvariable=update_path_entry_v) 
#aaaa = Entry(other_function_frame, width=30,textvariable=update_path_entry_v)
update_path_entry_v.set(s_update_server_path)

#label_user_name = Label(other_function_frame, text='Update_user_pass:') 

update_user_entry_v = StringVar()
update_user_entry = Entry(other_function_frame,width=31,textvariable=update_user_entry_v) 
#bbbb = Entry(other_function_frame, width=19,textvariable=update_user_entry_v)
update_user_entry_v.set(s_update_user)

rs_ip_header_check_checkbuttion.grid(row=0, column=0, sticky='w')
rs_ip_header_entry.grid(row=0, column=1, sticky='w')
speed_check_checkbuttion.grid(row=0, column=2, sticky='w')
speed_user_entry.grid(row=0, column=3,sticky='w')
re_checkbuttion.grid(row=1, column=0, sticky='w')
re_value_entry.grid(row=1, column=1, sticky='w')
set_height_button.grid(row=1, column=2, sticky='w')
height_entry.grid(row=1, column=3,sticky='w')
client_timeout_checkbuttion.grid(row=2, column=0, sticky='w')
client_timeout_entry.grid(row=2, column=1, sticky='w')
request_timeout_checkbuttion.grid(row=2, column=2, sticky='w')
request_timeout_entry.grid(row=2, column=3, sticky='w')
no_any_checkbuttion.grid(row=3, column=0, sticky='w')
update_button.grid(row=4, column=0, sticky='w')
update_path_entry.grid(row=4, column=1,sticky='w')
#label_user_name.grid(row=3, column=2,sticky='w')
update_user_entry.grid(row=4, column=2,columnspan=2,sticky='w')

auth_frame = Frame()

def auth_radio():
    global g_no_auth_bool, g_single_user_bool, g_multi_user_bool
    if auth_v.get() == 0:
        g_no_auth_bool = True
        g_single_user_bool, g_multi_user_bool = False,False
        user_name_entry['state'] = 'disable'
        password_entry['state'] = 'disable'
        special_user_checkbuttion['state'] = 'disable'
        user_prefix_entry['state'] = 'disable'
        pass_prefix_entry['state'] = 'disable'
        user_num_entry['state'] = 'disable'
    elif auth_v.get() == 1:
        g_single_user_bool = True
        g_no_auth_bool,g_multi_user_bool = False,False
        user_name_entry['state'] = 'normal'
        password_entry['state'] = 'normal'
        special_user_checkbuttion['state'] = 'normal'
        user_prefix_entry['state'] = 'disable'
        pass_prefix_entry['state'] = 'disable'
        user_num_entry['state'] = 'disable'
    else:
        g_multi_user_bool = True
        g_no_auth_bool, g_single_user_bool = False,False
        user_name_entry['state'] = 'disable'
        password_entry['state'] = 'disable'
        special_user_checkbuttion['state'] = 'disable'
        user_prefix_entry['state'] = 'normal'
        pass_prefix_entry['state'] = 'normal'
        user_num_entry['state'] = 'normal'     

    show_result()
    
auth_v = IntVar() 
auth_v.set(0)
no_auth_radio = Radiobutton(auth_frame, variable=auth_v, value=0, text='Disable authentication', command=auth_radio) 
single_user_radio = Radiobutton(auth_frame, variable=auth_v, value=1, text='Single User mode', command=auth_radio)
multi_user_radio = Radiobutton(auth_frame, variable=auth_v, value=2, text='Multiple User mode', command=auth_radio)
label_user_name = Label(auth_frame, text='User_Name:') 
user_name_v = StringVar()
user_name_entry = Entry(auth_frame, width=20, state='disable',textvariable=user_name_v) 
user_name_v.set(s_user_name)
user_name_v.trace('w', show_result)

label_pass_name = Label(auth_frame, text='Password:') 
password_v = StringVar()
password_entry = Entry(auth_frame, width=20, state='disable',textvariable=password_v) 
password_v.set(s_password)
password_v.trace('w', show_result)
def check_brower_mode():
    global g_brower_bool
    from tkMessageBox import showinfo
    if special_user_check_v.get() == 1:
        g_brower_bool = False
        if g_onebyone_bool and not (int(session_number_entry.get().strip()) > 1):
            showinfo("Setting config prompt", "Please set 'Session_Number' in 'Necessary Parameter' > 1 firstly")
            special_user_check_v.set(0)
        elif not g_onebyone_bool and  (int(session_number_entry.get().strip()) > 1):
            showinfo("Setting config prompt", "Please enable 'One_over_next_start' in tab 'General' firstly")
            special_user_check_v.set(0)
        elif not g_onebyone_bool and  not (int(session_number_entry.get().strip()) > 1):
            showinfo("Setting config prompt", "Please enable 'One_over_next_start' in tab 'General', and  set 'Session_Number' in 'Necessary Parameter' > 1 firstly")
            special_user_check_v.set(0)
        else:
            g_brower_bool = True
    else:
        g_brower_bool = False
    show_result()   


    
special_user_check_v = IntVar()
special_user_checkbuttion = Checkbutton(auth_frame,  state='disable',text='Brower mode', variable=special_user_check_v, command=check_brower_mode)

label_user_prefix = Label(auth_frame, text='User_prefix:') 
user_prefix_v = StringVar()
user_prefix_entry = Entry(auth_frame, state='disable', width=20,textvariable=user_prefix_v) 
user_prefix_v.set(s_user_prefix)
user_prefix_v.trace('w', show_result)

label_pass_prefix = Label(auth_frame, text='Pass_prefix:') 
pass_prefix_v = StringVar()
pass_prefix_entry = Entry(auth_frame,  state='disable',width=20,textvariable=pass_prefix_v) 
pass_prefix_v.set(s_pass_prefix)
pass_prefix_v.trace('w', show_result)


label_user_num = Label(auth_frame, text='Multi:')
user_num_v = StringVar()
user_num_entry = Entry(auth_frame,width=5,  state='disable',textvariable=user_num_v) 
user_num_v.set(s_user_num)
user_num_v.trace('w', show_result)

no_auth_radio.grid(row=0, column=0, sticky='w')
single_user_radio.grid(row=1, column=0, sticky='w')
label_user_name.grid(row=1, column=1, sticky='w')
user_name_entry.grid(row=1, column=2, sticky='w')
label_pass_name.grid(row=1, column=3, sticky='w')
password_entry.grid(row=1, column=4, sticky='w')
special_user_checkbuttion.grid(row=1, column=5,columnspan=2, sticky='w')

multi_user_radio.grid(row=2, column=0, sticky='w')
label_user_prefix.grid(row=2, column=1, sticky='w')
user_prefix_entry.grid(row=2, column=2, sticky='w')
label_pass_prefix.grid(row=2, column=3, sticky='w')
pass_prefix_entry.grid(row=2, column=4, sticky='w')
label_user_num.grid(row=2, column=5, sticky='w')
user_num_entry.grid(row=2, column=6, sticky='w')


def check_header():
    global g_header_bool
    if header_check_v.get() == 1:
        g_header_bool = True
        header_text['state'] = 'normal'
        help_head =  '''
        
Some examples about http-header:

X-Forwarded-For:1.1.1.1
Referer: http://www.zjs.com
Host: rss.sina.com.cn
User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14
Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5
Accept-Language: zh-cn,zh;q=0.5
Accept-Encoding: gzip,deflate
Accept-Charset: gb2312,utf-8;q=0.7,*;q=0.7
Keep-Alive: 300
Connection: keep-alive
Cookie: mycookie1=rs1;mycookie2=rs2;mycookie3=rs3
If-Modified-Since: Sun, 01 Jun 2008 12:05:30 GMT
Cache-Control: max-age=0
'''
        output_text.insert("end",help_head)
    else:
        g_header_bool = False
        header_text['state'] = 'disable'
    show_result()

header_frame = Frame()
header_check_v = IntVar()
header_checkbuttion = Checkbutton(header_frame, text='Header:', variable=header_check_v, command=check_header)
header_text = Text(header_frame, width=113, height=7)
pre_header = "Host: rss.sina.com.cn\nUser-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.1"
header_text.insert(1.0, pre_header)
header_text.bind('<Return>', show_result)
header_text['state'] = 'disable'
header_text.grid(row=0, columnspan=2, sticky='w')

header_checkbuttion.grid(row=0, column=0, stick='w')
header_text.grid(row=1, column=0, stick='w')

result_txt = Text(root, height=1, width=cmd_text_width)

show_result()
from time import sleep,time
#def thread_run():
#    try:
#        show_result()
#        print '\n' + '#' * 130 + '\n'
#        print cmd
#        aaaa = Popen(cmd1,shell=True,stdin=PIPE)
#        sleep(5)
#        if aaaa.poll() is None:
#            aaaa.communicate(input='i')
#        sleep(5)
#        if aaaa.poll() is None:
#            aaaa.communicate(input='i')
#        print 'oooooooooooooooooooo' 
#        call(cmd, shell=True)
#    except KeyboardInterrupt:
#        print 'The GUI script is closed by manually'
# 


#from subprocess import Popen,PIPE
#from Queue import Queue
#my_queue = Queue(0)

def change_state():
    global aa
    force_command_button["state"] = 'normal'
    if not g_update_bool:
        pause_button["state"] = 'normal'
        update_button["state"] = 'disable'
        aa.set('CTRL+C')
        if g_l4_warm_bool or g_l7_warm_bool:
            if not g_disableip_bool:
                key_ip_button['state'] = 'normal'
            if g_hash_query:
                key_query_button['state'] = 'normal'
            if g_hash_header:
                key_header_button['state'] = 'normal'
            if g_hash_cookie or g_real_cookie:
                key_cookie_button['state'] = 'normal'
            if ('-' in port_v.get() or ',' in port_v.get()) or ('-' in server_name_v.get() or ',' in server_name_v.get()):
                key_vip_button['state'] = 'normal'
            if g_fullnat_bool:
                key_fullnat_button['state'] = 'normal'
                key_l2_src_button['state'] = 'normal'
                key_l2_dst_button['state'] = 'normal'
                key_l2_src_dst_button['state'] = 'normal'
        if g_cache_bool:
            key_cache_button['state'] = 'normal'
        if g_speed_bool:
            speedup_command_button['state'] = 'normal'
            speeddown_command_button['state'] = 'normal'
    else:
        run_command_button["state"] = 'disable'
        
        
        


last_time = time()
flag_bool = False
#blackhole = file('/dev/null','w')
def RunButton():
    global cmd_process,aa,last_time,flag_bool,my_logfile
    try:
        if aa.get() == 'RUN':
            flag_bool = True
            show_result()
            cmd = result_txt.get(1.0, END)
        #    sys.stdout = Std_redirector(output_text)
            output_text.insert("end",cmd.strip() + '\n')
            output_text.insert("end",'-' * 150 + '\n' )

            
            cmd_process = spawn(cmd,logfile= Std_redirector(output_text))
            change_state()    
            get_thread().start()
 
        elif aa.get() == 'CTRL+C':
            if cmd_process.isalive():
                if time() - last_time > 1:
                    cmd_process.sendcontrol('c')
                    last_time = time()

    except KeyboardInterrupt:
        close_state()
        print 'The GUI script is closed by manually'
    except  Exception, e:
        flag_bool = False
        close_state()
        print 'The GUI main meet a problem\n%s' % e
        
def restore_pause():
    global pause_str,my_logfile
    if pause_str.get() == 'Pause output':
        cmd_process.logfile = None
        pause_str.set('Restore output')
    else:
        cmd_process.logfile = Std_redirector(output_text)
        pause_str.set('Pause output')
def clear_text():
    output_text.delete(0.0,END)

def force_close():
    
    if not g_update_bool:
        if cmd_process.isalive():
            cmd_process.terminate(force=True)
            close_state()
    else:
        if update_process.isalive():
            update_process.sendcontrol('c')
#            sleep(0.5)
#            if update_process.isalive():
#                update_process.terminate(force=True)
            close_state()

def send_key_i():
    if cmd_process.isalive():
        cmd_process.send('i')

def send_key_q():
    if cmd_process.isalive():
        cmd_process.send('q')
def send_key_c():
    if cmd_process.isalive():
        cmd_process.send('c')
def send_key_h():
    if cmd_process.isalive():
        cmd_process.send('h')
def send_key_o():
    if cmd_process.isalive():
        cmd_process.send('o')
def send_key_u():
    if cmd_process.isalive():
        cmd_process.send('u')
def send_key_f():
    if cmd_process.isalive():
        cmd_process.send('f')
def send_key_d():
    if cmd_process.isalive():
        cmd_process.send('d')
#def send_key_t():
 #   if cmd_process.isalive():
  #      cmd_process.send('t')
def send_key_m():
    if cmd_process.isalive():
        cmd_process.send('m')
        
def send_key_1():
    if cmd_process.isalive():
        cmd_process.send('1')
def send_key_2():
    if cmd_process.isalive():
        cmd_process.send('2')
def send_key_3():
    if cmd_process.isalive():
        cmd_process.send('3')
def reset_config():
    #global g_no_print_time_bool
    global g_concurrent_bool,g_debug_all_bool,g_srcport_bool,g_l4_warm_bool,g_l7_warm_bool,g_l4_weight_bool,g_l7_weight_bool,g_timeout_bool
    global g_fullnat_bool,g_content_rewrite_bool
    global g_l2_src_dst_bool,g_l2_src_bool,g_l2_dst_bool,g_l2_session_bool
    
    session_number_v.set(s_session_num)
    request_number_v.set(s_req_num)
    port_v.set(80)
    session_how_to_v.set(0)
    g_concurrent_bool = True
    debug_all_v.set(0)
    g_debug_all_bool = False
    if sport_check_v.get() == 1:
        sport_check_v.set(0)
        g_srcport_bool = False
        sport_entry['state'] = 'disable'
        sport_reuse_check_checkbuttion['state'] = 'disable'
    warm_check_v.set(0)
    g_l4_warm_bool = False
    g_l7_warm_bool = False
    weight_check_v.set(0)
    g_l4_weight_bool = False
    g_l7_weight_bool = False
    content_rewrite_v.set(0)
    g_fullnat_bool = False
    fullnat_v.set(0)
    g_content_rewrite_bool = False
    l2_src_v.set(0)
    l2_dst_v.set(0)
    l2_src_dst_v.set(0)
    l2_session_v.set(0)
    g_l2_src_dst_bool = False
    g_l2_src_bool = False
    g_l2_dst_bool = False
    g_l2_session_bool = False
    
    
    if timeout_check_v.get() == 1:
        timeout_check_v.set(0)
        g_timeout_bool = False
        timeout_value_entry['state'] = 'disable'
#    if no_time_check_v.get() == 1:
#        no_time_check_v.set(0)
#        g_no_print_time_bool = False
    
#    if no_time_check_v.get() == 1:
#        no_time_check_v.set(0)
#        g_no_print_time_bool = False
    request_interval_v.set(s_interval)
    global g_onebyone_bool, g_middle_bool, g_reuse_bool
    g_onebyone_bool, g_middle_bool, g_reuse_bool = False, False, False
    interval_onebyone_entry['state'] = 'disable'
    interval_middle_entry['state'] = 'disable'
        
    global g_disableip_bool,g_randomip_bool, g_startip_bool, g_endip_bool, g_overip_bool, g_discontinus_bool,g_eth_bool,g_dst_ip_port_bool
    
    
    if g_randomip_bool or g_startip_bool or  g_discontinus_bool:
        ip_v.set(0)
        g_disableip_bool = True
        g_randomip_bool, g_startip_bool, g_endip_bool, g_overip_bool, g_discontinus_bool,g_eth_bool,g_dst_ip_port_bool = False,False, False, False, False, False, False
        random_num_entry['state'] = 'disable'
        range_ip_start_entry['state'] = 'disable'
        range_ip_end_entry['state'] = 'disable'
     #   check_end_ip_v.set(0)
        check_end_checkbuttion['state'] = 'disable'
        order_ip_checkbuttion['state'] = 'disable'
        ethname_checkbuttion['state'] = 'disable'
        if ethname_bool_v.get() == 1:
            ethname_list['state'] = 'disable'
        discontinuous_ip_entry['state'] = 'disable'
        ip_interval_entry['state'] = 'disable'
        check_random_dst_ip_port_checkbuttion['state'] = 'disable'
        check_random_dst_ip_port_v.set(0)
            
    global g_get_bool,g_post_bool,g_put_bool,g_delete_bool,g_head_bool,g_trace_bool,g_connect_bool,g_option_bool,g_url_weight_bool,zip_value,g_custom_method_bool
    get_method_v.set(0)
    
    g_get_bool = False
    compress_combo.set(compress_type[0])
    get_entry_url_v.set(s_get_url)

    get_url_entry['state'] = 'disable'
    post_method_v.set(0)
    post_url_entry['state'] = 'disable'
    g_post_bool = False
    post_user_pass_entry['state'] = 'disable'
    put_method_v.set(0)
    put_url_entry['state'] = 'disable'
    g_put_bool = False
    delete_method_v.set(0)
    delete_url_entry['state'] = 'disable'
    g_delete_bool = False
    
    
    head_method_v.set(0)
    head_url_entry['state'] = 'disable'
    g_head_bool = False
    trace_method_v.set(0)
    trace_url_entry['state'] = 'disable'
    g_trace_bool = False
    connect_method_v.set(0)
    connect_url_entry['state'] = 'disable'
    g_connect_bool = False
    
    option_method_v.set(0)
    option_url_entry['state'] = 'disable'
    g_option_bool = False
    
    custom_method_v.set(0)
    custom_url_entry['state'] = 'disable'
    g_custom_method_bool = False
    
    zip_combo.set(zip_list[0])
    zip_value = 'gzip and deflate'
    uri_account_check_v.set(0)
    g_url_weight_bool = False
    
    global g_ssl_disable,g_ssl_enable,g_ssl_verify,g_ssl_domain,g_ssl_client,g_pyopenssl
    https_switch_v .set(0)
    g_ssl_disable = True
    g_ssl_enable = False
    g_ssl_verify = False
    g_ssl_domain = False
    g_ssl_client = False
    g_pyopenssl = False
    multi_cert_check_checkbuttion['state'] = 'disable'
    multi_cert_entry['state'] = 'disable'
    verify_server_checkbuttion['state'] = 'disable'
    client_cert_checkbuttion ['state'] = 'disable'
    ca_entry ['state'] = 'disable'
    client_cert_entry['state'] = 'disable'
    client_key_entry['state'] = 'disable'
    verify_host_checkbuttion['state'] = 'disable'
    sslv2_checkbuttion['state'] = 'disable'
    sslv3_checkbuttion['state'] = 'disable'
    tlsv1_checkbuttion['state'] = 'disable'
    tlsv11_checkbuttion['state'] = 'disable'
    tlsv12_checkbuttion['state'] = 'disable'
    
    sni_checkbuttion['state'] = 'disable'
    reuse_checkbuttion['state'] = 'disable'
    ticket_checkbuttion['state'] = 'disable'
    encryp_checkbuttion['state'] = 'disable'
    ciphers_combo['state'] = 'disable'
    
    
    global g_hash_cookie,g_fix_cookie,g_hash_query,g_hash_header,g_real_cookie,g_cache_bool,g_auth_bool,g_speed_bool
    global g_random_cache_bool,g_custom_header_bool,g_random_expire_bool,g_load_file_bool
    hashcookie_check_v.set(0)
    g_hash_cookie = False
    g_fix_cookie = False
    hashcookie_key_entry['state'] = 'disable'  
    hashcookie_value_entry['state'] = 'disable'
    hashcookie_fix_checkbuttion['state'] = 'disable'
    hashcookie_fix_combo['state'] = 'disable'
    
    hashquery_check_v.set(0)
    g_hash_query = False
    hashquery_key_entry['state'] = 'disable'  
    hashquery_value_entry['state'] = 'disable'
    
    hashheader_check_v.set(0)
    g_hash_header = False
    hashheader_key_entry['state'] = 'disable'  
    hashheader_value_entry['state'] = 'disable'  
    
    real_cookie_check_v.set(0)
    g_real_cookie = False
    random_cache_v.set(0)
    cache_custom_head_check_v.set(0)
    cache_expire_check_v.set(0)
    load_file_cache_v.set(0)
    g_random_cache_bool,g_custom_header_bool,g_load_file_bool,g_random_expire_bool,g_cache_debug_bool = False,False,False,False,False
    cache_expire_checkbuttion['state'] = 'disable'
    cache_expire_entry['state'] = 'disable'
    cache_custom_head_checkbuttion['state'] = 'disable'
    cache_custom_head_entry['state'] = 'disable'
    load_file_cache_checkbuttion['state'] = 'disable'

    cache_check_v.set(0)
    g_cache_bool = False
    adcip_entry['state'] = 'disable'
    adcport_entry['state'] = 'disable'
    sniffer_entry['state'] = 'disable'
    debug_cache_v.set(0)
    debug_cache_checkbuttion['state'] = 'disable'
    

    global g_max_url_len_bool,g_legal_host_bool,g_http_version_bool,g_max_cookie_num_bool,g_max_header_num_bool,g_max_header_name_bool
    g_max_url_len_bool = False
    max_url_v.set(0)
    max_url_entry['state']='disable'
    
    
    g_legal_host_bool = False
    legal_host_v.set(0)
    legal_host_entry['state']='disable'
    
    
    g_http_version_bool = False
    http_version_v.set(0)
    http_version_entry['state']='disable'
    
    g_max_cookie_num_bool = False
    max_cookie_num_v .set(0)
    max_cookie_num_entry['state']='disable'
    
    g_max_header_num_bool = False
    max_header_num_v.set(0)
    max_header_num_entry['state']='disable'
    
    
    g_max_header_name_bool = False
    max_header_name_v.set(0)
    max_header_name_entry['state']='disable'
    
    global g_max_header_value_bool,g_max_url_name_bool,g_max_url_value_bool,g_max_request_header_bool,g_max_request_body_bool
    g_max_header_value_bool = False
    max_header_value_v.set(0) 
    max_header_value_entry['state']='disable'
    
    
    
    g_max_url_name_bool = False
    max_url_name_v.set(0) 
    max_url_name_entry['state']='disable'
    
    
    g_max_url_value_bool = False
    max_url_value_v.set(0)
    max_url_value_entry['state']='disable'
    
    
    g_max_request_header_bool = False
    max_request_header_v.set(0)
    max_request_header_entry['state']='disable'
    
    g_max_request_body_bool = False
    max_request_body_v.set(0)
    max_request_body_entry['state']='disable'

    
    
    global g_sql_referer_bool,g_sql_cookie_bool,g_sql_url_bool,g_sql_body_bool,g_sql_bool
    global g_xss_referer_bool,g_xss_cookie_bool,g_xss_url_bool,g_xss_body_bool,g_xss_bool
    g_sql_referer_bool = False
    g_sql_cookie_bool = False
    g_sql_url_bool = False
    g_sql_body_bool = False
    g_sql_bool = False
    g_xss_referer_bool = False
    g_xss_cookie_bool = False
    g_xss_url_bool = False
    g_xss_body_bool = False
    g_xss_bool = False
    xss_injection_entry['state'] = 'disable'
    xss_url_injection_checkbuttion['state'] = 'disable'
    xss_referer_injection_checkbuttion['state'] = 'disable'
    xss_cookie_injection_checkbuttion['state'] = 'disable'
    xss_body_injection_checkbuttion['state'] = 'disable'
    sql_injection_entry['state'] = 'disable'
    sql_url_injection_checkbuttion['state'] = 'disable'
    sql_referer_injection_checkbuttion['state'] = 'disable'
    sql_cookie_injection_checkbuttion['state'] = 'disable'
    sql_body_injection_checkbuttion['state'] = 'disable'
    sql_referer_injection_v.set(0)
    sql_url_injection_v.set(0)
    sql_body_injection_v.set(0)
    sql_cookie_injection_v.set(0)
    xss_referer_injection_v.set(0)
    xss_url_injection_v.set(0)
    xss_body_injection_v.set(0)
    xss_cookie_injection_v.set(0)
    xss_injection_v.set(0)
    sql_injection_v.set(0)
        
    global g_cusum_re_bool,g_no_print_all_bool,g_header_bool,g_rs_ip_header_bool

    g_rs_ip_header_bool = False
    rs_ip_header_check_v.set(0)
    rs_ip_header_entry['state'] = 'disable'
    speed_check_v.set(0)
    g_speed_bool = False
    speed_user_entry['state'] = 'disable'
    
    no_any_check_v.set(0)
    g_no_print_all_bool = False
    
    
    re_check_v.set(0)
    g_cusum_re_bool = False
    re_value_entry['state'] = 'disable'
    
    global g_no_auth_bool,g_brower_bool
    auth_v.set(0)
    g_no_auth_bool = True
    g_brower_bool = False
    user_name_entry['state'] = 'disable'
    password_entry['state'] = 'disable'
    special_user_checkbuttion['state'] = 'disable'
    user_prefix_entry['state'] = 'disable'
    pass_prefix_entry ['state'] = 'disable'
    special_user_check_v.set(0)
    
    
    header_check_v.set(0)
    g_header_bool = False
    header_text['state'] = 'disable'
    show_result()


cmd_frame = LabelFrame(text='Command')
ft2 = tkFont.Font(family='Verdana', size=run_font_size, weight=tkFont.BOLD)
aa = StringVar() 
run_command_button = Button(cmd_frame, font=ft2, command=RunButton, height=run_height,width=run_width,textvariable=aa)
aa.set('RUN')

force_command_button = Button(cmd_frame,text = 'Force_kill',state = 'disable',width=20,command = force_close,height=1)
speedup_command_button = Button(cmd_frame,text = 'Speed_up',state = 'disable',width=5,command = send_key_u,height=1)
speeddown_command_button = Button(cmd_frame,text = 'down',state = 'disable',width=5,command = send_key_d,height=1)

key_ip_button = Button(cmd_frame, text = 'src_ip',width=14,state = 'disable',command=send_key_i, height=1)

key_cookie_button = Button(cmd_frame,text = 'cookie', width=5,state = 'disable',command=send_key_c, height=1)

key_header_button = Button(cmd_frame,text = 'header', width=5,state = 'disable',command=send_key_h, height=1)

key_query_button = Button(cmd_frame, text = 'query',width=5,state = 'disable',command=send_key_q, height=1)

key_l2_src_button = Button(cmd_frame, text = 'L2_src',width=5,state = 'disable',command=send_key_1, height=1)
key_l2_dst_button = Button(cmd_frame, text = 'L2_dst',width=5,state = 'disable',command=send_key_2, height=1)
key_l2_src_dst_button = Button(cmd_frame, text = 'L2_src_dst',width=5,state = 'disable',command=send_key_3, height=1)

key_vip_button = Button(cmd_frame, text = 'vip_range',width=14,state = 'disable',command=send_key_m, height=1)
key_fullnat_button = Button(cmd_frame, text = 'fullnat',width=14,state = 'disable',command=send_key_f, height=1)
clear_text_button = Button(cmd_frame, text = 'clear_output',width=20,command=clear_text, height=1)
pause_str = StringVar()
pause_button = Button(cmd_frame, textvariable=pause_str,width=20,state = 'disable',command=restore_pause, height=1)
pause_str.set('Pause Output')
reset_str = StringVar()
reset_button = Button(cmd_frame, textvariable=reset_str,width=20,command=reset_config, height=1)
reset_str.set('Reset Config')


key_ip_button.grid(row=0,column=0,columnspan=2,sticky='w')
key_vip_button.grid(row=1, column=0, columnspan=2,sticky='w')
key_fullnat_button.grid(row=2, column=0, columnspan=2,sticky='w')
key_cookie_button.grid(row=3,column=0,sticky='w')
key_header_button.grid(row=3,column=1,sticky='w')
key_query_button.grid(row=4, column=0,sticky='w')
key_l2_src_button.grid(row=4, column=1,sticky='w')
key_l2_dst_button.grid(row=5, column=0,sticky='w')
key_l2_src_dst_button.grid(row=5, column=1,sticky='w')
speedup_command_button.grid(row=6, column=0, sticky='w')
speeddown_command_button.grid(row=6, column=1, sticky='w')


clear_text_button.grid(row=0, column=2, sticky='w')
reset_button.grid(row=1, column=2, sticky='w')
force_command_button.grid(row=2,column=2,sticky='w')
pause_button.grid(row=3, column=2, sticky='w')


run_command_button.grid(row=4,column=2,rowspan=3,sticky='w')

output_frame = Frame(root)
output_text = Text(output_frame,height=output_text_height,width=output_text_width) 
#output_text.pack(fill=BOTH) 
s = Scrollbar(output_frame)


#T.focus_set()
s.pack(side=RIGHT, fill=Y)
output_text.pack(side=LEFT, expand=1,fill=BOTH)
s.config(command=output_text.yview)
output_text.config(yscrollcommand=s.set)

necessary_frame.grid(row=0, column=0, sticky='w')

nb.add(general_frame, text='General')
#nb.add(frequently_used_frame, text='General')
nb.add(ip_frame, text='IP')
nb.add(method_url_frame, text='Method')
nb.add(cert_frame, text='SSL')
nb.add(persistence_frame, text='Persistence')
nb.add(auth_frame, text='Authentication')
nb.add(cache_frame, text='Cache')
nb.add(http_constraint_frame, text='HTTP_Constraint')
nb.add(sql_xss_frame, text='SQL/XSS')
nb.add(other_function_frame, text='Advance')
nb.add(header_frame, text='Header')
nb.grid(row=1,column=0,sticky='w')
result_txt.grid(row=2,column=0, columnspan=2, sticky='w')
cmd_frame.grid(row=0,column=1, rowspan=2, sticky='w')
output_frame.grid(row=3,column=0,columnspan=2, sticky='w')
#my_logfile =  Std_redirector(output_text)


# create a ttk notebook with our custom style, and add some i1tabs to it



def write_ini():
    config = ConfigParser()
    config.read(INITXT)
    if not config.has_section('Setting'):
        config.add_section("Setting")

    config.set("Setting","vs",server_name_v.get())
    config.set("Setting","vs_port",port_v.get())
    config.set("Setting","start_ip",range_ip_start_v.get())
    config.set("Setting","end_ip",range_ip_end_v.get())
    config.set("Setting","post_user_pass",entry_postuser_pass_v.get())
    config.set("Setting","post_url",post_entry_url_v.get())
    current_get_str = get_entry_url_v.get()
    if '?' in current_get_str:
        save_get_str = current_get_str.split('?')[0]
    else:
        save_get_str = current_get_str
    config.set("Setting","get_url",save_get_str)
    config.set("Setting","ca_name",ca_entry_v.get())
    config.set("Setting","client_cert",client_cert_entry_v.get())
    config.set("Setting","client_key",client_key_entry_v.get())
    config.set("Setting","re_pattern",re_value_entry_v.get())
    config.set("Setting","cookie_key",hashcookie_key_entry_v.get())
    config.set("Setting","cookie_value",hashcookie_value_entry_v.get())
    config.set("Setting","query_key",hashquery_key_entry_v.get())
    config.set("Setting","query_value",hashquery_value_entry_v.get())
    config.set("Setting","header_key",hashheader_key_entry_v.get())
    config.set("Setting","header_value",hashheader_value_entry_v.get())
    config.set("Setting","cache_ip",adcip_entry_v.get())
    config.set("Setting","cache_port",adcport_entry_v.get())
    config.set("Setting","sniffer_key",sniffer_entry_v.get())
    config.set("Setting","custom_cache_header",cache_custom_head_entry_v.get())
    config.set("GUI","OUTPUT_TEXT_HEIGHT",height_entry_v.get())
    config.set("Setting","user_name",user_name_v.get())
    config.set("Setting","password",password_v.get())
    config.set("Setting","user_prefix",user_prefix_v.get())
    config.set("Setting","pass_prefix",pass_prefix_v.get())
    config.set("Setting","user_num",user_num_v.get())
    config.set("Setting","rs_ip_header",rs_ip_header_entry_v.get()) 
    config.set("Setting","user_num",user_num_v.get())
    config.set("Setting","rs_ip_header",rs_ip_header_entry_v.get())  
    config.set("Setting","update_user_pass",update_user_entry_v.get())
    config.set("Setting","update_server_path",update_path_entry_v.get())

    tmp_file = open(INITXT,"w")
    config.write(tmp_file)  

def close_fun():

    write_ini()
    if flag_bool:
        if cmd_process.isalive():
            cmd_process.sendcontrol('c')
    #sleep(1)
    root.destroy()
    pid = getpid()
    kill(pid,1)
#    call('pkill -f http_gui',shell=True)
def printProtocol():

    close_fun()


root.protocol('WM_DELETE_WINDOW',printProtocol)

try:
    mainloop() 
except KeyboardInterrupt:

    close_fun()
  
    print '00000the program is closed by manually'
except  Exception, e:
    print 'eeeeeeeeeeeeee\n%s' % e
