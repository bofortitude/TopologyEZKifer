#!/usr/bin/env python
from optparse import OptionParser
#from gevent import monkey
#monkey.patch_socket()

import threading, sys, string
from time import sleep, ctime, time, gmtime, strftime
from re import search
from copy import deepcopy
from subprocess import call
#import urllib
from random import randint,shuffle
from subprocess import PIPE, Popen
usage = '''

./http-test.py [options] ServerIP Port CurrentSessionNum  requestNum requestInterval
For examples:

./http-test.py 10.0.8.202 80 100 50 10


The PC running script will launch 100 connections to server 10.0.8.202:80,For
every session, client will tranfer 50 request, the interval among requests is
10 seconds

There are hide_shortcut_key(i, I) when run script with pamameters which is mix  '-l or -L' and '-I or -i'  
There are hide_shortcut_key(c,C,q,Q,h,H) when run script with pamameters which is mix  '-l or -L' and '-a or -q or -C' 
There are hide_shortcut_key(u,U,d,D) when run script with pamameters which is '--speed-up'

Note:

Due to the limitness of Apache server, you'd better set requestItervall <=15, of course, 
we could modify the default-setting in http.conf



Some examples about http-header:

-H "X-Forwarded-For:1.1.1.1"
-H "Referer: http://www.zjs.com"
-H "Host: rss.sina.com.cn"
-H "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14"
-H "Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"
-H "Accept-Language: zh-cn,zh;q=0.5"
-H "Accept-Encoding: gzip,deflate"
-H "Accept-Charset: gb2312,utf-8;q=0.7,*;q=0.7"
-H "Keep-Alive: 300"
-H "Connection: keep-alive"
-H "Cookie: mycookie1=rs1;mycookie2=rs2;mycookie3=rs3"
-H "If-Modified-Since: Sun, 01 Jun 2008 12:05:30 GMT"
-H "Cache-Control: max-age=0"

------------------------------------------------------------
Fortiadc support
-s index.php?Content-Type=application/soap+xml
-s index.php?Content-Type=application/xml
-s index.php?Content-Type=text/html
-s index.php?Content-Type=text/plain
-s index.php?Content-Type=text/css
-s index.php?Content-Type=application/x-javascript
-s index.php?Content-Type=application/javascript
-s index.php?Content-Type=text/javascript
-s index.php?Content-Type=text/xml

Fortiadc unsupport

-s index.php?Content-Type=image/jpeg
-s index.php?Content-Type=mpg4 video/mp4
-s index.php?Content-Type=application/pdf

'''
version = string.split(string.split(sys.version)[0][:3], ".")
if map(int, version) < [2, 6]:
    print "You need Python ver 2.6 or higher to run!"
    sys.exit()
    
parser = OptionParser(usage=usage, version="%prog 6.8")
parser.add_option("-c", "--cookie", action="store_true", dest="cookie_bool", default=False, help="The request  will take cookie from server")

parser.add_option("-o", "--onebyone", dest="interval_connections", type="float", help="New connection is launched after old-connection was over.")

parser.add_option("-m", "--middle_interval", dest="middle_interval", type="float", help="New connection is launched after interval, and old connection maybe still running")

parser.add_option("-l", "--l4-warm", dest="l4", action="store_true", default=False, help="l4 warm-rate test,it count one time for one connecton")

parser.add_option("-L", "--l7-warm", dest="l7", action="store_true", default=False, help="l7 warm-rate test, it count one time for one transaction")




 
parser.add_option("-s", "--sub-page", dest="link", help="sub-page path(such as sub-link.html)                 Usage: -s index.php | -s fold/aa.html                  -s [1-100r].html | -s aaa.php/?aaa=bbb")

parser.add_option("-q", "--query", dest="query_a", help="Add query parameter for URL. The URL will b e like: http://www.fortinet.com.cn/?name=Peter.                 Usage: -q 'arg_name^1=value^10'")

parser.add_option("-C", "--custom-cookie", dest="cookie_a",
                  help="Add custom cookie eg. -C 'mykeyword^1=cookie^10' means single dynamic cookie_pair.   'mykeyword^1=cookie^10:1' means two cookie pairs, the first one is fixed, the second is dynamic   'mykeyword^1=cookie^10:2' means two cookie pairs, the first is dynamic, the second is fixed    ")

parser.add_option("-a", "--custom-header", dest="header_a",
                  help="Add custom header. Usage: -a 'test^1=test^10'")


#parser.add_option("-A", "--accuracy", dest="accuracy_a", type="float", help="If the wait-time greater than the value you set here, the reqeust will be recorded and print at last. default, it is 0.5 second. Usage: -A 1.0")




parser.add_option("-H", "--header", action="append", dest="arg_list",
                  help="Add predefined header line.                            Usage:  'Accept-Encoding: gzip'")




parser.add_option("-u", "--user-pass", dest="user_pass_all",
                  help="Support HTTP BASIC,MD5,WSSE,HMAC digest,Google Account Authentication. -u 'user:pass:10'  NOTE: The mix of '-u user:pass:b' and '-o' has special mean, the subsequent requests will take authentication item in their HEADER even if they are not in same connection, that is, no need let '401' occur in every connection  ")




parser.add_option("-w", "--l4_weight", action="store_true", dest="l4_weight_bool", default=False,
                  help="display the sum statistics info by tcp session")
parser.add_option("-W", "--l7_weight", action="store_true", dest="l7_weight_bool", default=False,
                  help="display the sum statistics info by http transaction")

#parser.add_option("--l2", dest="l2", type="int",help="The default header is 'random_cache_id', you can set your custom value with this option, Usage: --cache-id aaabbbcc")

parser.add_option("--l2-src", action="store_true", dest="l2_src_bool", default=False,
                  help="display the source_ip sum statistics info by L2 link")
parser.add_option("--l2-dst", action="store_true", dest="l2_dst_bool", default=False,
                  help="display the destination_ip sum statistics info by L2 link")
parser.add_option("--l2-src-dst", action="store_true", dest="l2_src_dst_bool", default=False,
                  help="display the src_dst_pair sum statistics info by L2 link")
parser.add_option("--l2-session", action="store_true", dest="l2_session_bool", default=False,
                  help="display the session sum statistics info by L2 link")
parser.add_option("-U", "--url-sum", action="store_true", dest="url_sum_bool", default=False,
                  help="display the sub-link statistics info")

#parser.add_option("-r", "--redirection",action="store_true",dest="redirecion_bool", default= False,help="print the redirected location info, it need not be used in together with other parameters,except for -s")
#parser.add_option("-P", "--post", dest="post_value", default=False, help="Enable the POST method, it always get together with -s. usage: -P admin:pass")

parser.add_option("-i", "--ip-range", dest="my_ip", help='''Simulated IP range, which support ipv4 and ipv6. For ipv4, 32 bit netmask is defalt; 
                        USAGE: IPV4: '-i 10.70.70.1-10.70.70.100'
                        For IPV6, 128 bit netmask is defalt;
                        USAGE: '-i 2001::10.70.70.1-10.70.70.100'.
                        
                            if just simulate single ip. Usage: '-i 10.70.70.1' or '-i 2001:70::10.70.70.1' 
                            if simulate the noncontinuous ip. Usage '-i 1.1.1.1,2.2.2.2' or '-i 2001:70::1.1.1.1,2.2.2.2' 
                            if simulate the random ip. Usage '-i 10'
                           if -e is not set, the script will find proper NIC automatically then bind it''')


parser.add_option("-e", "--eth-name", dest="my_eth", help="The NIC name ip-range will bind, it is not neccesary,you maybe set it sometime. Usage: '-e eth1'")

parser.add_option("-D", "--asynchronous", type="float", dest="ip_interval", help="Enable this option, the next ip will start to send the request after previous ip has transfered all request. Usage: -D 1.0")


parser.add_option("--random-dst-port", action="store_true", default=False, dest="random_ip_port_bool", help="Enable this option, the program will send the request with random_dst_port, it only take effect when set port-range and simulate ip.")


parser.add_option("-S", "--https", action="store_true", default=False, dest="prefix", help="Enable https, if it is alone(that is, you havn't set -f with it),  will disable the certfication-authenticaion")

parser.add_option("-f", "--ca-FileName", dest="ca_file", help="Set the ca_cert_file_name, it must be use with -S. Usage: -f zjsca.pem")


parser.add_option("-F", "--client-cert-key", dest="client_cert_key", help="Set the client cert and key file, it must be used with -S, Note: the key file muse be clear key rather than encrpt key.                                         usage: -F client_cert.pem:client_key.pem           Client will take client_cert.pem an client_key.pem to server.  \
                                                -F client_cert.pem:client_key.pem:2  \
            client will take client_cert1.pem and client_key1.pem in first session, client_cert2.pem and client_key2.pem in second sesson...")

parser.add_option("-v", "--verify-subject-name", action="store_true", default=False, dest="subject_verify_bool", help="Enable this option, program will check subject in cert whether match host_name, it must be used with '-f' and '-S'")

parser.add_option("-z", "--zip", dest="zip_method", help="Set zip algorithm, usage: -z g|d|i|n|m                   g means gzip, d means deflate, i means identify(no compress),n means un_support compress_method, m means the script will change its algorithm dynamicly ")

parser.add_option("-p", "--source-port", dest="source_port", type="int", help=" Set the source-port of http-request.Note: If SessionNum is non-1 value, you must add option -o. that is, the port will be reused")

parser.add_option("-r", "--port-reuse", dest="port_reuse_bool", action="store_true",
                  help=" Enable the source_port reuse .Usage: If SessionNum is non-1 value, and both '-o' and '-p' are active too, this source_port will be reused")
parser.add_option("-R", "--regular-expression", dest="custom_pattern",
                  help=" Set custome mattched regular expression, it you haven't set this option, defaultly, the script will match IPV4_ADDRESS .Usage: -R '(rs|RS)\d+'  it is used to match rs1,RS22...")    

#parser.add_option("-d", "--l7-debug", action="store_true", default=False, dest="l7_debug_bool", help="Enable this option, the HTTP header will add my-custom-header: zjs_debug:num, it is designed to help QA to figure out why some certain package occur timeout")

parser.add_option("-t", "--time-limit", dest="mytimeout", type="float", help=" Seconds to max. wait for responses. Maybe it will be used when sending larger amount of request, you don't hope a delay response to cost much time. usage -t 1.0")

parser.add_option("-T", "--telnet-ADC", dest="adc_sniffer", help="It is used to telnet ADC to sniffer, usually test web cache.                                                 Usage: -T '10.0.8.1|port2:port3|tcp and port 80'")


parser.add_option("-n", "--no-timeout-print", action="store_true", default=False, dest="output_time", help="Enable this option, the script will not print info about port and header which cost too much time")
parser.add_option("-N", "--no-output", action="store_true", default=False, dest="no_output_bool", help="Enable this option, the program won't print any normal http message,such 403,200,500. For error issue, suchas timeout,reset, they still will be printed, it mainly is used when sending amount of flow")

parser.add_option("-M", "--multi-servers", dest="server_list", help="Enable this option, the program will start the request to different servers. When enable it, the server in necessary parameters will become meaningless.                     Usage: -M 1.1.1.1,2.2.2.2,3.3.3.3 or 1.1.1.1-1.1.1.3 or 1.1.1.1")

parser.add_option("--no-bind-ip", action="store_true", default=False, dest="no_bindip_bool", help="Enable this option, the program won't bind the src_ip to NIC when simulating src_ip with -i, it is used to be involved by other program(such as llb.py) for sepecial purpose")

parser.add_option("--debug", action="store_true", default=False, dest="debug_all_bool", help="Enable this option, the program will display the response header and content")

parser.add_option("--fullnat", action="store_true", default=False, dest="full_nat_bool", help="Enable this option, the program will display the LB_IP and LB_src_port which is used to connect to server by ADC")

parser.add_option("--rewrite", action="store_true", default=False, dest="rewrite_bool", help="Enable this option, the program will display the rewrited host, url, referere")

parser.add_option("--update", action="store_true", default=False, dest="update_bool", help="Enable this option, the program will try to connect to FTP server in http_gui.ini to update itself")

parser.add_option("--cache", action="store_true", default=False, dest="random_cache_bool", help="Enable this option, the program will start cache mode. Usage: --cache")

parser.add_option("--cache-id", dest="header_cache_id", help="The default header is 'random_cache_id', you can set your custom value with this option, Usage: --cache-id aaabbbcc")

parser.add_option("--no-cache-load", dest="load_cache_file", action="store_false", default=True, help="Enable this option, the program will load previous cache_id from file 'old_cache_value.cache'")
parser.add_option("--cache-expire", dest="cache_expire_time", help="The program will get the begain time from old_cache_value.cache, then subtract with current time, if which > expire, will clean the old_cache_value out. Default, the expire time is 86400s. Usage: --cache-expire 100")
parser.add_option("--cache-debug", action="store_true", dest="cache_debug_bool", default=False, help="If it is togther with sniffer_cache_mode, the program will print the sniffer info; if with random_cache mode, will print match_cache_list info. Usage --cache-debug")

parser.add_option("--speed-up", dest="speed_add_num", type="int", help="Set the accelerated speed value. when it is set, the shortcut_key 'u', 'd' will be actived. Usage: --speed_add_num 10 or --spend_add_num -5")

parser.add_option("--pyopenssl", dest="myopenssl", default='version=tls_v1', help="Import pyopenssl but not default ssl socket. Usage: --pyopenssl 'version=ssl_v3,tls_v1|encryption=RC4-MD5|sni=1|reuse=1|ticket=1;  reuse=1 is used to test ssl_id persistence; ticket=1 mean enable RFC4507bis session tickets, sni =1 is used to test sni, it often be toghter with '-M'\
                                                         the support version is ssl_v2,ssl_v23,ssl_v3,tls_v1,tls_v1_1,tls_v1_2, for supported encryption algorithm, use the 'openssl cipher' command to see what is available")
parser.add_option("--method", action="append", dest="method_list",
                  help="Add Http Method,it support 'GET','POST','TRACE','DELETE','PUT','HEAD','OPTIONS','CONNECT' or any your custome method.                 Usage: --method 'POST:admin|pass:auth.php'              --method 'PUT:abc[1-10].html'                         --method 'CUSTOM:MY_METHOD:abc.html'                         --method 'CONNECT:1.1.1[1-10:80'")

parser.add_option("--protocol", dest="protocol",default='ver=1.1',
                  help="Test HTTP protocol Constraint in WAF. Usage: --protocol 'max_url_len=10|ver=1.1'|max_cookie_num=5|max_head_num=5| \
                  hostname=aabbcc|max_head_name_len=5|max_head_value=4|max_url_name_len=9| \
                  max_url_value_len=4|max_req_head=10:5|max_req_body=90|client_time=2|request_time=10")


parser.add_option("--injection", dest="injection", help="Start the injection attack. Usage: --injection sql|u|x=1-- ; --injection xss|c|x=<script>alert(1);<script>")
 

parser.add_option("--rs-ip-header", dest="rs_ip_header", help="Set checked RS header, sometime RS can not reply 200 Ok, but which can not mean ADC had not dispatched  the request to it. Default, the program will try to search my custom header 'ip', you can set your own one. Usage: --rs-ip-header your_header_name")



options, args = parser.parse_args()

mytimeout = None

ipv6_bool = False

if '--rs-ip-header' in sys.argv:
    rs_ip_header = options.rs_ip_header
else:
    rs_ip_header = 'ip'

l2_src_bool =options.l2_src_bool
l2_dst_bool = options.l2_dst_bool
l2_src_dst_bool = options.l2_src_dst_bool
l2_sess_bool = options.l2_session_bool




full_nat_bool = options.full_nat_bool
rewrite_bool = options.rewrite_bool

no_bindip_bool = options.no_bindip_bool
debug_all_bool = options.debug_all_bool
cmd_cache_debug_bool = options.cache_debug_bool
random_cache_bool = options.random_cache_bool
cache_expire_time = 86400
my_cache_id = 'random_cache_id'
if '--cache-id' in sys.argv:
    my_cache_id = options.header_cache_id

if '--cache-expire' in sys.argv:
    cache_expire_time = options.cache_expire_time
load_cache_file_bool = options.load_cache_file
#print load_cache_file_bool
#load_cache_file_bool = True
#print no_bindip_bool

if '-T' in sys.argv:
    import pexpect
    from StringIO import StringIO
    telnet_bool = True
    adc_sniffer = options.adc_sniffer
    if '|' in adc_sniffer:
        adc_ip, adc_ports, adc_match_string = adc_sniffer.split('|')
        if '-' in adc_ip:
            vdom_bool = True
            adc_ip, vdom_name = adc_ip.split('-')
        else:
            vdom_bool = False
        
    else:
        print "-T parameter format error, the string you input must include '}'"
        sys.exit()
    if ':' in adc_ports: 
        adc_port_list = adc_ports.split(':')
    else:
        adc_port_list = [adc_ports]
    
else:
    telnet_bool = False
    vdom_bool = False


if '-R' in sys.argv:
    p1 = options.custom_pattern
    p_bool = True
else:
    p1 = r'\d+\.\d+\.\d+\.\d+'
    p_bool = False
if  '-n' in sys.argv:
    output_time = False
else:
    output_time = True

port_reuse_bool = options.port_reuse_bool


if '-D' in sys.argv:
    asynchronous_bool = True
    ip_interval = options.ip_interval
else:
    asynchronous_bool = False
no_output_bool = options.no_output_bool
url_sum_bool = options.url_sum_bool

def ipRange(start_ip, end_ip):
   start = list(map(int, start_ip.split(".")))
   end = list(map(int, end_ip.split(".")))
   temp = start
   ip_range = []
   
   ip_range.append(start_ip)
   while temp != end:
      start[3] += 1
      for i in (3, 2, 1):
         if temp[i] == 256:
            temp[i] = 0
            temp[i - 1] += 1
      ip_range.append(".".join(map(str, temp)))
   list_copy = deepcopy(ip_range)    
   for j in list_copy:
       if (j.split('.')[3] == '0') or (j.split('.')[3] == '255'):
           ip_range.remove(j)   
   return ip_range

sourceip_bool = False
ip_single_bool = False
random_ipv6_bool = False
random_ipv4_bool = False
multi_single_bool = False

if '-i' in sys.argv:
    python_version = sys.version
    if python_version > '2.7':
        python27_bool = True
    else:
        python27_bool = False


    from multiprocessing import Process, Pool, Manager, Lock
    
    sourceip_bool = True
    ip_original = options.my_ip
    if ip_original.isdigit():
        random_ip_num = int(ip_original)
        if ':' in args[0]:
            random_ipv6_bool = True
            ipv6_bool = True
        else:
            random_ipv4_bool = True
    else:
        if '::' in ip_original:
            ipv6_bool = True
            if '-' in ip_original:
                tmp_ip_list = ip_original.split('::')[1].split('-')
            elif ',' in ip_original:
                multi_single_bool = True
                tmp_ip_list = ip_original.split(',')
                #tmp_ip_list = ip_original.split('::')[1].split(',')
            else:
                ip_single_bool = True
            ipv6_prefix = ip_original.split('::')[0] 
        else:
            if '-' in ip_original:
                tmp_ip_list = ip_original.split('-')
            elif ',' in ip_original:
                multi_single_bool = True
                tmp_ip_list = ip_original.split(',')
                
            else:
                ip_single_bool = True

random_ip_port_bool = options.random_ip_port_bool

if '-e' in sys.argv:
    eth_bool = True
    eth_name = options.my_eth
else:
    eth_bool = False

ca_direct = ''
if '-F' in sys.argv or  '-f' in sys.argv or (load_cache_file_bool and random_cache_bool) or options.update_bool:
    from os.path import exists
    path_info, error = Popen('ls /bin/http_test -la', shell=True, stdout=PIPE).communicate()
    if search('-> (.+)http_test_.+.py', path_info) is not None:
        ca_direct = search('-> (.+)http_test_.+.py', path_info).group(1)



if '-f' in sys.argv:
    if exists(options.ca_file):
        ca_file = options.ca_file
        ca_file_bool = True
    elif exists('%s%s' % (ca_direct, options.ca_file)):
        ca_file = '%s%s' % (ca_direct, options.ca_file)
        ca_file_bool = True
    else:
        print "-f error, can not find specificed CA file %s" % options.ca_file
        sys.exit()

        
else:
    ca_file_bool = False


client_cert_start = 0
def get_client_cert_key():
    global client_cert_start
    result_cert, result_key = '', ''
    if client_multi_cert_bool:
        if client_cert_start < cert_num:
            client_cert_start += 1
        else:
            client_cert_start = 1 
        if client_cert_prefix_bool:
            result_cert = '%s%s.%s' % (client_cert_prefix, client_cert_start, client_cert_suffix)
        else:
            result_cert = '%s%s' % (client_cert_file, client_cert_start)
        if client_key_prefix_bool:
            result_key = '%s%s.%s' % (client_key_prefix, client_cert_start, client_key_suffix)
        else:
            result_key = '%s%s' % (client_key_file, client_cert_start)            
            
    else:
        result_cert = client_cert_file
        result_key = client_key_file
        
    if exists(result_cert):
        f_result_cert = result_cert
        f_result_key = result_key

    elif exists('%s%s' % (ca_direct, result_cert)):
        f_result_cert = '%s%s' % (ca_direct, result_cert)
        f_result_key = '%s%s' % (ca_direct, result_key)
    else:
        print "-F error, can not find specificed cert file %s" % f_result_cert
        sys.exit()
    print f_result_cert, f_result_key
    return f_result_cert, f_result_key
client_multi_cert_bool = False
if '-F' in sys.argv:
    client_cert_key = options.client_cert_key
    if ':' not in client_cert_key:
        print "-F error, there must be a ':' in parameter"
        sys.exit()
    elif len(client_cert_key.split(':')) == 2:
        client_cert_bool = True
        client_multi_cert_bool = False
        client_cert_file, client_key_file = client_cert_key.split(':')
        if exists(client_cert_file):
            client_cert_file = client_cert_file
            client_key_file = client_key_file


        elif exists('%s%s' % (ca_direct, client_cert_file)):
            client_cert_file = '%s%s' % (ca_direct, client_cert_file)
            client_key_file = '%s%s' % (ca_direct, client_key_file)
            client_key_file = client_key_file

 
        else:
            print "-f error, can not find specificed cert file %s" % client_cert_file
            sys.exit()
                      
    elif len(client_cert_key.split(':')) == 3:
        client_cert_file, client_key_file, cert_num_str = client_cert_key.split(':')
        if '.' in client_cert_file:
            client_cert_prefix, client_cert_suffix = client_cert_file.split('.')[0], client_cert_file.split('.')[1]
            client_cert_prefix_bool = True
        else:
            client_cert_prefix_bool = False
        if '.' in client_key_file:
            client_key_prefix, client_key_suffix = client_key_file.split('.')[0], client_key_file.split('.')[1]
            client_key_prefix_bool = True
        else:
            client_key_prefix_bool = False  
        cert_num = int(cert_num_str)          
        client_cert_bool = True
        client_multi_cert_bool = True
    else:
        print "-F error, ':' is too much for pamater"
        sys.exit()
        
else:
    client_cert_bool = False
def pyopenssl_process(i):
    global my_openssl_dict
    global zjs_session_reuse_bool
    if '=' in i :
        if i.split('=')[0] == 'reuse':
            my_openssl_dict['reuse'] = int(i.split('=')[1])
            if my_openssl_dict['reuse']:
                zjs_session_reuse_bool = True

        elif i.split('=')[0] == 'ticket':
      
            my_openssl_dict['ticket'] = int(i.split('=')[1])
            if my_openssl_dict['ticket']:
                zjs_ticket_bool = True
        elif i.split('=')[0] == 'sni':
      
            my_openssl_dict['sni'] = int(i.split('=')[1])
            if my_openssl_dict['sni']:
               zjs_sni_bool = True
            
        elif i.split('=')[0] == 'version':
            version_begin_value = i.split('=')[1]
            if ',' in version_begin_value:
                
                my_openssl_dict['version'] = version_begin_value.split(',')
            else:
                my_openssl_dict['version'] = [version_begin_value]
        elif i.split('=')[0] == 'encryption':
            encryption_begin_value = i.split('=')[1]
            if ',' in encryption_begin_value:
                my_openssl_dict['encryption'] = encryption_begin_value.split(',')
            else:
                my_openssl_dict['encryption'] = [encryption_begin_value]
        else:
            print 'Error pyopenssl command, legal keys are "version,encryption,ticket,reuse"'
            sys.exit()   
    else:
        print 'Error input format for pyopenssl,miss "="'
        sys.exit()     

zjs_session_reuse_bool = False
import __builtin__

if debug_all_bool:
    __builtin__.debuglevel = 1
else:
    __builtin__.debuglevel = 0  

if '--pyopenssl' in sys.argv:
    encrypt_anull, error = Popen('openssl ciphers aNULL', shell=True, stdout=PIPE).communicate()
    encrypt_anull_list = encrypt_anull.strip().split(':')
    my_openssl_dict = {'reuse':0, 'version':['tls_v1'], 'ticket':0, 'encryption':[], 'sni':0}
    __builtin__.pyopenssl = 1
    __builtin__.encrypt_anull_list = encrypt_anull_list
    pyopenssl_bool = True
    
    
    pyopenssl_parameters = options.myopenssl
    if '|' in pyopenssl_parameters:
        para_list = pyopenssl_parameters.split('|')
        for i in para_list:
            pyopenssl_process(i)
    else:
        pyopenssl_process(pyopenssl_parameters)

   
else:
    __builtin__.pyopenssl = 0
    __builtin__.encrypt_anull_list = []
    pyopenssl_bool = False
    
    
protocol_bool = False        
if '--protocol' in sys.argv:
    protocol_bool = True
    protocol_dict = {}
    protocol_parameters = options.protocol
    if '|' in protocol_parameters:
        protocol_parameter_pair = protocol_parameters.split('|')
        for i in protocol_parameter_pair:
            protocol_dict[i.split('=')[0]] =  i.split('=')[1]
    else:
        protocol_dict[protocol_parameters.split('=')[0]] =  protocol_parameters.split('=')[1]
    
 


if '--injection' in sys.argv:
    injection_str = options.injection
    injection_bool = True
    injection_type,injection_sub_type,injection_pattern = injection_str.split('|')
    aa =  '--injection sql|u|x=1--'
else:
    injection_bool = False

 
 
 
    

import httplib2

if options.update_bool:
    from ConfigParser import ConfigParser
    INITXT = '%shttp_gui.ini' % ca_direct
    if exists(INITXT):
        config = ConfigParser()
        config.readfp(open(INITXT))
        if config.has_option('Setting', 'update_server_path'):
            update_server_path = config.get('Setting', 'update_server_path') 

            if config.has_option('Setting', 'update_user_pass'):
                update_user_name = config.get('Setting', 'update_user_pass') 
                update_user_name_bool = True
            else:
                update_user_name_bool = False
                print 'Can not find the update_user_pass in http_gui.ini, will login with anonymous user'
            if update_user_name_bool:
                update_cmd = 'jiasheng_update http_test %s -u %s' % (update_server_path, update_user_name)
            else:
                update_cmd = 'jiasheng_update http_test %s' % update_server_path
            print update_cmd
            try:
                call(update_cmd, shell=True)
            except KeyboardInterrupt:
                print "the http_test update process is closed by manully"
        else:
            print 'Can not find update_server info in http_gui.ini'
            sys.exit()
            #call(update_cmd,shell=True)
    else:
        print 'Can not find the http_gui.ini'
    sys.exit()
    
            
    

if '-a' in sys.argv:
    h_a = True
else:
    h_a = False
    
prefix_bool = options.prefix

#if '-A' in sys.argv:
#    accuracy_bool = True
#    accuracy_a = options.accuracy_a
#else:
#    accuracy_bool = False
#    if not prefix_bool:
#        
#        accuracy_a = 0.5
#    else:
#        
#        accuracy_a = 3

if '-p' in sys.argv:
    
    source_port = options.source_port

    source_port_bool = True
    httplib2.source_port_bool = True

else:
    
    source_port = 0
    source_port_bool = False
    httplib2.source_port_bool = False


httplib2.zjs_debug_bool = options.debug_all_bool



if '-o' in sys.argv:
    onebyone = True

else:
    onebyone = False

if '-m' in sys.argv:
    middle_bool = True
else:
    middle_bool = False


if '-q' in sys.argv:
    query_bool = True
else:
    query_bool = False

sub_bool = False
sub_query = False
multi_sublink_bool = False
multiprocess_sublink_bool = False
if '-s' in sys.argv:
    sub_bool = True
    sub_page = options.link


    if search('\?.+=.+?', sub_page) is not None:
        sub_query = True

    multi_sublink = search('\[(\d+-\d+.?)\]', sub_page)
    if multi_sublink is not None:
        str_multi_sub_start, str_multi_sub_end = multi_sublink.group(1).split('-')
        if str_multi_sub_end.find('r') != -1 or str_multi_sub_end.find('R') != -1:
     
            multiprocess_sublink_bool = True
           
            str_multi_sub_end = str_multi_sub_end[:-1]
   
            
        multi_sub_end = int(str_multi_sub_end)
        multi_sub_start = int(str_multi_sub_start)
        
        
        if int(multi_sub_end) < multi_sub_start:
            print "-s parameter excetion: end_value muse great than start_value"
            sys.exit()  

        multi_prefix = sub_page.split('[')[0]
        multi_suffix = sub_page.split(']')[1]
        multi_sublink_bool = True
 
  
    else:

        global_sub_page = sub_page
    #    print  multi_sub_start,multi_sub_end,multi_prefix,multi_suffix
        
        
 

if '-H' in sys.argv:
    header_bool = True
else:
    header_bool = False

if '-C' in sys.argv:
    header_cookie_bool = True
else:
    header_cookie_bool = False

user_mode = False
user_bool = False
user_single_bool = False
user_domain = ''
if '-u' in sys.argv:
    user_bool = True
    user_original_all, pass_original, user_num = options.user_pass_all.split(':')
    
    if user_num == 'b' and onebyone:
        user_mode = True 
    if user_num == 's':
        user_single_bool = True
        
    if '\\' in user_original_all:
        user_domain, user_original = user_original_all.split('\\')
    else:
        user_original = user_original_all
    

gzip_bool = False
deflate_bool = False
identity_bool = False
zip_mix_bool = False
zip_unsupport_bool = False

if '-z' in sys.argv:
    zip_method_flag = options.zip_method
    switch_zip = True
    if zip_method_flag not in ['g', 'd', 'i', 'm', 'n']:
        print "please double check the -z, what you input is not supported"
        sys.exit()
                
    elif zip_method_flag == 'g':
        gzip_bool = True
    elif zip_method_flag == 'd':
        deflate_bool = True 
    elif zip_method_flag == 'i':
        identity_bool = True
    elif zip_method_flag == 'm':
        zip_mix_bool = True   
    elif zip_method_flag == 'n':
        zip_unsupport_bool = True  
else:
    switch_zip = False


cookie_bool = options.cookie_bool
g_l4_weight_bool = options.l4_weight_bool
g_l7_weight_bool = options.l7_weight_bool

if g_l4_weight_bool or g_l7_weight_bool:
    weight_bool = True
else:
    weight_bool = False
g_l4_warm_bool = options.l4
g_l7_warm_bool = options.l7

httplib2.warm_bool = g_l4_warm_bool or g_l7_warm_bool
local_warm_bool = g_l4_warm_bool or g_l7_warm_bool

httplib2.subject_verify_bool = options.subject_verify_bool
       
if not pyopenssl_bool:
    if g_l4_warm_bool or g_l7_warm_bool:
    
        if not prefix_bool:
            mytimeout = 1
        else:
            mytimeout = 5
    
    if '-t' in sys.argv:
        mytimeout = options.mytimeout
    

    

      
#redirection_bool = options.redirecion_bool



if ca_file_bool and not prefix_bool:
    print "Since you use -f, -S is also must be set togther"
    sys.exit()

if client_cert_bool and not prefix_bool:
    print "Since you use -F, -S is also must be set togther"
    sys.exit()

    

query_a = options.query_a



if header_cookie_bool:
    mycookie_original = options.cookie_a
    if ':' in mycookie_original:
        
        mycookie_1, cookie_flag_str = mycookie_original.split(':')
        cookie_flag = int(cookie_flag_str)
    else:
        mycookie_1 = mycookie_original
        cookie_flag = 0

if h_a:
    v1 = options.header_a
   



if len(sys.argv) < 6:
    parser.print_help()
   # print "Please add parameter (-h or --help) for help"
    sys.exit()

if onebyone and middle_bool:
    print "-o and -m couldn't been used at the same time"
    sys.exit()


if g_l4_warm_bool and g_l7_warm_bool:
    print "-l and -L cann't be used at the same time"
    sys.exit()

Server = args[0]
Start_ServerPort = args[1]

def get_vs_port(result_port_list,tname):
    return str(result_port_list[tname % num_dst_port - 1])
    
    
result_port_list = []
num_dst_port = 0
if ',' in Start_ServerPort or '-' in Start_ServerPort:
    multi_dst_port_bool = True
    if ',' in  Start_ServerPort:
        comma_port_list = Start_ServerPort.strip().split(',')
        for i in comma_port_list:
            if '-' in i:
                tmp_add_value = 0
                range_port_start, range_port_end = i.split('-')
                
                if range_port_start.strip().isdigit() and range_port_end.strip().isdigit() and int(range_port_start.strip()) <= int(range_port_end.strip()):
                    while (tmp_add_value + int(range_port_start.strip())) <= int(range_port_end.strip()):
                        result_port_list.append(tmp_add_value + int(range_port_start.strip()))
                        tmp_add_value += 1                    
                else:
                    print 'VS_PORT has an error format, please double check'
                    sys.exit()
            else:
                result_port_list.append(i)
    elif '-' in Start_ServerPort:
        tmp_add_value = 0
        range_port_start, range_port_end = Start_ServerPort.split('-')
        if range_port_start.strip().isdigit() and range_port_end.strip().isdigit() and int(range_port_start.strip()) <= int(range_port_end.strip()):
            while (tmp_add_value + int(range_port_start.strip())) <= int(range_port_end.strip()):
                result_port_list.append(tmp_add_value + int(range_port_start.strip()))
                tmp_add_value += 1
        else:
            print 'VS_PORT has an error format, please double check'
            sys.exit()
    num_dst_port = len(result_port_list)
else:
    multi_dst_port_bool = False


                

SessionNum = long(args[2])
if SessionNum == 0:
    session_unlimit_bool = True
else:
    session_unlimit_bool = False

server_list = []
if '-M' in sys.argv:
    multi_server_bool = True
    
    if ',' in options.server_list:
        
        server_list = options.server_list.split(',')
        Server = server_list[0]
    elif '-' in options.server_list:
        if '::' in options.server_list:
            ipv6_dst_prefix, ipv6_dst_suffix = options.server_list.split("::")
            m_server_list_suffix = ipv6_dst_suffix.split('-')
            server_list_suffix = ipRange(m_server_list_suffix[0], m_server_list_suffix[1])
            for i in server_list_suffix:
                server_list.append('%s::%s' % (ipv6_dst_prefix, i))
        else:
            m_server_list = options.server_list.split('-')
            server_list = ipRange(m_server_list[0], m_server_list[1])
        Server = server_list[0]
    else:
        server_list = [options.server_list]
        Server = options.server_list
#    if SessionNum < len(server_list):
#        SessionNum = len(server_list)
else:
    multi_server_bool = False 
 
l2_dst_ip_bool = False
l2_src_ip_bool = False
l2_src_dst_ip_bool = False
l2_session_bool = False
    
if full_nat_bool:
    if l2_dst_bool:
        l2_dst_ip_bool = True
    if l2_src_bool:
        l2_src_ip_bool = True 
    if l2_src_dst_bool:
        l2_src_dst_ip_bool = True
    if l2_sess_bool:
        l2_session_bool = True
    
    
def get_dns_ip(host):
    from socket import getaddrinfo, SOCK_STREAM
    return getaddrinfo(host, None, 0, SOCK_STREAM)[0][4][0]

def get_eth_name(serverip):
    
    myroute, error = Popen('ip route get %s' % serverip, shell=True, stdout=PIPE).communicate()
    ethname = search('dev (\w+) ', myroute)
    if ethname is not None:
        return ethname.group(1)
    else:
        print 'Can not find the ethname automatically'
        

if sourceip_bool and not eth_bool:
    if random_ipv4_bool or random_ipv6_bool:
        eth_name = 'lo'
    else:
        if not ipv6_bool and search(p1, Server) is None:
    
            dst_ip_server = get_dns_ip(Server)
            eth_name = get_eth_name(dst_ip_server)
        else:

            eth_name = get_eth_name(Server)
    

result_reuse_bool = False
if SessionNum != 1 and onebyone and port_reuse_bool:
    result_reuse_bool = True

requestNum = long(args[3])
if requestNum == 0:
    request_unlimit_bool = True
else:
    request_unlimit_bool = False
    
requestInterval = float(args[4])

if middle_bool and SessionNum != 1:
    middle_interval = options.middle_interval
else:
    middle_interval = 0

if onebyone and SessionNum != 1:
    
    connection_interval = options.interval_connections
else:
    connection_interval = 0

if sourceip_bool and no_output_bool and not asynchronous_bool:
    just_test_bool = True
else:
    just_test_bool = False
   
if prefix_bool:
    prefix_name = "https"
   # import OpenSSL.SSL
else:
    prefix_name = "http" 




myarg = "name"
adcUsername = 'admin'
adcPassword = ''
Sessions = []

switch = True

all_status = []
cache_debug_bool = False

#if user_mode and requestNum == 1 and onebyone:
#    httplib2.user_auth_bool = True
#else:
#    httplib2.user_auth_bool = False

post_bool = False
method_mix_bool = False
#my_method_value = options.method_name
data = {}
body = None
cache_dict = {}
def my_print(msg):

    if not g_l4_warm_bool and not g_l7_warm_bool and not no_output_bool:
        print msg
if random_cache_bool  and load_cache_file_bool:
    from os.path import exists
    from cPickle import load, dump
   # import cPickle as pickle
    cache_file_name = '%sold_cache_value.cache' % ca_direct
    if exists(cache_file_name):
        cache_file = file(cache_file_name, 'rb')
        try:
            cache_dict = load(cache_file)
        except  Exception, e:
            pass
           
        cache_file.close()
    if cache_dict:
        original_cache_time = cache_dict['time']
        current_cache_time = time()
        if (current_cache_time - original_cache_time) > float(cache_expire_time):
            cache_dict = {}
    if (cmd_cache_debug_bool and cache_dict) or (cache_dict and cache_debug_bool):
        my_print('Start to load previous cahce_header information as follows')
        for key in cache_dict:
            my_print('%s:%s' % (key, cache_dict[key]))
post_increase_num = -1
def get_post_url():
    global post_increase_num
    post_increase_num += 1
    if post_url_bool:
        if post_multi_sublink_bool:
            cur_sub_num = post_multi_sub_start + post_increase_num
            if  cur_sub_num <= post_multi_sub_end:
    
                return post_multi_prefix + str(cur_sub_num) + post_multi_suffix
            else:
                post_increase_num = 0
                return post_multi_prefix + str(post_multi_sub_start) + post_multi_suffix
        else:
            return post_begin_url
    else:
        return web + '/'
put_increase_num = -1
def get_put_url():
    global put_increase_num
    put_increase_num += 1
    if put_url_bool:
        if put_multi_sublink_bool:
            cur_sub_num = put_multi_sub_start + put_increase_num
            if  cur_sub_num <= put_multi_sub_end:
    
                return  put_multi_prefix + str(cur_sub_num) + put_multi_suffix
            else:
                put_increase_num = 0
                return  put_multi_prefix + str(put_multi_sub_start) + put_multi_suffix
        else:
            return  put_begin_url
    else:

        return  '/'
head_increase_num = -1
def get_head_url():
    global head_increase_num
    head_increase_num += 1
    if head_url_bool:
        if head_multi_sublink_bool:
            cur_sub_num = head_multi_sub_start + head_increase_num
            if  cur_sub_num <= head_multi_sub_end:
    
                return head_multi_prefix + str(cur_sub_num) + head_multi_suffix
            else:
                head_increase_num = 0
                return head_multi_prefix + str(head_multi_sub_start) + head_multi_suffix
        else:
            return  head_begin_url
    else:

        return '/'  
trace_increase_num = -1
def get_trace_url():
    global trace_increase_num
    trace_increase_num += 1
    if trace_url_bool:
        if trace_multi_sublink_bool:
            cur_sub_num = trace_multi_sub_start + trace_increase_num
            if  cur_sub_num <= trace_multi_sub_end:
                return trace_multi_prefix + str(cur_sub_num) + trace_multi_suffix 
            else:
                trace_increase_num = 0
                return  trace_multi_prefix + str(trace_multi_sub_start) + trace_multi_suffix
        else:
            return trace_begin_url
    else:

        return '/'          
option_increase_num = -1
def get_option_url():
    global option_increase_num
    option_increase_num += 1
    if option_url_bool:
        if option_multi_sublink_bool:
            cur_sub_num = option_multi_sub_start + option_increase_num
            if  cur_sub_num <= option_multi_sub_end:
    
                return option_multi_prefix + str(cur_sub_num) + option_multi_suffix
            else:
                option_increase_num = 0
                return option_multi_prefix + str(option_multi_sub_start) + option_multi_suffix
        else:
            return option_begin_url
    else:

        return  '/'      
delete_increase_num = -1
def get_delete_url():
    global delete_increase_num
    delete_increase_num += 1
    if delete_url_bool:
        if delete_multi_sublink_bool:
            cur_sub_num = delete_multi_sub_start + delete_increase_num
            if  cur_sub_num <= delete_multi_sub_end:
    
                return  delete_multi_prefix + str(cur_sub_num) + delete_multi_suffix
            else:
                delete_increase_num = 0
                return  delete_multi_prefix + str(delete_multi_sub_start) + delete_multi_suffix
        else:
            return delete_begin_url
    else:

        return '/'  
connect_increase_num = -1    
def get_connect_url():
    global connect_increase_num
    connect_increase_num += 1
    if connect_multi_sublink_bool:
        cur_sub_num = connect_multi_sub_start + connect_increase_num
        if  cur_sub_num <= connect_multi_sub_end:

            return connect_multi_prefix + str(cur_sub_num) + connect_multi_suffix
        else:
            connect_increase_num = 0
            return connect_multi_prefix + str(connect_multi_sub_start) + connect_multi_suffix
    else:
        return connect_begin_url

    
connect_multi_sublink_bool, delete_multi_sublink_bool, option_multi_sublink_bool, trace_multi_sublink_bool, head_multi_sublink_bool, put_multi_sublink_bool, post_multi_sublink_bool = False, False, False, False, False, False, False

if '--method' in sys.argv:
    
    method_all_list = options.method_list
    method_list = []
    for i in method_all_list:
        if 'POST' in i:
            post_url_bool = False
            from urllib import urlencode
            post_user, post_pass = i.split(':')[1].split('|')
            if ':' in i and len(i.split(':')) == 3:
                post_begin_url = i.split(':')[2]
                if not post_begin_url.startswith('/'):
                    post_begin_url = '/' + post_begin_url
                post_multi_sublink = search('\[(\d+-\d+.?)\]', post_begin_url)
                if post_multi_sublink is not None:
                    post_str_multi_sub_start, post_str_multi_sub_end = post_multi_sublink.group(1).split('-')
                    post_multi_sub_end = int(post_str_multi_sub_end)
                    post_multi_sub_start = int(post_str_multi_sub_start)
                    post_multi_sublink_bool = True
                    post_multi_prefix = post_begin_url.split('[')[0]
                    post_multi_suffix = post_begin_url.split(']')[1]

                
                post_url_bool = True

            data = {'user':post_user, "pass":post_pass}
            post_body = urlencode(data)
           # post_body = '1--'
            #post_body = "<script>alert(1);<script>" 
            #print 22222222,post_body
            method_list.append('POST')
        if 'GET' in i:
            method_list.append('GET')
        if 'PUT' in i:
            put_url_bool = False
            if ':' in i and len(i.split(':')) == 2:
                put_url_bool = True
                put_begin_url = i.split(':')[1]
                if not put_begin_url.startswith('/'):
                    put_begin_url = '/' + put_begin_url
                put_multi_sublink = search('\[(\d+-\d+.?)\]', put_begin_url)
                if put_multi_sublink is not None:
                    put_str_multi_sub_start, put_str_multi_sub_end = put_multi_sublink.group(1).split('-')
                    put_multi_sub_end = int(put_str_multi_sub_end)
                    put_multi_sub_start = int(put_str_multi_sub_start)
                    put_multi_sublink_bool = True
                    put_multi_prefix = put_begin_url.split('[')[0]
                    put_multi_suffix = put_begin_url.split(']')[1]
  
            method_list.append('PUT')  
       
        if 'HEAD' in i:
            method_list.append('HEAD')
            head_url_bool = False
            if ':' in i and len(i.split(':')) == 2:
                head_url_bool = True
                head_begin_url = i.split(':')[1]
                if not head_begin_url.startswith('/'):
                    head_begin_url = '/' + head_begin_url
                head_multi_sublink = search('\[(\d+-\d+.?)\]', head_begin_url)
                if head_multi_sublink is not None:
                    head_str_multi_sub_start, head_str_multi_sub_end = head_multi_sublink.group(1).split('-')
                    head_multi_sub_end = int(head_str_multi_sub_end)
                    head_multi_sub_start = int(head_str_multi_sub_start)
                    head_multi_sublink_bool = True
                    head_multi_prefix = head_begin_url.split('[')[0]
                    head_multi_suffix = head_begin_url.split(']')[1]
   
        if 'TRACE' in i:
            method_list.append('TRACE')
            trace_url_bool = False
            if ':' in i and len(i.split(':')) == 2:
                trace_url_bool = True
                trace_begin_url = i.split(':')[1]
                if not trace_begin_url.startswith('/'):
                    trace_begin_url = '/' + trace_begin_url
                trace_multi_sublink = search('\[(\d+-\d+.?)\]', trace_begin_url)
                if trace_multi_sublink is not None:
                    trace_str_multi_sub_start, trace_str_multi_sub_end = trace_multi_sublink.group(1).split('-')
                    trace_multi_sub_end = int(trace_str_multi_sub_end)
                    trace_multi_sub_start = int(trace_str_multi_sub_start)
                    trace_multi_sublink_bool = True
                    trace_multi_prefix = trace_begin_url.split('[')[0]
                    trace_multi_suffix = trace_begin_url.split(']')[1]
  
        if 'OPTIONS' in i:
            method_list.append('OPTIONS') 
            option_url_bool = False
            if ':' in i and len(i.split(':')) == 2:
                option_url_bool = True
                option_begin_url = i.split(':')[1]
                if not option_begin_url.startswith('/'):
                    option_begin_url = '/' + option_begin_url
                option_multi_sublink = search('\[(\d+-\d+.?)\]', option_begin_url)
                if option_multi_sublink is not None:
                    option_str_multi_sub_start, option_str_multi_sub_end = option_multi_sublink.group(1).split('-')
                    option_multi_sub_end = int(option_str_multi_sub_end)
                    option_multi_sub_start = int(option_str_multi_sub_start)
                    option_multi_sublink_bool = True
                    option_multi_prefix = option_begin_url.split('[')[0]
                    option_multi_suffix = option_begin_url.split(']')[1]
      
        if 'DELETE' in i:
            method_list.append('DELETE')   
            delete_url_bool = False
            if ':' in i and len(i.split(':')) == 2:
                delete_url_bool = True
                delete_begin_url = i.split(':')[1]
                if not delete_begin_url.startswith('/'):
                    delete_begin_url = '/' + delete_begin_url
                delete_multi_sublink = search('\[(\d+-\d+.?)\]', delete_begin_url)
                if delete_multi_sublink is not None:
                    delete_str_multi_sub_start, delete_str_multi_sub_end = delete_multi_sublink.group(1).split('-')
                    delete_multi_sub_end = int(delete_str_multi_sub_end)
                    delete_multi_sub_start = int(delete_str_multi_sub_start)
                    delete_multi_sublink_bool = True
                    delete_multi_prefix = delete_begin_url.split('[')[0]
                    delete_multi_suffix = delete_begin_url.split(']')[1]
       
        if 'CONNECT' in i:
            method_list.append('CONNECT')   
            if ':' in i:
                connect_begin_url = i.split(':',1)[1]
                if not connect_begin_url.startswith('/'):
                    connect_begin_url = '/' + connect_begin_url
                connect_multi_sublink = search('\[(\d+-\d+.?)\]', connect_begin_url)
                if connect_multi_sublink is not None:
                    connect_str_multi_sub_start, connect_str_multi_sub_end = connect_multi_sublink.group(1).split('-')
                    connect_multi_sub_end = int(connect_str_multi_sub_end)
                    connect_multi_sub_start = int(connect_str_multi_sub_start)
                    connect_multi_sublink_bool = True
                    connect_multi_prefix = connect_begin_url.split('[')[0]
                    connect_multi_suffix = connect_begin_url.split(']')[1]
        if 'CUSTOM' in i:
            method_list.append('CUSTOM') 
            custom_str, custom_method_name,custom_method_url = i.split(':')
            if not custom_method_url.startswith('/'):
                custom_method_url = '/' + custom_method_url
                
              
        
                  
else:
    method_list = ['GET']
    
    
len_method_list = len(method_list)


if (connect_multi_sublink_bool or delete_multi_sublink_bool or option_multi_sublink_bool or trace_multi_sublink_bool or head_multi_sublink_bool or put_multi_sublink_bool or post_multi_sublink_bool or multi_sublink_bool) and query_bool and url_sum_bool:  
    url_full_bool = True
else:
    url_full_bool = False
    
if header_bool:
    header_result = {}
    header_t = options.arg_list
    for i in header_t:
        j = i.split(':', 1)
        header_result[j[0].lower().strip()] = j[1].strip()
    zjs_headers_c = deepcopy(header_result)

compress_type = ['application/soap+xml', 'text/plain', 'application/xml', 'text/html', 'text/css', 'application/x-javascript', 'application/javascript', 'text/javascript', 'text/xml']
#compress_type = ['text/html','text/plain','text/css','text/javascript','text/xml']

if '--speed-up' in sys.argv:
    speed_up_bool = True
    speed_add_num = options.speed_add_num   
    adjust_speed = 0
   
else:
    speed_up_bool = False
   




header_num = randint(1, 10000000)
def get_header_num():
    global header_num
    header_num += 1
    return str(header_num)

current_sub_num = 0
multi_first_flag = 0
def get_multi_sub_name():
    global current_sub_num, multi_first_flag
    if multiprocess_sublink_bool:
        current_sub_num = randint(multi_sub_start, multi_sub_end)
    else:
        if multi_first_flag == 0:
            multi_first_flag += 1
            current_sub_num = multi_sub_start
        else:
            if current_sub_num < multi_sub_end:
                current_sub_num += 1
            else:
                current_sub_num = multi_sub_start
    
        
    return multi_prefix + str(current_sub_num) + multi_suffix
                  
def adc_telnet(port_name):
    try:
        
        fp = StringIO()  
        if cache_debug_bool or cmd_cache_debug_bool:
            my_print('Try to login to %s' % adc_ip)
        child = pexpect.spawn('telnet %s' % adc_ip) 
        child.logfile_read = fp
        index = child.expect(["login:", "[pP]assword", "#", "(?i)Unknown host", pexpect.EOF, pexpect.TIMEOUT])

        if (index == 0):
            child.sendline(adcUsername)   
            index = child.expect(["[pP]assword", pexpect.EOF, pexpect.TIMEOUT])
            child.sendline(adcPassword)
            child.expect('#')
            if cache_debug_bool or cmd_cache_debug_bool:
                my_print('Login to %s successfully' % adc_ip)
            
            if vdom_bool:
                child.sendline("config vdom") 
                child.expect('#')
                child.sendline("edit %s" % vdom_name)
                child.expect('#')
                if cache_debug_bool or cmd_cache_debug_bool:
                    my_print('Enter into VDOM %s' % vdom_name)
            sniffer_key = "diagnose sniffer packet %s '%s' 3" % (port_name, adc_match_string)
            child.sendline(sniffer_key)
            dia_index = child.expect(['filters=', 'error'])
            if cache_debug_bool or cmd_cache_debug_bool:
                my_print('Try to sniffer with  "%s"' % sniffer_key)            
            if dia_index == 1:
                print 'diagnose sniffer command meet error, please check inputed command or ADC enable vdom or not...'
                sys.exit()
            else:
                fp.seek(0)
                fp.truncate()
      
        else:
   
            print "The telnet login_fail, due to TIMEOUT or EOF" 
            child.close(force=True)
            child = None
            sys.exit()
            
        return child, fp
    except Exception, e:
  
        print "The telent action meet a problem,as follows %s" % e
        sys.exit()

def match_url(pkg, url):
    data = ''
  
    if pkg.find('->') != -1:
        pkg_list = pkg.split('\r\n')
        for i in pkg_list:

            if i.find('\t') != -1:
                tmp_list = i.split('\t')
                if len(tmp_list) == 3:
                    data = data + tmp_list[2]
                else:
                    if cache_debug_bool or cmd_cache_debug_bool:
                        print '________________sniffer-string-format-error__________________'
                        print i
        if cache_debug_bool or cmd_cache_debug_bool:
            print '%s\n' % data
            print 'Match_sublink_string is "%s"\n' % url

        
        if data.find(url) != -1:   
            if cache_debug_bool or cmd_cache_debug_bool:
                my_print('Find match url in sniffer info')         
            return True
        
    return False
        

           
def adc_sniffer_func(match_sub_page):
    global map_file_child 
    match_result = []
    try: 
  
        for i in map_file_child:

            i[0].sendline('zjs-spefic-end')
            i[0].expect('zjs-spefic-end', timeout=1)
         
            adc_package = i[1].getvalue()

            
            if len(adc_package) > 20:

                match_result.append(match_url(adc_package, match_sub_page))
                if cache_debug_bool or cmd_cache_debug_bool:
                    print adc_package
                
            else:
                
                match_result.append(False)
                if cache_debug_bool or cmd_cache_debug_bool:
                    print 'No-sniffer-package\n'



            i[1].seek(0)
            i[1].truncate()

              
   #     print match_result
        if True in match_result:
            return True
        else:
            return False
    except (pexpect.TIMEOUT, Exception), e:
        print "%s \n" % e
        for i in map_file_child:

            i[0].close(force=True)
            i[1].close()
           
        map_file_child = start_telnet()   
   
def start_telnet():

    string_files = []
    child_list = []
    for port_index, port_name in enumerate(adc_port_list):
        
        tmp_child, tmp_fp = adc_telnet(port_name)
        child_list.append(tmp_child)
        string_files .append(tmp_fp)
   
    return zip(child_list, string_files)
#
#def my_out(a1):
#   # print a1,
#    log_file.write(a1)
#
#def my_out_port(a1):
#    print a1
#    if sourceip_bool:
#        
#        log_file.write('#' + a1 + '\n') 
         
def random_ipv4_list(num):
    
    random_ip_list = []
    while len(random_ip_list) < num:
        ip_1 = randint(1, 223)
        if ip_1 != 172 and ip_1 != 127 and ip_1 != 10:
            ip_element = str(ip_1) + '.' + str(randint(0, 255)) + '.' + str(randint(0, 255)) + '.' + str(randint(1, 254))
            random_ip_list.append(ip_element)

    return random_ip_list

                                                                
def random_ipv6_list(num):
    random_ip_list = []
    M = 16 ** 4
    while len(random_ip_list) < num:
 
        ip_element = "2000:" + ":".join(("%x" % randint(0, M) for i in range(7)))
        random_ip_list.append(ip_element)
    return random_ip_list


def ip_process(ip_list, eth_name, add_bool=True):
    if add_bool:
        bind_str = 'bind'
        action = 'add'
 
    else:
        bind_str = 'unbind'
        action = 'del'        
    if ipv6_bool:
        ipv6_str = '-6 '
        mask_bit = '/128'
    else:
        ipv6_str = ''
        mask_bit = '/32'
        
    for ip in ip_list:
        if call('ip %saddr %s %s%s dev %s' % (ipv6_str, action, ip, mask_bit, eth_name), shell=True) != 0:
            print "%s ip %s error" % (bind_str, ip)
    print '%s ip task over' % bind_str


def sys_tcp_limit():

#
#    if call("ulimit -n 10240", shell = True) != 0:
#        print "cann't release the file limitness"

    if ipv6_bool:
        mydad = "sysctl -w net.ipv6.conf." + eth_name + ".accept_dad=0"
        if call(mydad, shell=True) != 0:    
            print "can't modify the setting about ipv6_DAD at NIC %s" % eth_name
    try:
        f = file("/etc/sysctl.conf", 'r')
    except Exception, e:
#        sys.exit()
        
        print "Couldn't open the file sysctl.conf" 
        print e

  
     
     
    str = f.read()
    f.close()
    p = "net.ipv4.ip_local_port_range" 

            
    port_limit = search('net.ipv4.ip_local_port_range', str)
    if port_limit is None:
        w_bool = True
    else:
        w_bool = False
    
    if w_bool:
     
        if call("echo 'net.ipv4.ip_local_port_range = 1024 65000' >> /etc/sysctl.conf", shell=True) != 0:    
            print "can't modify the sysctl.conf"

        if call(["sysctl", "-p"]) not in [0, 255]:
            print "can't load the sysctl.conf"



from re import split as resplit
def process_four(v1):

        
    t1 = v1.split('=')
    t2 = t1[0]
    t3 = t1[1]
    a_m = search('\^(\d+)', t2).group(1)
    a1, a1_end = resplit('\^\d+', t2)
    
 #   a_m = t2.split('^')[1]
  #  a1 = t2.split('^')[0]
    
    b_m = search('\^(\d+)', t3).group(1)
    b1, b1_end = resplit('\^\d+', t3)
    
   # b_m = t3.split('^')[1]
    #b1 = t3.split('^')[0]
  
    return a_m, b_m, a1, b1, a1_end, b1_end


a = 1
b = 0

r_1 = 0

c = 1
d = 0
r_2 = 0

e = 1
f = 0
r_3 = 0
def result_two_new(a_m, b_m, a_1, b_1, a, b, r_1, k_end, v_end):

    r_1 += 1
    if r_1 == 1:
        little_switch = True
    else:
        little_switch = False
    if a_m == 0 and b_m == 0:
        return [a_1 + k_end, b_1 + v_end], a, b, r_1
    if a_m == 0 and b_m != 0:
        if b >= b_m:
            b = 1
            return [a_1 + k_end, b_1 + str(b) + v_end], a, b, r_1
        else:
            b += 1
            return [a_1 + k_end, b_1 + str(b) + v_end], a, b, r_1
    if a_m != 0 and b_m == 0:
        if little_switch:
            a = 0
        if a < a_m:
            a += 1
            return [a_1 + str(a) + k_end, b_1 + v_end], a, b, r_1
        
        else:
            a = 1
            return [a_1 + str(a) + k_end, b_1 + v_end], a, b, r_1
    if a > a_m:
        a = 1
        b = 1
        return [a_1 + str(a) + k_end, b_1 + str(b) + v_end], a, b, r_1
    else:
        if b >= b_m:
            if a < a_m:
                a += 1
                b = 1
                return [a_1 + str(a) + k_end, b_1 + str(b) + v_end], a, b, r_1
            else:
                a = 1
                b = 1
                return [a_1 + str(a) + k_end, b_1 + str(b) + v_end], a, b, r_1
        else:
            b += 1
            return [a_1 + str(a) + k_end, b_1 + str(b) + v_end], a, b, r_1




list_count = []
list_count_weight_warm = []
cookie_count_weight_warm = []
header_count_weight_warm = []
query_count_weight_warm = []
fullnat_count_weight_warm = []
list_count_dst_warm = []
list_count_weight = []
list_count_weight_page = []
list_count_weight_fullnat = []
list_count_weight_cache = []
list_count_weight_page_full = []
list_count_weight_dst = []
list_random_cache_count = []
list_count_l2_dst = []
list_count_l2_src = []
list_count_l2_src_dst = []
list_count_l2_session = []
l2_src_dst_count_weight_warm,l2_src_count_weight_warm,l2_dst_count_weight_warm = [],[],[]

def count_num_weight(serverip, mypara='', count_list=[]):


    a = {}
    b = {}
    t_b = False


    if mypara:
        if count_list:

            for d_t in count_list:
                if d_t.has_key(mypara):
                    t_b = True

            if t_b:
                for i in count_list:

                    if i.has_key(mypara):
                        if i.has_key(serverip):
                            i[serverip] += 1
                            i[mypara] += 1
                        else:
                            i[serverip] = 1
                            i[mypara] += 1
            else:
                    a[mypara] = 1
                    a[serverip] = 1
                    count_list.append(a)
        else:
            b[mypara] = 1
            b[serverip] = 1
            count_list.append(b)
    return count_list

def count_num_multi_ip(serverip, mypara, test_ip_account_list):
    a = {}
    b = {}
    t_b = False
    try:
        if mypara:
            if test_ip_account_list:
    
                for d_t in test_ip_account_list:
                    if d_t.has_key(mypara):
                        t_b = True
    
                if t_b:
    
                    for index, i in enumerate(test_ip_account_list):
    #                for i in multi_ip_account_list:
                  
                        if i.has_key(mypara):
    
                            if i.has_key(serverip):
                                
             
                                i[serverip] += 1
     
                                i[mypara] += 1
         
    #                            print  i[mypara]
                                
                                test_ip_account_list[index] = i
 
                            else:
    
                                i[serverip] = 1
                                i[mypara] += 1
                                test_ip_account_list[index] = i
                else:
    
                    a[mypara] = 1
                    a[serverip] = 1
                    test_ip_account_list.append(a)
            else:
    
                b[mypara] = 1
                b[serverip] = 1
                test_ip_account_list.append(b)
    except Exception, e:
        pass
#        print "33333333333333%s" % e


def count_multi_ip(serverip, mypara):
    a = {}
    b = {}
    t_b = False
    try:
        if mypara:
            if multi_ip_account_list:
    
                for d_t in multi_ip_account_list:
                    if d_t.has_key(mypara):
                        t_b = True
    
                if t_b:
    
                    for index, i in enumerate(multi_ip_account_list):
    #                for i in multi_ip_account_list:
                  
                        if i.has_key(mypara):
    
                            if i.has_key(serverip):
                                
             
                                i[serverip] += 1
     
                                i[mypara] += 1
         
    #                            print  i[mypara]
                                
                                multi_ip_account_list[index] = i
 
                            else:
    
                                i[serverip] = 1
                                i[mypara] += 1
                                multi_ip_account_list[index] = i
                else:
    
                    a[mypara] = 1
                    a[serverip] = 1
                    multi_ip_account_list.append(a)
            else:
    
                b[mypara] = 1
                b[serverip] = 1
                multi_ip_account_list.append(b)
    except Exception, e:
        print "33333333333333%s" % e

tmp_warm_count = 0
    
def query_out(l1, flag=True):

    global tmp_warm_count   
    c = 0
    if p_bool:
        add_int = 0
    else:
        add_int = 3
    for d in l1:

        k = d.keys()
        k.sort()
      #  if not p_bool and flag:
        k.reverse()
        c += 1
#        if c == 1:
#            if g_l4_warm_bool or g_l7_warm_bool:
#
#                tmp_warm_count += 1
#
#                if tmp_warm_count == 1:
#
#                    if not sourceip_bool:
#                        for i in range(2 * len(k)):
#                            if i == 0:
#                                print "Client :",
#                            if i == 1:
#                                print "Num" + ' ' * (len(k[0]) + add_int),
#                            if (i > 1) and (i % 2 == 0):
#                                print "Server :",
#                            if (i > 1) and (i % 2 == 1):
#                                print "Num             ",
#            
#                        print "\n"
#            else:
#                for i in range(2 * len(k)):
#                    if i == 0:
#                        print "Client :",
#                    if i == 1:
#                        print "Num" + ' ' * (len(k[0]) + add_int),
#                    if (i > 1) and (i % 2 == 0):
#                        print "Server :",
#                    if (i > 1) and (i % 2 == 1):
#                        print "Num             ",
#        
#                print "\n"
        
        for i in k:
           
            if not p_bool:
                print "%s : %s           " % (i, d[i]),
            else:
                print "%s : %s      " % (i, d[i]),

        print "\n"

#def source_port_out(l1):
#    if len(l1) > 0:
#        if not sourceip_bool:
#            print "The IP address, source_port,debug_header information as follows:"
#        for i in l1:
#            reason = l1[i]
#            if not i[4]:
#           
#                if not sourceip_bool:
#                    i = list(i)
#                    i[0] = "LocalHost"
#                    i = tuple(i)
#
#                
#                my_out_port("%s:%s<--->%s:%s >>>>>>>>>>>>>>>%s" % (i[0], i[1], i[2], i[3], reason))
#
#            else:
#                
#                if not sourceip_bool:
#          
#                    i = list(i)
#                    i[0] = "LocalHost"
#
#                
#                
#                my_out_port("%s:%s<--->%s:%s and zjs_debug:%s >>>>>>>>>>>>>>>%s" % (i[0], i[1], i[2], i[3], i[4], reason))
#                
#                

                                   
                 


#def query_out_sourceip(l1):
#
#    for d in l1:
#
#        k = d.keys()
#        k.sort()
#        k.reverse()
#
#        for i in k:
#            my_out("%s : %s           " % (i, d[i]))
#        my_out("\n")
#    


user_id = -1
def get_id():
    global user_id
    if user_num.isdigit():
            
        if  user_id < int(user_num):
            user_id += 1
            return user_id
            
        else:
            user_id = -1
            return  0
    else:
        return ''
ssl_v_num = -1
ssl_e_num = -1
def get_ssl_version():
    global ssl_v_num 
    ssl_v_num += 1
    return my_openssl_dict['version'][ssl_v_num % len(my_openssl_dict['version'])]
    
    
def get_ssl_encrypion():
    global ssl_e_num 
    ssl_e_num += 1
    bb = ssl_e_num % len(my_openssl_dict['encryption'])
    return my_openssl_dict['encryption'][ssl_e_num % len(my_openssl_dict['encryption'])]
def get_src_port(tname):
    global source_port
    result_port = source_port + int(tname)
    if result_port <= 65000:
        return result_port
    else:
        source_port = 10000
        my_print('warning, the source_port beyound the range, the script will reuse the port from 10000 automatically')
        return 10000
def get_new_interval(interval, adjust_speed, n=1):
    global switch
 #   return (1 - (100 * interval * adjust_speed/ (1 + interval * adjust_speed) / 100)) * interval
    result = (1 - (100 * interval * adjust_speed / (n + interval * adjust_speed) / 100)) * interval
    return result
cache_list = []
def get_random_cache_result(responser1, match_sub_page, request_method, cache_dict):
    global cache_list
    
    if my_cache_id in responser1:
        cur_cache_id_value = responser1[my_cache_id]
       # print cur_cache_id_value
        if cur_cache_id_value not in cache_list:
            cache_list.append(cur_cache_id_value)
        cache_key = '%s|%s' % (request_method, match_sub_page)

        if cache_key in cache_dict:
            cache_value_list = cache_dict[cache_key]
            if cur_cache_id_value in cache_value_list:
                random_cache_value = 'Hit-Cache'
                if cache_debug_bool or cmd_cache_debug_bool:
                    my_print('The Request URL is %s, current random_id is %s, match_list is %s, so result is Hit-Cache' % (cache_key, cur_cache_id_value, cache_value_list))               
            else:
                
               # if '|' in original_cache_value:
                #    new_cache_value = original_cache_value.split('|')[1] + '|' + cur_cache_id_value
                #else:
                 #   new_cache_value = original_cache_value + '|' +cur_cache_id_value
                if cache_debug_bool or cmd_cache_debug_bool:
                    my_print('The URL is %s, current random_id is %s, match_list is %s, so result is No-Hit-Cache' % (match_sub_page, cur_cache_id_value, cache_value_list))
                cache_value_list.append(cur_cache_id_value)
                cache_dict[cache_key] = cache_value_list
                random_cache_value = 'No-Hit-Cache'

        else:
            cache_dict[cache_key] = [cur_cache_id_value]

            random_cache_value = 'No-Hit-Cache'
            if cache_debug_bool or cmd_cache_debug_bool:
                my_print('The URL is %s, current random_id is %s, match_list is empty, so result is No-Hit-Cache' % (match_sub_page, cur_cache_id_value))
        random_cache_pair = ',%s ->%s' % (cache_key, random_cache_value)
    else:
        random_cache_value = 'No-Hit-Cache'
        cache_key = ''
        random_cache_pair = ',Warning!No random_cache_id Header'
        if cache_debug_bool or cmd_cache_debug_bool:
            my_print('The URL is %s,can not find random_cache_id in responser header, so result is No-Hit-Cache' % match_sub_page)
    return cache_key, random_cache_value, random_cache_pair

def zjs_random_str(num,body_flag=0):
    result_str = ''
    
    ori_str = 'abcdefghijklmnopqrstuvwx1234567890ASDFGHJKLQWERTYUIOPZXCVBNM/?-_=&%yz'
    ori_str = 'abcdefghijklmnopqrstuvwx1234567890ASDFGHJKLQWERTYUIOPZXCVBNMyz'
    if body_flag:
        result_str = 'a' * num
    
    else:
        for i in xrange(num):
            result_str += ori_str[randint(0,len(ori_str)-1)]
    
    return result_str
def max_str_pair(self,num,length=5,normal=1,head_flag=1,start=1):
    result_str = ''
    result_dict = {}
    pad_str = 'head_'
  #s  ori_str = 'abcdefghijklmnopqrstuvw~!@#$%^&*()_-=\+|xyz1234567890?/'
    if normal==1:
        ori_str = 'abcdefghijklmnopqrstuvwx1234567890ASDFGHJKLQWERTYUIOPZXCVBNMyz'
    else:
        ori_str = 'abcdefghijklmnopqrstuvwx1234567890ASDFGHJKLQWERTYUIOPZXCVBNM/?-_=&%yz'
    for i in xrange(num):
        for j in xrange(length):
            result_str += ori_str[randint(0,len(ori_str)-1)]
        result_dict['%s%s' %(pad_str,str(i+start))] = result_str
        result_str = ''   
    return result_dict
def get_max_cookie_num(new_cookie_num,start=0):
    result_str = ''
    for i in xrange(new_cookie_num):
        if i == new_cookie_num -1:
            suffix = ''
        else:
            suffix = ';'
        result_str += 'auto_cookie_%s=%s%s' %(str(i+1+start),zjs_random_str(5),suffix)
    return result_str
def zjs_max_url_name_len(num):
    url_query_name = zjs_random_str(num)
    url_query_value = 'URL_Query_Name_Length_%s' % num
    result_str = '%s%s=%s' %('?',url_query_name,url_query_value)

    return result_str

def zjs_max_url_value_len(num):
    url_query_value = zjs_random_str(num)
    url_query_name = 'URL_Query_value_Length_%s' % num
    result_str = '%s%s=%s' %('?',url_query_name,url_query_value)

    return result_str

    

mix_num = 0
method_num = -1
global_cookie = {}
global_ssl_session = None
old_o_cookie = {}
def loop(tname, Server,ServerPort, sourceip='', http=''):
    
#    def cookie_process(old_d, c_s):
#
#        l2 = []
#        tmp_d = {}
#        tmp_l = []
# 
#        if ' ' in c_s:
#    
#            l1 = c_s.split(" ")
#            for i in l1:
#                if "=" in i:
#                    if ('expire' not in i) and ('path' not in i) and ('domain' not in i):
#                        l2.append(i[:-1])
#
#            
#        else:
#             if "=" in c_s:
#                 if ('expire' not in c_s) and ('path' not in c_s) and ('domain' not in c_s):
#                     l2.append(c_s)
#             else:
#                 l2.append("ERROR-COOKIE=ERROR")
#        for m in l2:
#            tmp_d[m.split('=')[0]] = m.split('=')[1]
#        if old_d:
#
#            for n in tmp_d:
#                if n in old_d:
#                    old_d[n] = tmp_d[n]
#                    
#                else:
#                    old_d[n] = tmp_d[n]
#            for w in old_d:
#                tmp_l.append(w + '=' + old_d[w])
#            
#            send_cookie = ';'.join(tmp_l)
#            
#            return old_d, ';'.join(l2), send_cookie
#        
#        else:
#            return tmp_d, ';'.join(l2), ';'.join(l2)
        
           
    def all_account(full_nat_ip, data, warm_time,test_a):
       # print 'abc-%s' %data
        
        global qn, mix_num, list_count_weight, list_count_weight_warm, method_num
        global query_count_weight_warm, header_count_weight_warm, cookie_count_weight_warm, list_count_weight_dst, list_count_dst_warm 
        global list_count_weight_warm, list_count, list_count_weight_page, list_count_weight_cache, list_count_weight_page_full
        global list_random_cache_count, list_count_weight_fullnat, fullnat_count_weight_warm,list_count_l2_dst
        global list_count_l2_src,list_count_l2_src_dst,list_count_l2_session
        global l2_src_dst_count_weight_warm,l2_src_count_weight_warm,l2_dst_count_weight_warm
        try:
            if h_a or query_bool or header_cookie_bool:
    
                if query_bool and (not h_a) and (not header_cookie_bool):
                    result_header = tmp_query
    
                        
                elif h_a and (not query_bool) and (not header_cookie_bool):
                    result_header = "HEADER--" + ":".join(h_t_1)
                elif header_cookie_bool and (not h_a) and (not query_bool): 
                    result_header = "COOKIE--" + zjs_headers["Cookie"]
                elif h_a and query_bool and not header_cookie_bool:
                    tmp_header = "HEADER--" + ":".join(h_t_1)
                    result_header = tmp_query + "&&" + tmp_header
                elif query_bool and header_cookie_bool and not h_a:
                    tmp_header = "cookie--" + zjs_headers["Cookie"]
                    result_header = tmp_query + "&&" + tmp_header
                elif h_a and header_cookie_bool and not query_bool:
                    tmp_header1 = "cookie--" + zjs_headers["Cookie"]
                    tmp_header2 = "HEADER--" + ":".join(h_t_1)
                    result_header = tmp_header1 + "&&" + tmp_header2
                elif h_a and header_cookie_bool and query_bool:
                    tmp_header1 = "cookie--" + zjs_headers["Cookie"]
                    tmp_header2 = "HEADER--" + ":".join(h_t_1)
            
                    result_header = tmp_header1 + "&&" + tmp_header2 + "&&" + tmp_query
           
                if sourceip_bool:
                    if process_lock.acquire():
                        if lock.acquire():
                            count_num_multi_ip(data, result_header, sum_multi_list_count)
                            lock.release()
                        process_lock.release()
                
                list_count = count_num_weight(data, sourceip + result_header, list_count)
    
            if  l4_warm_bool or l7_warm_bool:
              
                if sourceip_bool:
                    
                    if multi_dict['s_header_bool'] or multi_dict['s_query_bool'] or multi_dict['s_cookie_bool'] or multi_dict['s_dst_bool'] or multi_dict['s_fullnat_bool'] or multi_dict['l2_src_bool'] or multi_dict['l2_dst_bool'] or multi_dict['l2_src_dst_bool'] or not multi_dict['s_bool']:             
                        if process_lock.acquire():
                            if lock.acquire():
                           
                                if multi_dict['s_header_bool']:
                                    warm_time = ":".join(h_t_1) + ' | ' + warm_time
                                    count_num_multi_ip(data, warm_time, multi_header_account_list)
                                elif multi_dict['s_query_bool']:
                                    warm_time = tmp_query + ' | ' + warm_time
                               
                                    count_num_multi_ip(data, warm_time, multi_query_account_list)
                                
                                elif multi_dict['s_dst_bool']:
                                    warm_time = '%s-%s' % (Server, ServerPort) + ' | ' + warm_time
                                    count_num_multi_ip(data, warm_time, multi_dst_account_list)
    
                                elif multi_dict['s_cookie_bool']:
                                    warm_time = zjs_headers["Cookie"] + ' | ' + warm_time
                                    count_num_multi_ip(data, warm_time, multi_cookie_account_list)
                                    
                                elif multi_dict['s_fullnat_bool']:
                                    warm_time = 'FULL_NAT' + ' | ' + warm_time
                                    count_num_multi_ip(full_nat_ip, warm_time, multi_fullnat_account_list)
                                elif multi_dict['l2_src_bool']:
                                    warm_time = sourceip + ' | ' + warm_time
                                    count_num_multi_ip(full_nat_ip, warm_time, multi_l2_src_account_list)
                                elif multi_dict['l2_dst_bool']:
                                    warm_time = Server + ' | ' + warm_time
                                    count_num_multi_ip(full_nat_ip, warm_time, multi_l2_dst_account_list)
                                elif multi_dict['l2_src_dst_bool']:
                                    warm_time = sourceip + Server +  ' | ' + warm_time
                                    count_num_multi_ip(full_nat_ip, warm_time, multi_l2_src_dst_account_list)
                                
                                elif  not multi_dict['s_bool']: 
                                    count_num_multi_ip(data, warm_time, multi_ip_account_list)
    #                                                  print 'thread_%s aaaaaa--------%s' % (tname,time())
    #                                    )               print multi_ip_account_list
                                
                                lock.release()
                            process_lock.release()
                           
                    elif multi_dict['s_bool']:
                        if lock.acquire():
                            warm_time = sourceip + '| ' + warm_time
                            list_count_weight_warm = count_num_weight(data, warm_time, list_count_weight_warm)
                        lock.release()                                                                 
                else:
                 
                    if lock.acquire():   
                       
                        if key_cookie_bool:
                            
                            warm_time = zjs_headers["Cookie"] + ' | ' + warm_time
    
                            cookie_count_weight_warm = count_num_weight(data, warm_time, cookie_count_weight_warm)
                        elif key_header_bool:
                          
                            warm_time = ":".join(h_t_1) + ' | ' + warm_time
                             
                            header_count_weight_warm = count_num_weight(data, warm_time, header_count_weight_warm)
                        elif key_query_bool:
                
                            warm_time = tmp_query + ' | ' + warm_time
                            
                            query_count_weight_warm = count_num_weight(data, warm_time, query_count_weight_warm)
                            
                        elif key_fullnat_bool:
                   
                            warm_time = 'FULL_NAT' + ' | ' + warm_time
                     
                           # print fullnat_count_weight_warm
                            fullnat_count_weight_warm = count_num_weight(full_nat_ip, warm_time, fullnat_count_weight_warm)
                  
                        elif key_l2_src_bool:
                         
                            warm_time = '| ' + warm_time
                            l2_src_count_weight_warm = count_num_weight(full_nat_ip, warm_time, l2_src_count_weight_warm)
                            
                        elif key_l2_dst_bool:
                            warm_time = Server + ' | ' + warm_time
                            l2_dst_count_weight_warm = count_num_weight(full_nat_ip, warm_time, l2_dst_count_weight_warm)
                        elif key_l2_src_dst_bool:
                            warm_time = sourceip + Server +  ' | ' + warm_time
                            l2_src_dst_count_weight_warm = count_num_weight(full_nat_ip, warm_time, l2_src_dst_count_weight_warm)                        
                        elif key_dst_bool:
                            warm_time = '%s-%s' % (Server, ServerPort) + ' | ' + warm_time
                            list_count_dst_warm = count_num_weight(data, warm_time, list_count_dst_warm)
                        else:
                            list_count_weight_warm = count_num_weight(data, warm_time, list_count_weight_warm)
                    lock.release()
                       
         
            if  l7_weight_bool or l4_weight_bool or url_sum_bool or random_cache_bool or full_nat_bool:
       
                if sourceip_bool:
                    if process_lock.acquire():
                        if lock.acquire():
                            if l7_weight_bool or l4_weight_bool:
                                count_num_multi_ip(data, 'Client', sum_multi_weight_count)
                                count_num_multi_ip(data, 'Client ' + sourceip, sum_multi_vs_sip_count)
                                if multi_dst_port_bool or multi_server_bool:
                                    count_num_multi_ip(data, '%s-%s' % (Server, ServerPort), sum_multi_dst_count)
                            if l2_dst_ip_bool:
                                count_num_multi_ip(full_nat_ip, '%s' % (Server,), sum_multi_l2_dst_count)
                            if l2_src_ip_bool:
                                count_num_multi_ip(full_nat_ip, 'Client %s' % sourceip, sum_multi_l2_src_count)
                            if l2_src_dst_ip_bool:
                                count_num_multi_ip(full_nat_ip, '%s-%s' % (sourceip,Server), sum_multi_l2_src_dst_count)  
                            if l2_session_bool:
                                if not 'ERROR' in full_nat_ip:
                                    count_num_multi_ip(full_nat_ip, '%s-%s<=>%s-%s' % (test_a[0],test_a[1],test_a[2],test_a[3]), sum_multi_l2_session_count)                  
                            if url_sum_bool:    
                                count_num_multi_ip(data, sub_page, sum_multi_url_count)
                            if full_nat_bool:    
                                        
                                count_num_multi_ip(full_nat_ip, 'FULL_NAT', sum_multi_fullnat_count)
                            if url_full_bool:
                                full_url = sub_page + '?' + tmp_query
                                count_num_multi_ip(data, full_url, sum_multi_full_url)  
                            if random_cache_bool:
                                if cache_key:
                                    count_num_multi_ip(' %s' % random_cache_value, cache_key, mgr_random_cache_list)
                        lock.release()
                                
                    process_lock.release()
                else:   
                    if lock.acquire():
                        if l7_weight_bool or l4_weight_bool:
                            list_count_weight = count_num_weight(data, 'Client ' + sourceip, list_count_weight)
                            if multi_dst_port_bool or multi_server_bool:
                                list_count_weight_dst = count_num_weight(data, '%s%s-%s' % (sourceip, Server, ServerPort), list_count_weight_dst)
              
                        if l2_dst_ip_bool:
                            list_count_l2_dst = count_num_weight(full_nat_ip, '%s%s' % (sourceip, Server), list_count_l2_dst)
                        if l2_src_ip_bool:
                            if sourceip:
                                sds = sourceip
                            else:
                                sds = 'Local'
                            list_count_l2_src = count_num_weight(full_nat_ip, sds, list_count_l2_src)
                        if l2_src_dst_ip_bool:
                            if sourceip:
                                sds = '%s-%s' % (sourceip, Server)
                            else:
                                sds = '%s-%s' % ('Local', Server)
                            list_count_l2_src_dst = count_num_weight(full_nat_ip, sds, list_count_l2_src_dst)
                        if l2_session_bool:
                            if not ('ERROR' in full_nat_ip):
                                list_count_l2_session = count_num_weight(full_nat_ip, '%s-%s<=>%s-%s' % (test_a[0],test_a[1],test_a[2],test_a[3]), list_count_l2_session)
                             
                        if url_sum_bool:
                          #  tmp_subpage = sub_page
                            list_count_weight_page = count_num_weight(data, '%s%s' % (sourceip, sub_page), list_count_weight_page)
                        if full_nat_bool:
                          #  tmp_subpage = sub_page
                            list_count_weight_fullnat = count_num_weight(full_nat_ip, '%s%s' % (sourceip, 'FULL_NAT'), list_count_weight_fullnat)
                        if url_full_bool:
                            list_count_weight_page_full = count_num_weight(data, '%s%s' % (sourceip, sub_page + '?' + tmp_query), list_count_weight_page_full)                   
                        if random_cache_bool:
                            if cache_key:
                                list_random_cache_count = count_num_weight(' %s' % random_cache_value, cache_key, list_random_cache_count)                 
                
                    lock.release()
        except  Exception, e:
            pass
            
    l7_warm_bool = g_l7_warm_bool
    l4_warm_bool = g_l4_warm_bool
    l4_weight_bool = g_l4_weight_bool
    l7_weight_bool = g_l7_weight_bool
    warm_time = ''
    data_bool = False 
    old_cookie = {}
    user_class = ''
    zjs_server_cipher = ''
    if onebyone:
        global old_o_cookie
        
    Server_cookie = "empty" 
    zjs_cert_common_name = ''
    zjs_cert_issuer = ''
    global cookie_bool
    global a, b, r_1, c, d, r_2, e, f, r_3
    global qn, mix_num, list_count_weight, list_count_weight_warm, method_num
    global query_count_weight_warm, header_count_weight_warm, cookie_count_weight_warm, fullnat_count_weight_warm
    global list_count_weight_warm, list_count, list_count_weight_page, list_count_weight_cache, list_count_weight_page_full, list_count_weight_fullnat
    global l2_src_dst_count_weight_warm,l2_src_count_weight_warm,l2_dst_count_weight_warm
    global switch
    global global_ssl_session, cache_dict
    original_cookie = 'empty'
    test_a = ()
    l7_debug_value = -1
    full_nat_str, full_nat_ip = '', ' no_header'
    full_nat_port_str, full_nat_port = '', ' no_header'
    rewrite_host_str, rewrite_host = '', ' no_header'
    rewrite_referer_str, rewrite_referer = '', ' no_header'
    rewrite_url_str, rewrite_url = '', ' no_header'
    x_forwarded_for_value_str, x_forwarded_for_value = '', ' no_header'
    display_url_str = ''

              
    if post_bool:
        
        zjs_headers = {"Connection": "keep-alive", 'Content-Type': 'application/x-www-form-urlencoded'}
        
    else:  
        zjs_headers = {"Connection": "keep-alive"}

    original_WEBServer = prefix_name + "://" + Server + ":" + ServerPort
   
        
    if header_bool:
        
        zjs_headers.update(zjs_headers_c)
        
    if source_port_bool:
        if result_reuse_bool:
            my_source_port = get_src_port(0)
        else:    
            my_source_port = get_src_port(tname - 1)
    else:
        
        my_source_port = 0

   
    cur_pyopenssl_dict = {}
    session_result_str = ''
    if pyopenssl_bool or multi_server_bool or multi_dst_port_bool:
        session_result_str = '('
        
        if pyopenssl_bool:
            cur_pyopenssl_dict = {}
            py_encryp, py_sni, py_ticket, py_reuse, py_version = '', '', '', '', ''
            cur_pyopenssl_dict['version'] = get_ssl_version()
            py_version = cur_pyopenssl_dict['version']
            cur_pyopenssl_dict['reuse'] = my_openssl_dict['reuse']
            if cur_pyopenssl_dict['reuse']:
                py_reuse = 'REUSE' 
            cur_pyopenssl_dict['ticket'] = my_openssl_dict['ticket']
            if cur_pyopenssl_dict['ticket']:
                py_ticket = 'TICKET'
                
            if my_openssl_dict['sni']:
                               
#                sni_host_bool = True   
#                if sni_host_bool:
#                
                if 'host' in zjs_headers:
                    sni_host_original_value = zjs_headers['host']
                    if ':' in sni_host_original_value:
                        sni_host_value_list = sni_host_original_value.split(':')
                        if len(sni_host_value_list) ==2:
                            cur_pyopenssl_dict['sni'] = sni_host_value_list[0]
                        else:
                            cur_pyopenssl_dict['sni'] = ':'.join(sni_host_value_list[0:-1])
                    else:
                        cur_pyopenssl_dict['sni'] = sni_host_original_value
                    
                if 'sni' not in cur_pyopenssl_dict:
                    cur_pyopenssl_dict['sni'] = Server

                py_sni = cur_pyopenssl_dict['sni'] 
                        
                  
            else:
                cur_pyopenssl_dict['sni'] = 0
    
              
            if not my_openssl_dict['encryption']:
                cur_pyopenssl_dict['encryption'] = []
               
            else:
                cur_pyopenssl_dict['encryption'] = get_ssl_encrypion()
                py_encryp = cur_pyopenssl_dict['encryption']
        #    cur_pyopenssl_dict['timeout'] = mytimeout

         #   py_encryp, py_sni, py_ticket, py_reuse, py_version
            session_result_str += py_version
            if py_reuse:
                session_result_str += ',%s' % py_reuse
            if py_ticket:
                session_result_str += ',%s' % py_ticket
            if py_encryp:
                session_result_str += ',%s' % py_encryp
            if py_sni:
                session_result_str += ',%s' % py_sni
        if multi_server_bool:
            if len(session_result_str) > 1:
                session_result_str += ',dst_ip=%s' % Server
            else:
                session_result_str += 'dst_ip=%s' % Server
                
        if multi_dst_port_bool:
            if len(session_result_str) > 1:
                session_result_str += ',dst_port=%s' % ServerPort
            else:
                session_result_str += 'dst_port=%s' % ServerPort
            
        session_result_str += ')'
          
          
          
     
    if not user_mode:    
          
        if ca_file_bool:
            http = httplib2.Http(ca_certs=ca_file)
        else:
            http = httplib2.Http(disable_ssl_certificate_validation=True)  
              #http = httplib2.Http(timeout=mytimeout, disable_ssl_certificate_validation=True, zjs_bind_ip=sourceip, zjs_source_port=my_source_port)  
    http.timeout = mytimeout
    http.zjs_bind_ip = sourceip
    http.zjs_source_port = my_source_port
    http.zjs_ssl_session = global_ssl_session
    http.zjs_ssl_para = cur_pyopenssl_dict


    out_cert_key = ''
    if client_cert_bool:

        my_cert, my_key = get_client_cert_key()
        if client_multi_cert_bool:
            out_cert_key = '[%s,%s]' % (my_cert, my_key)
        http.add_certificate(key=my_key, cert=my_cert, domain='')
      


    if user_bool:
       
        if user_single_bool or user_mode:
            http_user = user_original
            http_pass = pass_original
        else:
        
            my_user_id = str(get_id())
            http_user = user_original + my_user_id
            http_pass = pass_original + my_user_id
        http.add_credentials(http_user, http_pass, user_domain)
  
    if sourceip:
        sourceip = 'IP-' + sourceip + '-'
    my_print("\n%sstart the %s session%s %s %s at: %s \n" % (sourceip, prefix_name, session_result_str, out_cert_key, tname, ctime()))
 

    try:
        if request_unlimit_bool:
            reqnum = 'ulimit'
        else:
            reqnum = requestNum
        i = 0
        i = long(i)
        last_request_flag = 0
       
        
        while i < reqnum:
            

            if reqnum != 'ulimit':
                if i == reqnum - 1 and user_bool:
              
                    last_request_flag = 1
            if i == 0 and user_mode:
                http.zjs_user_mode_first = True
            else:
                http.zjs_user_mode_first = False
                
            if gzip_bool:
        
                zjs_headers['accept-encoding'] = 'gzip'
                request_with_zip = 'gzip'
            elif deflate_bool:
        
                zjs_headers['accept-encoding'] = 'deflate'
                request_with_zip = 'deflate'
            elif identity_bool:
        
                zjs_headers['accept-encoding'] = 'identity'
                request_with_zip = 'identity'
            elif zip_unsupport_bool:
                zjs_headers['accept-encoding'] = 'zjs-abc-haha'
                request_with_zip = 'zjs-abc-haha'
            
            elif zip_mix_bool:
                mix_num += 1
                
                if mix_num % 5 == 1:
                    zjs_headers['accept-encoding'] = 'gzip,deflate'
                    request_with_zip = 'gzip,deflate'
                elif mix_num % 5 == 2:
                    zjs_headers['accept-encoding'] = 'gzip'
                    request_with_zip = 'gzip'
                elif mix_num % 5 == 3:
                    zjs_headers['accept-encoding'] = 'deflate'
                    request_with_zip = 'deflate'
                elif mix_num % 5 == 4:
                    zjs_headers['accept-encoding'] = 'identity'
                    request_with_zip = 'identity'
                elif mix_num % 5 == 0:
                    zjs_headers['accept-encoding'] = 'unsupport'
                    request_with_zip = 'zjs-abc-haha'
            else:
                request_with_zip = 'gzip,deflate'
          
            method_num += 1
            if method_num < len_method_list:

                request_method = method_list[method_num]
            else:

                method_num = 0
                request_method = method_list[0]
            if request_method == 'POST':
                if not 'Content-Type' in zjs_headers:
                    zjs_headers['Content-Type'] = 'application/x-www-form-urlencoded'
                else:
                    if zjs_headers['Content-Type'] != 'application/x-www-form-urlencoded':
                        zjs_headers['Content-Type'] = 'application/x-www-form-urlencoded'
                if 'content-length' in zjs_headers:
                    del zjs_headers['content-length']
                sub_page = get_post_url()
                WEBServer = original_WEBServer + sub_page  
             
                body = post_body
 
            if request_method == 'GET':  
                if 'content-length' in zjs_headers:
                    del zjs_headers['content-length']
                if 'content-type' in zjs_headers:
                    del zjs_headers['content-type'] 
                body = None        
                if sub_bool:
                    if multi_sublink_bool:
                        sub_page = get_multi_sub_name()
                    else:
                        sub_page = global_sub_page
                    if not sub_page.startswith('/'):
                        sub_page = '/%s' % sub_page 
                else:
                    sub_page = '/'
                    

                WEBServer = original_WEBServer + sub_page

            
            if request_method == 'PUT':
                body = 'this is a text'
                zjs_headers['content-type'] = 'text/plain'
                zjs_headers['content-length'] = str(len(body))   
                sub_page = get_put_url()
                WEBServer = original_WEBServer + sub_page
        #        print WEBServer 

                
            if request_method == 'HEAD':
                if 'content-length' in zjs_headers:
                    del zjs_headers['content-length']
                if 'content-type' in zjs_headers:
                    del zjs_headers['content-type']
                body = None 
                sub_page = get_head_url()
                WEBServer = original_WEBServer + sub_page
           #     print WEBServer
                
            if request_method == 'TRACE':
                if 'content-length' in zjs_headers:
                    del zjs_headers['content-length']
                if 'content-type' in zjs_headers:
                    del zjs_headers['content-type']
                sub_page = get_trace_url()
                WEBServer = original_WEBServer + sub_page
              #  print WEBServer
                body = None 
            if request_method == 'OPTIONS':
                if 'content-length' in zjs_headers:
                    del zjs_headers['content-length']
                if 'content-type' in zjs_headers:
                    del zjs_headers['content-type']
               #zjs_headers = {}
                sub_page = get_option_url()
                WEBServer = original_WEBServer + sub_page
            #    print WEBServer
                body = None 
            if request_method == 'DELETE':
                if 'content-length' in zjs_headers:
                    del zjs_headers['content-length']
                if 'content-type' in zjs_headers:
                    del zjs_headers['content-type']
                sub_page = get_delete_url()
                WEBServer = original_WEBServer + sub_page
           #     print WEBServer
                
                body = None 
            if request_method == 'CONNECT':
                if 'content-length' in zjs_headers:
                    del zjs_headers['content-length']
                if 'content-type' in zjs_headers:
                    del zjs_headers['content-type']
                
                sub_page = get_connect_url()
            
                WEBServer = original_WEBServer + sub_page
            #    print WEBServer
                body = None 
            if request_method == 'CUSTOM':
                if 'content-length' in zjs_headers:
                    del zjs_headers['content-length']
                if 'content-type' in zjs_headers:
                    del zjs_headers['content-type']
                
                sub_page = custom_method_url
            
                WEBServer = original_WEBServer + sub_page
            #    print WEBServer
                body = None 
                request_method = custom_method_name
   
            if query_bool:
                q_1, q_2, q_3, q_4, q_kend, q_vend = process_four(query_a)
                q_t_1, e, f, r_3 = result_two_new(int(q_1), int(q_2), q_3, q_4, e, f, r_3, q_kend, q_vend)
                tmp_query = q_t_1[0] + "=" + q_t_1[1]
                
                if sub_query:
                    WEBServer = WEBServer + "&" + tmp_query
                else:
                    WEBServer = WEBServer + "?" + tmp_query
            
            if telnet_bool or random_cache_bool or url_sum_bool:

                match_sub_page = sub_page

                if query_bool:
                    if sub_query:
                        match_sub_page = match_sub_page + "&" + tmp_query
                    else:
                        match_sub_page = match_sub_page + "?" + tmp_query
                if url_sum_bool:
                    display_url_str = ',' + request_method + '|' + match_sub_page
                    
           
                    
                add_match_sub_page = request_method + '.' + match_sub_page + '.HTTP'
                             
            if h_a or header_cookie_bool: 
                                  
                if h_a and not header_cookie_bool:
                    m_1, m_2, m_3, m_4, m_kend, m_vend = process_four(v1)

                    h_t_1, a, b, r_1 = result_two_new(int(m_1), int(m_2), m_3, m_4, a, b, r_1, m_kend, m_vend)
                    zjs_headers[h_t_1[0].lower()] = h_t_1[1]   
                if header_cookie_bool and not h_a:
                    
                    n_1, n_2, n_3, n_4, n_kend, n_vend = process_four(mycookie_1)
                    c_t_1, c, d, r_2 = result_two_new(int(n_1), int(n_2), n_3, n_4, c, d, r_2, n_kend, n_vend)    
                    zjs_headers["Cookie"] = "=".join(c_t_1)
                    if cookie_flag == 2:
                        zjs_headers["Cookie"] = zjs_headers["Cookie"] + ';fix_cookie=constant'
                    elif cookie_flag == 1:
                        zjs_headers["Cookie"] = 'fix_cookie=constant;' + zjs_headers["Cookie"]  
               
                if header_cookie_bool and h_a:
                    m_1, m_2, m_3, m_4, m_kend, m_vend = process_four(v1)
                    h_t_1, a, b, r_1 = result_two_new(int(m_1), int(m_2), m_3, m_4, a, b, r_1, m_kend, m_vend)
                    zjs_headers[h_t_1[0].lower()] = h_t_1[1]
                    n_1, n_2, n_3, n_4, n_kend, n_vend = process_four(mycookie_1)
                    c_t_1, c, d, r_2 = result_two_new(int(n_1), int(n_2), n_3, n_4, c, d, r_2, n_kend, n_vend)
                    zjs_headers["Cookie"] = "=".join(c_t_1)
                    if cookie_flag == 2:
                        zjs_headers["Cookie"] = zjs_headers["Cookie"] + ';2nd_cookie=constant'
                    elif cookie_flag == 1:
                        zjs_headers["Cookie"] = '1st_cookie=constant;' + zjs_headers["Cookie"]  

#            if l7_debug_bool:        
#                l7_debug_value = get_header_num()
#                if sourceip_bool:
#                    l7_debug_value = index + l7_debug_value 
#                zjs_headers["zjs_debug"] = l7_debug_value  
#                l7_debug_out = ', zjs_debug: %s' % l7_debug_value 
#
#            else:
#                l7_debug_out = ''
                
            if cookie_bool and global_cookie and (onebyone or middle_bool):
                Server_cookie = global_cookie['Cookie']
                zjs_headers["Cookie"] = Server_cookie
            if not switch:
                break

            if injection_bool:
                if injection_type == 'sql':
                    if 'u' in injection_sub_type:
                        if '?' in WEBServer and '=' in WEBServer:
                            WEBServer = WEBServer + "&" + injection_pattern
                        else:
                            WEBServer = WEBServer + "?" + injection_pattern
                    if 'c' in injection_sub_type:
                        zjs_headers["Cookie"] = injection_pattern
                    if 'r' in injection_sub_type:
                        zjs_headers["referer"] = 'http://www.zjs.com/index.php?%s' % injection_pattern
                    if 'b' in injection_sub_type:
                        body = injection_pattern.split('=')[1]
                        request_method = 'POST'
                if injection_type == 'xss':
                    if 'u' in injection_sub_type:
                        if '?' in WEBServer and '=' in WEBServer:
                            WEBServer = WEBServer + "&" + injection_pattern
                        else:
                            WEBServer = WEBServer + "?" + injection_pattern
                    if 'c' in injection_sub_type:
                        zjs_headers["Cookie"] = injection_pattern
                    if 'r' in injection_sub_type:
                        zjs_headers["referer"] = 'http://www.zjs.com/index.php?%s' % injection_pattern
                    if 'b' in injection_sub_type:
                        body = injection_pattern.split('=')[1]
                        request_method = 'POST'
            if protocol_bool:
                
                
                http.zjs_protocol_dict = protocol_dict
                if 'hostname' in protocol_dict:
                    zjs_headers["host"] = protocol_dict['hostname']
                if 'max_url_name_len' in protocol_dict:
                    max_url_name_len = int(protocol_dict['max_url_name_len'])
                    
                    WEBServer = '%s%s' %(original_WEBServer,zjs_max_url_name_len(max_url_name_len))
                if 'max_url_value_len' in protocol_dict:
                    max_url_value_len = int(protocol_dict['max_url_value_len'])
                    
                    WEBServer = '%s%s' %(original_WEBServer,zjs_max_url_value_len(max_url_value_len))
                
                if 'max_url_len' in protocol_dict:
                    max_url_len = protocol_dict['max_url_len']
                    
                    max_url_value_str = zjs_random_str(int(max_url_len)-1)
                    if max_url_len >= 1:
                        WEBServer = '%s%s%s' %(original_WEBServer, '/' ,max_url_value_str)

                    else:
                        WEBServer = original_WEBServer
#                if 'max_cookie_num' in protocol_dict:
#                    cookie_bool = True
#                    max_cookie_num = int(protocol_dict['max_cookie_num'])
#                    current_cookie_num = 0
#                    if 'Cookie' in zjs_headers:
#                        current_cookie = zjs_headers["Cookie"]
#                        
#                       
#                        if ';' in current_cookie:
#                            current_cookie_num = len(current_cookie.split(';'))
#                        else:
#                            current_cookie_num = 1
#                    if current_cookie_num > max_cookie_num:
#                        new_cookie_num = max_cookie_num
#                        cookie_value = get_max_cookie_num(new_cookie_num,start=0)
#                        zjs_headers["Cookie"] = cookie_value
#                    elif current_cookie_num < max_cookie_num:
#                        new_cookie_num = max_cookie_num - current_cookie_num
#                        cookie_value = get_max_cookie_num(new_cookie_num,start=current_cookie_num)
#                        if current_cookie_num == 0:
#                            zjs_headers["Cookie"] = cookie_value
#                        else:
#                            zjs_headers["Cookie"] = current_cookie + ';' +  cookie_value
                if 'max_req_body' in protocol_dict:
                    max_request_body_len = int(protocol_dict['max_req_body'])
                    test11 = zjs_random_str(int(max_request_body_len),body_flag=1)
                    body = test11
                    request_method = 'POST'
                        
                    

                        

                        
                    
               
 
                        
   
            if "Cookie" in zjs_headers:
           
                Server_cookie = zjs_headers["Cookie"]
            if cookie_bool and not query_bool and not header_cookie_bool:                  
                my_print('%s %sThe %s %s from  session %s occurs, which is with cookie %s\n' % (strftime('%H:%M:%S', gmtime()), sourceip, i + 1, request_method, tname, Server_cookie))
            elif query_bool and not cookie_bool:
                my_print('%s %sThe %s %s from  session %s occurs, which is with query %s\n' % (strftime('%H:%M:%S', gmtime()), sourceip, i + 1, request_method, tname, tmp_query))
            elif cookie_bool and query_bool and not header_cookie_bool:
                    
                my_print('%s %sThe %s %s from session %s occurs, which is with query %s, with cookie %s\n' % (strftime('%H:%M:%S', gmtime()), sourceip, i + 1, request_method, tname, tmp_query, Server_cookie))
            else:
                my_print('%s %sThe %s %s from session %s occurs' % (strftime('%H:%M:%S', gmtime()), sourceip, i + 1, request_method, tname))
            
                            
                        
            
            request_start = time()

            try:
                
             #   test_b, responser1, content1 = http.request(WEBServer, request_method, body=body, headers=zjs_headers,zjsdebug=l7_debug_value,over_flag=last_request_flag)
                test_b, responser1, content1 = http.request(WEBServer, request_method, body=body, headers=zjs_headers, zjsdebug=l7_debug_value, over_flag=last_request_flag)
                if zjs_session_reuse_bool:
                
                    global_ssl_session = http.zjs_ssl_session
                if pyopenssl_bool:
                #    if hasattr(http, 'zjs_server_cipher'):
                    zjs_server_cipher = ',%s' % http.zjs_server_cipher
                    if http.zjs_server_cipher not in encrypt_anull_list:
                        zjs_cert_common_name = ',CN=%s' % http.zjs_cert_common_name
                        zjs_cert_issuer = ',issuer=%s' % http.zjs_cert_issuer
                    
                
                if debug_all_bool:
#                    my_print('-'*50 +'responser-header' +'-'*50)
#                    for rrr in responser1:
#                        my_print('%s %s' %(rrr,responser1[rrr]))
                    my_print('-' * 50 + 'responser-content' + '-' * 50)
      
                    my_print(content1)
                if  l4_warm_bool or l7_warm_bool:
                    warm_time = 'DATE-' + strftime('%H:%M:%S', gmtime())
                
                test_a = (test_b[0], test_b[1], Server, ServerPort)      
                    
                zjs_local_usertype = http.zjs_user_type
                if user_bool:
                    zjs_local_usertype = http.zjs_user_type
                    zjs_user_realm = http.zjs_user_realm
             
                    if zjs_local_usertype != 'no':
                        user_class = ', %s->%s' % (http_user, zjs_local_usertype.split("'")[1].split('.')[1])
                    if zjs_user_realm:
                        user_class += ', realm->%s' % zjs_user_realm 
  
                
                if '-content-encoding' in  responser1:
                    
                    enconding = ',%s' % responser1['-content-encoding']
                
                else:

                    enconding = ',identity'
                

                if full_nat_bool:        
                    if 'fullnat_ip' in responser1:
                        full_nat_ip = ' %s' % responser1['fullnat_ip']
                        full_nat_str = ',lb_src_ip=%s' % full_nat_ip
                    else:
                        full_nat_ip = '%s_%s' % (full_nat_ip, responser1.status)
                    if 'fullnat_port' in responser1:
                        full_nat_port = responser1['fullnat_port']
                        full_nat_port_str = ',lb_src_port=%s' % full_nat_port
                    
                    
                if rewrite_bool:
                    if 'rewrite_host' in responser1: 
                        rewrite_host = responser1['rewrite_host']
                        if rewrite_host:
                            rewrite_host_str = ',rewrite_host=%s' % rewrite_host
                    if 'rewrite_referer' in responser1: 
                        rewrite_referer = responser1['rewrite_referer']
                        if rewrite_referer:
                            rewrite_referer_str = ',rewrite_referer=%s' % rewrite_referer
                    if 'rewrite_url' in responser1: 
                        rewrite_url = responser1['rewrite_url']
                        if rewrite_url:
                            rewrite_url_str = ',rewrite_url=%s' % rewrite_url  
                    if 'x-forwarded-for' in responser1: 
                        x_forwarded_for_value = responser1['x-forwarded-for']
                        if x_forwarded_for_value:
                            x_forwarded_for_value_str = ',x-forwarded-for=%s' % x_forwarded_for_value
                                                
                        
                        
                        
        
                if output_time:
                    request_over = time()
                    request_cost_time = request_over - request_start

#                    if request_cost_time > accuracy_a and responser1.status == 200:
#                        if l7_debug_bool:
#                            test_a = list(test_a)
#                            
#                            test_a.append(l7_debug_value)
#                            test_a = tuple(test_a)
#                            httplib2.request_error_dic[test_a] = request_cost_time
#                        else:
#                            test_a = list(test_a)
#                            test_a.append('')
#                            test_a = tuple(test_a)
#                            httplib2.request_error_dic[test_a] = request_cost_time
                        
                if telnet_bool: 
                            
                    adc_sniffer_cache_bool = adc_sniffer_func(add_match_sub_page)
                    if adc_sniffer_cache_bool:
                        cache_value = ' No-Hit-Cache'
                    else:
                        cache_value = ' Hit-Cache'
                    
                    cache_pair = ',%s ->%s' % (match_sub_page, cache_value)
                    if sourceip_bool:
                        ip_prefix_head = 'IP-'
                    else:
                        ip_prefix_head = ''
                    
                    if sourceip_bool:
                        count_num_multi_ip(cache_value, match_sub_page, sum_multi_cache_count)                                      
                    list_count_weight_cache = count_num_weight(cache_value, ip_prefix_head + sourceip + match_sub_page, list_count_weight_cache)
                                           
                else:
                    cache_pair = ''
                if random_cache_bool:
                    if sourceip_bool:
                        if process_lock.acquire():
                            if lock.acquire():
                                cache_key, random_cache_value, random_cache_pair = get_random_cache_result(responser1, match_sub_page, request_method, mgr_random_cache_dict)
                                lock.release()
                            process_lock.release()
                    else:
                        if lock.acquire():
                            cache_key, random_cache_value, random_cache_pair = get_random_cache_result(responser1, match_sub_page, request_method, cache_dict)
                            lock.release()
                else:
                    random_cache_pair = ''

               # if sourceip_bool:
                 #   print mgr_random_cache_dict
                #else:
                #    print cache_dict
                        
                    
        
                if rs_ip_header in responser1:
                    data = ' %s' % responser1[rs_ip_header]
                    data_bool = True
     
                   
                if request_method == 'PUT'  or request_method == 'DELETE' or request_method == 'OPTIONS' or request_method == 'HEAD':
        
                    if not data_bool:
                        my_print('%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s \n' % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1], enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason))
                        #print data_bool
                elif request_method == 'TRACE':
                    if not data_bool:
                        my_print('%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s \n' % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1], enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason))
                    
                    
                else:
                    if data_bool:
                        non_200 = ', it come from%s' % data
                    else:
                        non_200 = ''  
                    
                    if responser1.status != 200:  
                    
                        if not data_bool:   
                                
                            if responser1.status == 503:
                                my_print("%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s %s \n" % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1], user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason, content1))
    
                            
                            else:
                                my_print("%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s \n" % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1], user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason))
#                            if l7_debug_bool:
#                                test_a = list(test_a) 
#                                test_a.append(l7_debug_value)
#                                test_a = tuple(test_a)
#                                httplib2.request_error_dic[test_a] = 'code-%s' % responser1.status
#                            else:
#                                test_a = list(test_a)
#                                test_a.append('')
#                                test_a = tuple(test_a)
#                                httplib2.request_error_dic[test_a] = 'code-%s' % responser1.status
                    else:
                        
                        if request_method == 'GET':
    
                            if WEBServer != responser1['content-location']:
    
                                 
                                if responser1.previous is not None:
                                    my_print("%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s, it is redirected by middle page, the status from middle page is %s, Location info is %s\n" % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1],cache_pair, random_cache_pair, user_class, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason, responser1.previous['status'], responser1.previous['location']))
                                else:
                                    my_print("%s %sThere maybe redirection during your visit, but Client couldn't receieve any redirection info from server" % (strftime('%H:%M:%S', gmtime()), sourceip))
                            else:
                                
                                if not ('content-type' in responser1.keys()) or sub_query:
                              
                                    search_ip = search(p1, content1)
                                    if search_ip is None:
                                        if not data_bool:
                                            
                                            my_print("%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s,it doesn't take any ip address or matched regular expression \n" % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1], enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason))
                                           
                                    else:
                                            
                                        data = ' %s' % search_ip.group()
                                        data_bool = True   
                                   
                                else:
                             
                                    content_type_value = responser1['content-type'].split(';')[0]
                                    if content_type_value not in compress_type:
                                        if not data_bool:
                                    
                                            my_print('%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s. the content you request is a file\n' % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1], enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason))
                                    else:
                              
                                        search_ip = search(p1, content1)
                                  
                                        if search_ip is None:
                                            if not data_bool:
                                                my_print("%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s,it doesn't take any ip address or matched regular expression \n" % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1],enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason))
                                        else:
                                            data = ' %s' % search_ip.group()
                                            data_bool = True
                                  
        
                                    
                        else:
                            search_ip = search(p1, content1)
                            if search_ip is None and not data_bool:
                                my_print("%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s,it doesn't take any ip address or matched regular expression \n" % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1], enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason))
                            else:
                                data = " %s" % search_ip.group()
                                data_bool = True
                        
                        
                 
                if data_bool:
                   
                        
                    if cookie_bool:
                          if responser1.has_key('set-cookie'):
                              if onebyone or middle_bool:
                                  old_o_cookie, taken_cookie, Server_cookie = http.cookie_process(old_o_cookie, responser1['set-cookie'])
                              else:    
                                  old_cookie, taken_cookie, Server_cookie = http.cookie_process(old_cookie, responser1['set-cookie'])

                          
                              zjs_headers['Cookie'] = Server_cookie
                              my_print('%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s, it takes cookie: %s , coming from%s \n' % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1], enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason, taken_cookie, data))
                          else:
                              my_print('%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s, it takes cookie: %s , coming from%s \n' % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1],enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason, original_cookie, data))   
                    else:
                     
                        my_print('%s %sThe reply for %s %s (%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s) in session %s is %s %s, it comes from %s \n' % (strftime('%H:%M:%S', gmtime()), sourceip, request_method, i + 1, 'source_port=%s' % test_a[1],enconding, user_class, cache_pair, random_cache_pair, zjs_server_cipher, zjs_cert_common_name, zjs_cert_issuer, full_nat_str, full_nat_port_str, rewrite_host_str, rewrite_referer_str, rewrite_url_str, x_forwarded_for_value_str, display_url_str, tname, responser1.status, responser1.reason, data))
              
                    if not no_output_bool:
                      
                          
                        all_account(full_nat_ip, data=data, warm_time=warm_time,test_a=test_a)
                else:
                     all_account(full_nat_ip, data=' NO-IP-INFO', warm_time=warm_time,test_a=test_a)
           
                if h_a:
                    del zjs_headers[h_t_1[0].lower()]
                    
                if header_cookie_bool:
                    del zjs_headers["Cookie"]                    

                 
            except Exception, e:
                if g_l4_warm_bool or g_l7_warm_bool:
                    warm_time = 'DATE-' + strftime('%H:%M:%S', gmtime()) 
                else:
                    print '%s %sThe %s %s from session %s %s meet a problem due to "%s" ' % (strftime('%H:%M:%S', gmtime()), sourceip, i + 1, request_method, tname, session_result_str, e)
              
                all_account(' SESSION-ERROR', data=' SESSION-ERROR', warm_time=warm_time,test_a=[])  
                break
              
            i += 1  
            if (onebyone or middle_bool) and cookie_bool and Server_cookie != 'empty':
           
                global_cookie['Cookie'] = Server_cookie   
            data_bool = False   
            if reqnum != 1:
                l4_warm_bool = False
                l4_weight_bool = False
                if i < reqnum:

                    if speed_up_bool and not onebyone and not middle_bool:
                        if sourceip_bool:
                            speed_num = multi_dict['adjust_speed']
                            n = speed_ip_num * SessionNum
                     
                        else:
                            speed_num = adjust_speed
                            n = SessionNum
                        try:
                            req_interval = get_new_interval(requestInterval, speed_num, n)
                            sleep(req_interval)
                        except Exception, e:
                            switch = False
                            break
                   
                   
                    else:
                        if local_warm_bool and requestInterval >= 1:
                            tmp_bbb = str(time()).split('.')[1][0]
                            if tmp_bbb == '0':
                                req_interval = requestInterval
                            else:
                                req_interval = requestInterval - float('0.' + str(time()).split('.')[1][0]) + 0.1
                        else:
                            req_interval = requestInterval
                        sleep(req_interval)

    except Exception, e:
#        if g_l7_warm_bool or g_l4_warm_bool or g_l7_warm_bool:
#            pass
#        else:
            if not g_l4_warm_bool or g_l7_warm_bool:
                print "%s %sSub Thread has met a problem as follows" % (strftime('%H:%M:%S', gmtime()), sourceip)
         
                print e
          
            
            sys.exit() 


key_cookie_bool = False
key_header_bool = False
key_query_bool = False 
key_dst_bool = False
key_fullnat_bool = False
key_l2_dst_bool,key_l2_src_bool,key_l2_src_dst_bool = False,False,False

def warm_loop(sourceip, main_flag=False):
    global result_sum_chq
    def process(search_time, bool_flag='default'):
           
        r_list = [] 
        d_list = []
        global test_warm
        
        if bool_flag == 'cookie':
            test_warm = cookie_count_weight_warm
        elif bool_flag == 'header':
            test_warm = header_count_weight_warm
        elif bool_flag == 'query':
            test_warm = query_count_weight_warm        
        elif bool_flag == 'default':
            test_warm = list_count_weight_warm
        elif bool_flag == 'dst':
            test_warm = list_count_dst_warm
        elif bool_flag == 'fullnat':
            test_warm = fullnat_count_weight_warm
        elif bool_flag == 'l2_src':
            test_warm = l2_src_count_weight_warm
        elif bool_flag == 'l2_dst':
            test_warm = l2_dst_count_weight_warm
        elif bool_flag == 'l2_src_dst':
            test_warm = l2_src_dst_count_weight_warm
        for i in test_warm:
            if bool_flag != 'default':
                if search_time == sorted(i.keys())[-1].split('| ')[1]:
                    r_list.append(i)
    
                    query_out(r_list)
                    r_list = []
                    
                    d_list.append(i)
            else:
                if search_time in i.keys(): 
      
                    r_list.append(i)
                    query_out(r_list)
                    r_list = []
                    d_list.append(i)
       
            for j in i:
                if 'DATA' in j:
                    if j.strip() < search_time:
                        d_list.append(i)
                        
        for d_i in d_list:
            test_warm.remove(d_i)
            
    def process_multi(search_time, flag, time_flag=1):
        
      #  if process_lock.acquire():
            try:
         
                if flag == 'souceip':
                    my_multi_ip_account_list = list(multi_ip_account_list)
                    
                   
                if flag == 'cookie':
                    my_multi_ip_account_list = list(multi_cookie_account_list)
                if flag == 'header':
                    my_multi_ip_account_list = list(multi_header_account_list)
                if flag == 'query':
                    my_multi_ip_account_list = list(multi_query_account_list) 
                if flag == 'dst':
                    my_multi_ip_account_list = list(multi_dst_account_list)
                if flag == 'fullnat':
                    my_multi_ip_account_list = list(multi_fullnat_account_list)
                if flag == 'l2_src':
                    my_multi_ip_account_list = list(multi_l2_src_account_list)
                if flag == 'l2_dst':
                    my_multi_ip_account_list = list(multi_l2_dst_account_list)
                if flag == 'l2_src_dst':
                    my_multi_ip_account_list = list(multi_l2_src_dst_account_list)
                if flag == 'default':
                    global list_count_weight_warm
                    my_multi_ip_account_list = list(list_count_weight_warm)     
                for index, i in enumerate(my_multi_ip_account_list):
                    r_list = []
                    t_list = []
         
                    temp_bool = False
                    t1 = 0
                    for zzz in i.keys():
                        if search(search_time, zzz) is not None:
                            temp_bool = True
                        elif time_flag:
                            if '| DATE' in zzz:
            
                                t1 = zzz.split('|')[1].strip()
           
                            elif 'DATE' in zzz:
            
                                t1 = zzz.strip()
      
    
                                        
                    if temp_bool:
  
                        r_list.append(i)
                               
                        query_out(r_list)
    
                    
                        try:
                            if flag == 'souceip':
                                
                                multi_ip_account_list.remove(i)
    
                         
                            elif flag == 'cookie':
                                multi_cookie_account_list.remove(i)
                            elif flag == 'header':
                          
                                multi_header_account_list.remove(i)
                           
            
                            elif flag == 'query':                 
                                multi_query_account_list.remove(i)
                            elif flag == 'dst':                 
                                multi_dst_account_list.remove(i)
                            elif flag == 'fullnat':                 
                                multi_fullnat_account_list.remove(i)     
                            elif flag == 'l2_src':                 
                                multi_l2_src_account_list.remove(i)  
                            elif flag == 'l2_dst':                 
                                multi_l2_dst_account_list.remove(i)  
                            elif flag == 'l2_src_dst':                 
                                multi_l2_src_dst_account_list.remove(i)    
                            elif flag == 'default':      
                                list_count_weight_warm.remove(i)                         
                        except Exception, e:
                            pass
                           # print e
                            #print "aaaaaaaaaaaaa"
    
                    if time_flag:
    
                        if t1 != 0:
            
                            if t1 < search_time:
                                
                                try:
            
                                    if flag == 'souceip':
                                        
                                        multi_ip_account_list.remove(i)
                
                                 
                                    elif flag == 'cookie':
                                        multi_cookie_account_list.remove(i)
                                    elif flag == 'header':
                                  
                                        multi_header_account_list.remove(i)
                                   
                    
                                    elif flag == 'query':                 
                                        multi_query_account_list.remove(i)
                                    elif flag == 'dst':                 
                                        multi_dst_account_list.remove(i)
                                    elif flag == 'fullnat':                 
                                        multi_fullnat_account_list.remove(i)
                                    elif flag == 'l2_src':                 
                                        multi_l2_src_account_list.remove(i)  
                                    elif flag == 'l2_dst':                 
                                        multi_l2_dst_account_list.remove(i)  
                                    elif flag == 'l2_src_dst':                 
                                        multi_l2_src_dst_account_list.remove(i)  
                                    elif flag == 'default':
                                        
                                        list_count_weight_warm.remove(i)
         
                                except Exception, e:

                                    print "111111111%s" % e

                                           
            except Exception, e:
                pass
                #print e
                #print "bbbbbbbbbbbbbbbbb"

        #    process_lock.release() 
    
    try: 

        while True:
            if switch:
                

                search_time = 'DATE-' + strftime('%H:%M:%S', gmtime())
                sleep(1)
      
                if sourceip_bool:
                    if query_bool or h_a or header_cookie_bool:
                  
                        result_sum_chq = list(sum_multi_list_count) 
           
                    if multi_dict['s_cookie_bool'] and main_flag:
                        process_multi(search_time, flag='cookie')
                       
                    elif multi_dict['s_header_bool'] and main_flag:
                        process_multi(search_time, flag='header')
                 
                    elif multi_dict['s_query_bool'] and main_flag:
                       
                        process_multi(search_time, flag='query')
                    elif multi_dict['s_dst_bool'] and main_flag:
                        process_multi(search_time, flag='dst') 
                    elif multi_dict['s_fullnat_bool'] and main_flag:
                        process_multi(search_time, flag='fullnat') 
                    elif multi_dict['l2_src_bool'] and main_flag:
                        process_multi(search_time, flag='l2_src') 
                    elif multi_dict['l2_dst_bool'] and main_flag:
                        process_multi(search_time, flag='l2_dst') 
                    elif multi_dict['l2_src_dst_bool'] and main_flag:
                        process_multi(search_time, flag='l2_src_dst') 
                        
                    elif not multi_dict['s_bool'] and main_flag:
                        process_multi(search_time, flag='souceip')   
                                               
                    else:
                 
                        process_multi(search_time, flag='default')
              
                       
                else:
                    if key_cookie_bool:
                        process(search_time, bool_flag='cookie')
        
                           
                    elif key_header_bool:
                        process(search_time, bool_flag='header')
        
                    elif key_query_bool:
        
                        process(search_time, bool_flag='query')  
                    elif  key_dst_bool:
                        process(search_time, bool_flag='dst')  
                    elif  key_fullnat_bool:
                        process(search_time, bool_flag='fullnat')
                    elif  key_l2_src_bool:
                        
                        process(search_time, bool_flag='l2_src')
                    elif  key_l2_dst_bool:
                        
                        process(search_time, bool_flag='l2_dst')
                    elif  key_l2_src_dst_bool:
                        process(search_time, bool_flag='l2_src_dst')
                    else:   
                        process(search_time)
            else:
                break
               
    except Exception, e:
     
        pass
                                          
                       
def get_key_bool():   
    import select, contextlib
    import tty, termios
    @contextlib.contextmanager
    def decanonize(fd):
        old_settings = termios.tcgetattr(fd)
        new_settings = old_settings[:]
        new_settings[3] = new_settings[3] & ~termios.ICANON & ~termios.ECHO
        termios.tcsetattr(fd, termios.TCSAFLUSH, new_settings)
        yield
        termios.tcsetattr(fd, termios.TCSAFLUSH, old_settings)
    global s_bool
    global key_cookie_bool 
    global key_header_bool
    global key_query_bool, cache_debug_bool, key_fullnat_bool
    global adjust_speed, key_dst_bool
    global key_l2_dst_bool,key_l2_src_bool,key_l2_src_dst_bool
    
    with decanonize(sys.stdin.fileno()):
        while switch:
            i, o, e = select.select([sys.stdin], [], [], 1)
            if i and i[0] == sys.stdin:
                input = sys.stdin.read(1)
                if sourceip_bool:
                    if input == 'i' or input == 'I':
                        multi_dict['s_bool'] = not multi_dict['s_bool']
                        multi_dict['s_cookie_bool'] = False
                        multi_dict['s_header_bool'] = False
                        multi_dict['s_query_bool'] = False   
                        multi_dict['s_dst_bool'] = False
                        multi_dict['s_fullnat_bool'] = False
                        multi_dict['l2_src_bool'] = False
                        multi_dict['l2_dst_bool'] = False
                        multi_dict['l2_src_dst_bool'] = False
                        
                                                                   
                    elif (input == 'c' or input == 'C')  and (header_cookie_bool or cookie_bool):
                        multi_dict['s_cookie_bool'] = not multi_dict['s_cookie_bool']
                        multi_dict['s_header_bool'] = False
                        multi_dict['s_query_bool'] = False
                        multi_dict['s_dst_bool'] = False
                        multi_dict['s_fullnat_bool'] = False
                        multi_dict['l2_src_bool'] = False
                        multi_dict['l2_dst_bool'] = False
                        multi_dict['l2_src_dst_bool'] = False

                    elif (input == 'q' or input == 'Q') and query_bool:
                        multi_dict['s_query_bool'] = not multi_dict['s_query_bool']
                        multi_dict['s_cookie_bool'] = False
                        multi_dict['s_header_bool'] = False
                        multi_dict['s_dst_bool'] = False
                        multi_dict['s_fullnat_bool'] = False
                        multi_dict['l2_src_bool'] = False
                        multi_dict['l2_dst_bool'] = False
                        multi_dict['l2_src_dst_bool'] = False

                    elif (input == 'h' or input == 'H')  and h_a:
                        multi_dict['s_header_bool'] = not multi_dict['s_header_bool']
                        multi_dict['s_cookie_bool'] = False
                        multi_dict['s_query_bool'] = False
                        multi_dict['s_dst_bool'] = False
                        multi_dict['s_fullnat_bool'] = False
                        multi_dict['l2_src_bool'] = False
                        multi_dict['l2_dst_bool'] = False
                        multi_dict['l2_src_dst_bool'] = False
                    elif input == ('t' or input == 'T') and (telnet_bool or random_cache_bool):
                        cache_debug_bool = not cache_debug_bool
                    elif input == ('u' or input == 'U') and speed_up_bool:
                        multi_dict['adjust_speed'] = multi_dict['adjust_speed'] + speed_add_num
                        print ' Speed will increase %s' % speed_add_num
                    elif (input == 'd' or input == 'D') and speed_up_bool:
                        multi_dict['adjust_speed'] = multi_dict['adjust_speed'] - speed_add_num
                        print ' Speed will decrease %s' % speed_add_num
                    elif (input == 'm' or input == 'M') and (multi_dst_port_bool or multi_server_bool):
                        multi_dict['s_dst_bool'] = not multi_dict['s_dst_bool']
                        multi_dict['s_cookie_bool'] = False
                        multi_dict['s_header_bool'] = False
                        multi_dict['s_query_bool'] = False
                        multi_dict['s_fullnat_bool'] = False
                        multi_dict['l2_src_bool'] = False
                        multi_dict['l2_dst_bool'] = False
                        multi_dict['l2_src_dst_bool'] = False
                    elif input == 'f' or input == 'F' :
                        multi_dict['s_fullnat_bool'] = not multi_dict['s_fullnat_bool']
                        multi_dict['s_dst_bool'] = False
                        multi_dict['s_cookie_bool'] = False
                        multi_dict['s_header_bool'] = False
                        multi_dict['s_query_bool'] = False    
                        multi_dict['s_bool'] = False 
                        multi_dict['l2_src_bool'] = False
                        multi_dict['l2_dst_bool'] = False
                        multi_dict['l2_src_dst_bool'] = False  
                    elif input == '1':
                        multi_dict['l2_src_bool'] = not multi_dict['l2_src_bool']
                        multi_dict['s_fullnat_bool'] = False
                        multi_dict['s_dst_bool'] = False
                        multi_dict['s_cookie_bool'] = False
                        multi_dict['s_header_bool'] = False
                        multi_dict['s_query_bool'] = False    
                        multi_dict['s_bool'] = False
                        multi_dict['l2_src_dst_bool'] = False
                        multi_dict['l2_dst_bool'] = False
                    elif input == '2':
                        multi_dict['l2_dst_bool'] = not multi_dict['l2_dst_bool']
                        multi_dict['s_fullnat_bool'] = False
                        multi_dict['s_dst_bool'] = False
                        multi_dict['s_cookie_bool'] = False
                        multi_dict['s_header_bool'] = False
                        multi_dict['s_query_bool'] = False    
                        multi_dict['s_bool'] = False
                        multi_dict['l2_src_dst_bool'] = False
                        multi_dict['l2_src_bool'] = False
                        
                    elif input == '3':
                        multi_dict['l2_src_dst_bool'] = not multi_dict['l2_src_dst_bool']
                        multi_dict['s_fullnat_bool'] = False
                        multi_dict['s_dst_bool'] = False
                        multi_dict['s_cookie_bool'] = False
                        multi_dict['s_header_bool'] = False
                        multi_dict['s_query_bool'] = False    
                        multi_dict['s_bool'] = False
                        multi_dict['l2_src_bool'] = False
                        multi_dict['l2_dst_bool'] = False

                          
                    
                
                else:    
                    if (input == 'c' or input == 'C')  and (header_cookie_bool or cookie_bool):
                        key_cookie_bool = not key_cookie_bool
                        key_header_bool = False
                        key_query_bool = False
                        key_dst_bool = False
                        key_fullnat_bool = False
                        key_l2_dst_bool,key_l2_src_bool,key_l2_src_dst_bool = False,False,False
                    elif (input == 'q' or input == 'Q')  and query_bool:
                        key_cookie_bool = False
                        key_header_bool = False
                        key_dst_bool = False
                        key_fullnat_bool = False
                        key_l2_dst_bool,key_l2_src_bool,key_l2_src_dst_bool = False,False,False
                        key_query_bool = not key_query_bool
                    elif (input == 'h' or input == 'H')  and h_a:
                        key_cookie_bool = False
                        key_header_bool = not key_header_bool
                        key_query_bool = False
                        key_dst_bool = False
                        key_fullnat_bool = False
                        key_l2_dst_bool,key_l2_src_bool,key_l2_src_dst_bool = False,False,False
                    elif (input == 't' or input == 'T') and (telnet_bool or random_cache_bool):
                        cache_debug_bool = not cache_debug_bool
                    elif (input == 'u' or input == 'U') and speed_up_bool:
                        adjust_speed = adjust_speed + speed_add_num    
                        print ' Speed will increase %s' % speed_add_num
                    elif (input == 'd' or input == 'D') and speed_up_bool:                    
                        adjust_speed = adjust_speed - speed_add_num    
                        print ' Speed will decrease %s' % speed_add_num
                    elif (input == 'm' or input == 'M') and (multi_dst_port_bool or multi_server_bool):
                        key_dst_bool = not key_dst_bool
                        key_cookie_bool = False
                        key_header_bool = False
                        key_query_bool = False
                        key_fullnat_bool = False
                        key_l2_dst_bool,key_l2_src_bool,key_l2_src_dst_bool = False,False,False
                    elif input == 'f' or input == 'F' :
                        key_fullnat_bool = not key_fullnat_bool  
                        key_cookie_bool = False
                        key_header_bool = False
                        key_query_bool = False
                        key_dst_bool = False
                        key_l2_dst_bool,key_l2_src_bool,key_l2_src_dst_bool = False,False,False
                    elif input == '1':
                        key_l2_src_bool = not key_l2_src_bool
                        key_l2_dst_bool = False
                        key_l2_src_dst_bool = False
                        key_fullnat_bool = False 
                        key_cookie_bool = False
                        key_header_bool = False
                        key_query_bool = False
                        key_dst_bool = False
                    elif input == '2':
                        key_l2_dst_bool = not key_l2_dst_bool
                        key_l2_src_bool = False
                        key_l2_src_dst_bool = False
                        key_fullnat_bool = False 
                        key_cookie_bool = False
                        key_header_bool = False
                        key_query_bool = False
                        key_dst_bool = False
                    elif input == '3':
                        key_l2_src_dst_bool = not key_l2_src_dst_bool
                        key_l2_dst_bool = False
                        key_l2_src_bool = False
                        key_fullnat_bool = False 
                        key_cookie_bool = False
                        key_header_bool = False
                        key_query_bool = False
                        key_dst_bool = False

                  
                        
                    
                    
       
def warm_time_revision():
    #import signal, os

#    def handler(signum, frame):
#        pass
#    
#    # Set the signal handler and a 5-second alarm
#    sleep_time = 1 - float('0.' + str(datetime.now().microsecond))
#    signal.signal(signal.SIGALRM, handler)
#    signal.alarm(sleep_time)    
#    print time()

#    
#    def nothing_pass():
#        pass
#    from sched import scheduler
##
#    from datetime import datetime
##
#    s = scheduler(time,sleep)
#    sleep_time = 1 - float('0.' + str(datetime.now().microsecond))
#    print sleep_time
##
#    s.enter(sleep_time,1,nothing_pass,())
#    print time()


    start_time = int(str(time()).split('.')[0]) + 1

    while True:
        if start_time == int(str(time()).split('.')[0]):
            break   
        sleep(0.01)



switch = True
#if sourceip_bool:
#    
##    if not no_output_bool:
##    
##        log_file = open('result_log.txt', 'a+', 0)
##        log_file.truncate()
##        separate_time = ctime() 
##        log_file.write(separate_time + '\n')
##        log_file.write('------------------------------------------------------------------------------------------------\n')
##        log_file.write(' '.join(sys.argv) + '\n' * 3)
##    else:
##        log_file = None
      

def my_main(si=0,work_result_port_list=result_port_list,work_server_list=server_list):

    
    def cost_time_func(sourceip):
        global cost_time
        bb = time()
        cost_time = bb - aa
        if not sourceip_bool:
            if onebyone:
                cost_time = cost_time - connection_interval
                
            elif middle_interval:
                cost_time = cost_time - middle_interval
            
            print cost_time
        else:
            if onebyone:
                multi_dict[sourceip] = cost_time - connection_interval
                
            elif middle_interval:
                multi_dict[sourceip] = cost_time - middle_interval
            else:
                multi_dict[sourceip] = cost_time
            
    def close_action(ctrl=0):
        global switch
        switch = False
        sleep(ctrl)
        if telnet_bool:
            for i in map_file_child:

                i[0].close(force=True)
                i[1].close()
           
        if query_bool or h_a or header_cookie_bool:
            if sourceip_bool:
#                sleep(1)
                query_out(list_count)
            else:
                print "\n"
                print "\n"
                query_out(list_count)
        if random_cache_bool and load_cache_file_bool and not sourceip_bool:
            cache_file = file(cache_file_name, 'wb')
            if cache_dict:
                cache_dict['time'] = time()
                dump(cache_dict, cache_file)
            cache_file.close()
            

        if url_sum_bool or weight_bool or telnet_bool or random_cache_bool or full_nat_bool:
            if sourceip_bool:
                pass
#                if not asynchronous_bool:
#                    sleep(1)
#                if url_sum_bool:
#                    if sourceip_bool:
#                       print '*' * 130
#                       print 'The URL summary from %s\n' % sourceip
#                    query_out(list_count_weight_page, flag=False)
#                if full_nat_bool:
#                    if sourceip_bool:
#                       print '*' * 130
#                       print 'The LB_interface_IP summary from %s\n' % sourceip
#                    query_out(list_count_weight_fullnat, flag=False)
#                if l2_src_ip_bool:
#                    print '*' * 130
#                    print "The L2_SRC_IP summary from %s \n" % sourceip
#                    query_out(list_count_l2_dst, flag=False)
#                if l2_dst_ip_bool:
#                    print '*' * 130
#                    print "The L2_DEST_IP summary from %s \n" % sourceip
#                    query_out(list_count_l2_dst, flag=False)
#                if l2_src_dst_ip_bool:
#                    print '*' * 130
#                    print "The L2_SRC_DEST_PAIR summary from %s \n" % sourceip
#                    query_out(list_count_l2_dst, flag=False)
#                    
#                if url_full_bool:
#                    if sourceip_bool:
#                       print '*' * 130
#                       print 'The Full URL summary from %s\n' % sourceip
#                    query_out(list_count_weight_page_full, flag=False)  
#                if telnet_bool:
#                    if sourceip_bool:
#                       print '*' * 130
#                       print 'The Sniffer Cache summary from %s\n' % sourceip
#                    query_out(list_count_weight_cache)
#                if random_cache_bool:
#                    if sourceip_bool:
#                       print '*' * 130
#                       print 'The Random Cache summary from %s\n' % sourceip
#                    query_out(list_random_cache_count, flag=False)
#               
#                     
#                if weight_bool:
##                    if sourceip_bool:
##                       print '*' * 130
##                       print 'The  summary from %s\n' % sourceip
##                       
##                    query_out_sourceip(list_count_weight)
#                    if multi_dst_port_bool or multi_server_bool:
#                        print '*' * 130
#                        print "The IP-PORT-RANGE summary from %s \n" % sourceip
#                        query_out(list_count_weight_dst, flag=False)

                        
                 

            else:
                print "\n"
                if full_nat_bool:
                    print '*' * 60 + 'LB-Interface-IP' + '*' * 60
                    query_out(list_count_weight_fullnat, flag=False)
                if url_sum_bool:
                    print '*' * 60 + 'URL' + '*' * 60
                    query_out(list_count_weight_page, flag=False)
                if url_full_bool:
                    print '*' * 60 + 'FULL-URL' + '*' * 60
                    query_out(list_count_weight_page_full, flag=False)                 
                if l2_src_ip_bool:
                    print '*' * 60 + 'L2-SRC-IP' + '*' * 60
                    query_out(list_count_l2_src)
                if l2_dst_ip_bool:
                    #print '*' * 130
                    print '*' * 60 + 'L2_DEST_IP' + '*' * 60
                    query_out(list_count_l2_dst)
                if l2_src_dst_ip_bool:
                    #print '*' * 130
                    print '*' * 60 +  'L2_SRC_DEST_IP_PAIR' + '*' * 60
                    query_out(list_count_l2_src_dst)
                if l2_session_bool:
                    #print '*' * 130
                    print '*' * 60 +  'L2_SESSION' + '*' * 60
                    query_out(list_count_l2_session)
                if telnet_bool:
                    print '*' * 60 +  'SNIFFER-CACHE' + '*' * 60
                    query_out(list_count_weight_cache)
                if random_cache_bool:
                    print '*' * 60 +  'RANDOM-CACHE' + '*' * 60
                    query_out(list_random_cache_count)
                if weight_bool:
                    if multi_dst_port_bool or multi_server_bool:
                       # print '*' * 130
                        print '*' * 60 +  'IP-PORT-RANGE' + '*' * 60
                        query_out(list_count_weight_dst)
                        
                    print '*' * 60 +  'TOTAL-SUMMARY' + '*' * 60
                    query_out(list_count_weight, flag=False)                                        
           #     print '*' * 50     
    
   
        if output_time:
            if sourceip_bool:
                if not asynchronous_bool:
                    sleep(0.5)
       #     source_port_out(error_dict) 
            #source_port_out(httplib2.request_error_dic)            
    if not sourceip_bool:
        sys_tcp_limit()
  #  error_dict = {} 
    global lock
    lock = threading.Lock()
    if si == 0:
        str_sip, sourceip = '', ''       
    else:
        sourceip = si
        str_sip = 'IP_%s_' % si
    global switch, Server
    
    if user_mode:
        if ca_file_bool:
            http = httplib2.Http(ca_certs=ca_file)
        else:
            http = httplib2.Http(disable_ssl_certificate_validation=True)
    else:
        http = ''       
#    if l7_debug_bool and sourceip_bool:
#        index = 'IP_' + str(index) + '_'

    
    if telnet_bool:
        

        global map_file_child 
      
        map_file_child = start_telnet()
        
            
                
 
        
        
    try:
#        for i in xrange(SessionNum):
#            t = threading.Thread(target=loop, args=(i + 1, sourceip, http,index))
#            Sessions.append(t)

        if not sourceip_bool and (telnet_bool or speed_up_bool or random_cache_bool) and not local_warm_bool: 
         
            get_key_thread = threading.Thread(target=get_key_bool)
            get_key_thread.start()
            
        if g_l4_warm_bool or g_l7_warm_bool:
            warm_thread = threading.Thread(target=warm_loop, args=(sourceip,))
            if not sourceip_bool:
                warm_time_revision()
                if header_cookie_bool or h_a or query_bool or full_nat_bool or speed_up_bool or random_cache_bool or multi_dst_port_bool or multi_server_bool or full_nat_bool:
                    get_key_thread_sub = threading.Thread(target=get_key_bool)
                    get_key_thread_sub.start()
            warm_thread.start()
            

  
        aa = time()
        iii = 0
        i = 0
      
        if session_unlimit_bool:
            ses_num = 'a'
        else:
            ses_num = SessionNum
  
        while i < ses_num:
            if multi_server_bool:
                jjj = i % len(work_server_list)
                Server = work_server_list[jjj]
            if multi_dst_port_bool:
                ServerPort = get_vs_port(work_result_port_list,i + 1)
            else:
                ServerPort = Start_ServerPort
           
            j = threading.Thread(target=loop, args=(i + 1, Server,ServerPort, sourceip, http))
            j.setDaemon(True)
            j.start()
            if onebyone:
                j.join(10000)
                if speed_up_bool:
                    if sourceip_bool:
                        speed_num = multi_dict['adjust_speed']
                        n = speed_ip_num
                     
                    else:
                        speed_num = adjust_speed
                        n = 1
                    try:
                        
                        final_interval = get_new_interval(connection_interval, speed_num, n)
                        sleep(final_interval)
                    except Exception, e:
               
                        switch = False
                        break
                else:
           
                    sleep(connection_interval)
            else:
                if not session_unlimit_bool:
                    Sessions.append(j)
            if middle_bool:
                if speed_up_bool:
                    if sourceip_bool:
                        speed_num = multi_dict['adjust_speed']
                        n = speed_ip_num
                     
                    else:
                        speed_num = adjust_speed
                        n = 1
                    try:
                        
                        final_interval = get_new_interval(middle_interval, speed_num, n)
                        sleep(final_interval)
                    except Exception, e:
               
                        switch = False
                        break
                else:
                    sleep(middle_interval)

            i += 1    
            
        if not onebyone:
            for k in Sessions:
                if k.isAlive():
                    k.join(10000)
     
                
    except KeyboardInterrupt:  
        if not sourceip_bool:
            print "The program  is interrupted manully"
        
        close_action(0.5)

    except Exception, e:
#        sys.exit()
        
        print "%sMain thread meet problem as follows" % str_sip
        print e
        
        
    try:
        while switch:  
            all_status = []
            if not session_unlimit_bool:
                for e in Sessions:
                    all_status.append(e.isAlive())
            else:
                all_status.append(True)
            if not (True in set(all_status)):
               
                if  no_output_bool:
    
                    cost_time_func(sourceip)
                    switch = False
                    break
             
                my_print("%sTask Over" % str_sip)
                close_action(0)  
                cost_time_func(sourceip)
                break
#            else:      
#                if output_time:
#                    error_dict = deepcopy(httplib2.request_error_dic)   
#                sleep(1)

        
        if just_test_bool:
        
            if cost_time < 1:
                sleep(1.5 - cost_time)
    except KeyboardInterrupt:  
        if not sourceip_bool:
            print "The program  is interrupted manully"
        close_action(0.5)                

def multi_close(ip_list, eth_name, ttt1=0, ttt2=0):
    global switch
    switch = False
    read_switch = False
    if random_cache_bool and load_cache_file_bool:
        cache_file = file(cache_file_name, 'wb')
        sip_cache_dict = {}
        sip_cache_dict.update(mgr_random_cache_dict)
        if sip_cache_dict:
            sip_cache_dict['time'] = time()
            dump(sip_cache_dict, cache_file)
        cache_file.close()
            
   
#        get_key_thread.join(10000)
    if not no_output_bool:
     #   log_file.close()
        print "Every subprocess(Simulated IP) is over\n"

        if query_bool or h_a or header_cookie_bool:
            if 'failed' not in str(sum_multi_list_count):
                print '*' * 130
                query_out(sum_multi_list_count)
                
               # query_out(result_sum_chq)
               # print '*' * 130
        if url_full_bool:
            if 'failed' not in str(sum_multi_full_url):
                print '*' * 60 + 'FULL-URL-SUMMARY' + '*' * 60
                query_out(sum_multi_full_url)
              #  print '*' * 130
        if url_sum_bool:
            if 'failed' not in str(sum_multi_url_count):
                print '*' * 60 + 'URL-SUMMARY' + '*' * 60
                query_out(sum_multi_url_count)
              # print '*' * 130

        if full_nat_bool:
            if 'failed' not in str(sum_multi_fullnat_count):
                print '*' * 60 + 'LB_interface_IP' + '*' * 60
                print 
                query_out(sum_multi_fullnat_count)
              #  print '*' * 130
            if l2_src_ip_bool:
                if 'failed' not in str(sum_multi_l2_src_count):
                    print '*' * 60 + 'L2-SRC-IP-SUMMARY' + '*' * 45
                    query_out(sum_multi_l2_src_count)
            if l2_dst_ip_bool:
                if 'failed' not in str(sum_multi_l2_dst_count):
                    print '*' * 60 + 'L2-DEST-IP-SUMMARY' + '*' * 45
                    query_out(sum_multi_l2_dst_count)
            if l2_src_dst_ip_bool:
                if 'failed' not in str(sum_multi_l2_src_dst_count):
                    print '*' * 60 + 'L2-SRC-DEST-IP-PAIR-SUMMARY' + '*' * 45
                    query_out(sum_multi_l2_src_dst_count)
            if l2_session_bool:
                if 'failed' not in str(sum_multi_l2_session_count):
                    print '*' * 60 + 'L2-SESSION-SUMMARY' + '*' * 45
                    query_out(sum_multi_l2_session_count)

        if telnet_bool:
        
            if 'failed' not in str(sum_multi_cache_count):
                print '*' * 60 + 'TELNET-SUMMARY' + '*' * 60
                query_out(sum_multi_cache_count)
             #   print '*' * 130       
        if random_cache_bool:
            if 'failed' not in str(mgr_random_cache_list):
                print '*' * 60 + 'RANDOM-CACHE-SUMMARY' + '*' * 50
              
                query_out(mgr_random_cache_list)
             #   print '*' * 130           

             
        if weight_bool:
            if multi_dst_port_bool or multi_server_bool:
                if 'failed' not in str(sum_multi_dst_count):
                    print '*' * 60 + 'VIP-IP-PORT-RNAGE-SUMMARY' + '*' * 45
                  
                    query_out(sum_multi_dst_count)
                #    print '*' * 130  
                  #  print '*' * 130  
                
#            log_file = open('result_log.txt', 'r')
#            port_record = []
#            for line_1 in log_file:
#           
#                if separate_time in line_1:
#                    read_switch = True
#                if read_switch:
#                    if '#' not in line_1:
#                        print line_1
#                    else:
#                        port_record.append(line_1[1::])
            if 'failed' not in str(sum_multi_vs_sip_count):
                print '*' * 50 + 'SOURCE-IP-STATISTICS-SUMMARY' + '*' * 50
               
                query_out(sum_multi_vs_sip_count)
             #   print '*' * 130


            if 'failed' not in str(sum_multi_weight_count):
                print '*' * 60 + 'TOTAL-SUMMARY' + '*' * 60
           
                query_out(sum_multi_weight_count)
            #    print '*' * 130

#            if output_time:
#                if len(port_record) >= 1:
#                    print "\nThe address and port information as follows, whose cost-time greater than accuracy grade or sessions are reset\n"
#                    for i in port_record:
#                        print i       
#                log_file.close()
        print 'Total cost time is %s' % str(ttt2 - ttt1)
#        if not no_output_bool and output_time:
#            print "Every IP cost_time as follows"
#            for aaa_time in  dict(multi_dict):
#               
#                if 's_bool' not in aaa_time and 's_query_bool' not in aaa_time and 's_cookie_bool' not in aaa_time and 's_header_bool' not in aaa_time :
#                    print "%s ----------cost---------%s" % (aaa_time, multi_dict[aaa_time])          
                
                
        
        
        if no_output_bool:
            if ttt1 and ttt2:
                max_cost_list = []
                for aaa_time in  dict(multi_dict):
                    if 's_bool' not in aaa_time and 's_query_bool' not in aaa_time and 's_cookie_bool' not in aaa_time and 's_header_bool' not in aaa_time :
    
                        max_cost_list.append(multi_dict[aaa_time])
                if min(max_cost_list) >= 1:
                    print ttt2 - ttt1
                else:           
                    print ttt2 - ttt1 - (1 - min(max_cost_list))  
    if not no_bindip_bool:
        ip_process(ip_list, eth_name, add_bool=False)
      #  remove_ip(ip_list, eth_name,max_nic_num)

 #   sys.exit()
 
def mgr_init():
    import signal
    signal.signal(signal.SIGINT, signal.SIG_IGN)
   # print 'initialized manager' 
    
if sourceip_bool:
    if python27_bool:
        from multiprocessing.managers import SyncManager
    
    sys_tcp_limit()
    process_lock = Lock()
    if random_cache_bool:
        if python27_bool:
            mgr_random_cache = SyncManager()
            mgr_random_cache.start(mgr_init)
        else:
            mgr_random_cache = Manager()
        mgr_random_cache_list = mgr_random_cache.list()
        mgr_random_cache_dict = mgr_random_cache.dict()
        if load_cache_file_bool:
            mgr_random_cache_dict.update(cache_dict)



#    global multi_ip_account_list
    #import signal
    #signal.signal(signal.SIGINT, signal.SIG_IGN)
    if python27_bool:
        mgr = SyncManager()
        mgr.start(mgr_init)
    else:
        mgr = Manager()
    if local_warm_bool:
        
        multi_ip_account_list = mgr.list()
        
        if header_cookie_bool or cookie_bool:
            if python27_bool:
                mgr2 = SyncManager()
                mgr2.start(mgr_init) 
            else:           
                mgr2 = Manager()
            multi_cookie_account_list = mgr2.list()

        if h_a:
            if python27_bool:
                mgr3 = SyncManager()
                mgr3.start(mgr_init)
            else:
                mgr3 = Manager()
            multi_header_account_list = mgr3.list()
        if query_bool:
            if python27_bool:
                mgr4 = SyncManager()
                mgr4.start(mgr_init)
            else:
                mgr4 = Manager()
            multi_query_account_list = mgr4.list()
        if multi_dst_port_bool or multi_server_bool:
            if python27_bool:
                mgr11 = SyncManager()
                mgr11.start(mgr_init)
            else:
                mgr11 = Manager()
                multi_dst_account_list = mgr11.list()       
        if full_nat_bool:
            if python27_bool:
                mgr13 = SyncManager()
                mgr13.start(mgr_init)
            else:
                mgr13 = Manager()
            multi_fullnat_account_list = mgr13.list()    

            if python27_bool:
                mgr_warm_l2_src = SyncManager()
                mgr_warm_l2_src.start(mgr_init)
            else:
                mgr_warm_l2_src = Manager()
            multi_l2_src_account_list = mgr_warm_l2_src.list() 

            if python27_bool:
                mgr_warm_l2_dst = SyncManager()
                mgr_warm_l2_dst.start(mgr_init)
            else:
                mgr_warm_l2_dst = Manager()
            multi_l2_dst_account_list = mgr_warm_l2_dst.list()

            if python27_bool:
                mgr_warm_l2_src_dst = SyncManager()
                mgr_warm_l2_src_dst.start(mgr_init)
            else:
                mgr_warm_l2_src_dst = Manager()
            multi_l2_src_dst_account_list = mgr_warm_l2_src_dst.list()
             
    if header_cookie_bool or h_a or query_bool:
        if python27_bool:
            mgr5 = SyncManager()
            mgr5.start(mgr_init)
        else:
            mgr5 = Manager()
        
        sum_multi_list_count = mgr5.list()
        result_sum_chq = []
        
    if telnet_bool:
        if python27_bool:
            mgr6 = SyncManager()
            mgr6.start(mgr_init)
        else:
            mgr6 = Manager()
        sum_multi_cache_count = mgr6.list()
        sum_multi_cache = []
    if url_full_bool:
        if python27_bool:
            mgr7 = SyncManager()
            mgr7.start(mgr_init)
        else:
            mgr7 = Manager()
        sum_multi_full_url = mgr7.list()
        sum_multi_full = []

    if url_sum_bool:
        if python27_bool:
            mgr9 = SyncManager()
            mgr9.start(mgr_init)
        else:
            mgr9 = Manager()
        sum_multi_url_count = mgr9.list()
        sum_multi_url = []

    if full_nat_bool:
        if python27_bool:
            mgr12 = SyncManager()
            mgr12.start(mgr_init)
        else:
            mgr12 = Manager()
        sum_multi_fullnat_count = mgr12.list()  
        

    if weight_bool:
        if python27_bool:
            mgr8 = SyncManager()
            mgr8.start(mgr_init)
        else:
            mgr8 = Manager()
        sum_multi_weight_count = mgr8.list()
        
        if python27_bool:
            mgr_sip = SyncManager()
            mgr_sip.start(mgr_init)
        else:
            mgr_sip = Manager()
        sum_multi_vs_sip_count = mgr_sip.list()
        
    
        
        
        if multi_dst_port_bool or multi_server_bool:
            if python27_bool:
                mgr10 = SyncManager()
                mgr10.start(mgr_init)
            else:
                mgr10 = Manager()
            sum_multi_dst_count = mgr8.list()
                    
    if l2_src_ip_bool:
        if python27_bool:
            mgr_L2_src = SyncManager()
            mgr_L2_src.start(mgr_init)
        else:
            mgr_L2_src = Manager()
        sum_multi_l2_src_count = mgr_L2_src.list()
        
    if l2_dst_ip_bool:
        if python27_bool:
            mgr_L2_dst = SyncManager()
            mgr_L2_dst.start(mgr_init)
        else:
            mgr_L2_dst = Manager()
        sum_multi_l2_dst_count = mgr_L2_dst.list()
    if l2_src_dst_ip_bool:
        if python27_bool:
            mgr_L2_src_dst = SyncManager()
            mgr_L2_src_dst.start(mgr_init)
        else:
            mgr_L2_src_dst = Manager()
        sum_multi_l2_src_dst_count = mgr_L2_src_dst.list()
    if l2_session_bool:
        if python27_bool:
            mgr_L2_session = SyncManager()
            mgr_L2_session.start(mgr_init)
        else:
            mgr_L2_session = Manager()
        sum_multi_l2_session_count = mgr_L2_session.list()
        
    multi_dict = mgr.dict()
    multi_dict['s_bool'] = False
    multi_dict['s_dst_bool'] = False
    multi_dict['s_cookie_bool'] = False
    multi_dict['s_header_bool'] = False
    multi_dict['s_query_bool'] = False
    multi_dict['s_fullnat_bool'] = False
    multi_dict['l2_src_bool'] = False
    multi_dict['l2_dst_bool'] = False
    multi_dict['l2_src_dst_bool'] = False



    if speed_up_bool:
        multi_dict['adjust_speed'] = 0
    

    read_switch = False
    
    if ip_single_bool:
        ip_list = [ip_original]
#        if ipv6_bool:
#            ip_list = [ip_original.split('::')[1]]
#        else:
#            ip_list = [ip_original]
#            
    else:
        ip_list = []
        if not random_ipv4_bool and not random_ipv6_bool and not multi_single_bool:
            if len(tmp_ip_list) == 2:
                ori_ip_list = ipRange(tmp_ip_list[0], tmp_ip_list[1])
                if not ipv6_bool:
                    ip_list = ori_ip_list
                else:
                    for i in ori_ip_list:
                        ip_list.append(ipv6_prefix + "::" + i)
                
            else:
                print "There is format problem in inputed-ip-range,please double check"
                sys.exit()
        elif multi_single_bool:
         #   if not ipv6_bool:
            ip_list = tmp_ip_list
#            else:
#                for i in tmp_ip_list:
#                   ip_list.append(ipv6_prefix + "::" + i) 
            
        else:
     
            if random_ipv4_bool:
               
                ip_list = random_ipv4_list(random_ip_num)
    
                 
            if random_ipv6_bool:
                ip_list = random_ipv6_list(random_ip_num)
    speed_ip_num = len(ip_list)
    if not no_bindip_bool:
        ip_process(ip_list, eth_name, add_bool=True)
    
    
            
#        sleep(2)
    
    #pool = Pool(len(ip_list))
    
    try:   
#        for si in ip_list: 
        if (telnet_bool or speed_up_bool or random_cache_bool) and not local_warm_bool: 
            get_key_thread = threading.Thread(target=get_key_bool)
            get_key_thread.start()
        
        if local_warm_bool:

            get_key_thread = threading.Thread(target=get_key_bool)
            get_key_thread.start()
            warm_thread_main = threading.Thread(target=warm_loop, args=('', True))
            warm_time_revision()
            warm_thread_main.start()
        process_pool = []
        
        ttt1 = time()
        for index, si in enumerate(ip_list):
            try:
                if result_port_list:
                    if random_ip_port_bool:
                        sip_result_port_list = []
                        dst_port_index_list = range(num_dst_port)
                        shuffle(dst_port_index_list)
                        for i in dst_port_index_list:
                            sip_result_port_list.append(result_port_list[i])
                    else:
                        sip_result_port_list = result_port_list
                else:
                    sip_result_port_list = []
                if server_list:
                    if random_ip_port_bool:
                        sip_server_list = []
                        if len(server_list)==  num_dst_port:
        
                            dst_ip_index_list = dst_port_index_list
                        else:
         
                            dst_ip_index_list = range(len(server_list))
                            shuffle(dst_ip_index_list)
                        for i in dst_ip_index_list:
                            sip_server_list.append(server_list[i])
                    else:
                        sip_server_list = server_list
                else:
                    sip_server_list = []

                process_i = Process(target=my_main, args=(si,sip_result_port_list,sip_server_list,)) 
                if not asynchronous_bool:
                    process_pool.append(process_i)
      
                process_i.start()
       
                if asynchronous_bool:
                  #  print sum_multi_full_url
                   #         print 44444444444444 
                    process_i.join()
       
                    sleep(ip_interval)
                

            except KeyboardInterrupt:
                break
        if not asynchronous_bool:
            for i in process_pool:
            #    print '1111111%s' % sum_multi_url_count
                i.join()
            #    print '2222222%s' % sum_multi_url_count

        ttt2 = time()
        multi_close(ip_list, eth_name, ttt1, ttt2)

    except KeyboardInterrupt:
        print "the main process is closed via 'CTRL+C'"
        if not asynchronous_bool:
            for i in process_pool:
                i.join()
        ttt2 = time()
        multi_close(ip_list, eth_name, ttt1, ttt2)
    except Exception, e:
        print "errrrrrrrorrrrrrrrrrr\n%s" % e

else:
    my_main()
    



