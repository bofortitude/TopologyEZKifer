<html>
<body>
<?php

#$value = 'zjs-202';

$value = chop(exec('hostname'));
#$value2 = 'zjs-202-2';
#$value3 = 'zjs-202-3';
#setcookie("TestCookie1", $value1);
#setcookie("TestCookie2", $value2, time()+3600,'/');  /* expire in 1 hour */
#setcookie("TestCookie3", $value3, time()+3600);
#header("ttt_id: ".time());
#if (!isset($_COOKIE["TestCookie1"]) or (isset($_COOKIE["TestCookie1"]) and $_COOKIE["TestCookie1"]!= $value)){
#    setcookie("TestCookie1", $value);
#}
#if (!isset($_COOKIE["TestCookie2"]) or (isset($_COOKIE["TestCookie2"]) and $_COOKIE["TestCookie2"]!= $value)){
#    setcookie("TestCookie2", $value,time()+3600,'/');
#}
#if (!isset($_COOKIE["TestCookie3"]) or (isset($_COOKIE["TestCookie3"]) and $_COOKIE["TestCookie3"]!= $value)){
#    setcookie("TestCookie3", $value,time()+3600);
#}









function get_random_code ($length = 20)  
{  
    
    $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
    $result="";  
    $l=strlen($str);  
    for($i=0;$i < $length;$i++){  
        $num = rand(0, $l-1);
        $result .= $str[$num];  
    }  
    return $result;  
}  

$random_value = get_random_code(20);
header("random_cache_id: ".$random_value);



function GetIP(){
if(!empty($_SERVER["SERVER_ADDR"])){
  $cip = $_SERVER["SERVER_ADDR"];
}
else{
  $cip = "can't get ip address！";
}
return $cip;
}
echo GetIP();


 
if ($_GET["name"]) {
echo "Welcome      " . $_GET["name"];
}
header("fullnat_ip: ".$_SERVER['REMOTE_ADDR']);

if($_GET["Content-Type"]){
        if(preg_match("/\s/", $_GET["Content-Type"])){
                $types = preg_split ("/\s/", $_GET["Content-Type"]);
                header("Content-Type: ".$types[0].'+'.$types[1]);
        } else {
                header("Content-Type: ".$_GET["Content-Type"]);
        }
}





function getUrl(){
    $requestUri = '';
    if (isset($_SERVER['REQUEST_URI'])) {
        $requestUri = $_SERVER['REQUEST_URI'];
     }return $requestUri;
}     
$url = getUrl();


function getFullUrl(){
    $requestUri = '';
    if (isset($_SERVER['REQUEST_URI'])) { #$_SERVER["REQUEST_URI"] 只有 apache 才支持,
        $requestUri = $_SERVER['REQUEST_URI'];
    } else {
        if (isset($_SERVER['argv'])) {
            $requestUri = $_SERVER['PHP_SELF'] .'?'. $_SERVER['argv'][0];
        } else if(isset($_SERVER['QUERY_STRING'])) {
            $requestUri = $_SERVER['PHP_SELF'] .'?'. $_SERVER['QUERY_STRING'];
        }
    }
//    echo $requestUri.'<br />';
    $scheme = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : "";
    $protocol = strstr(strtolower($_SERVER["SERVER_PROTOCOL"]), "/",true) . $scheme;
    $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]);
    # 获取的完整url
    $_fullUrl = $protocol . "://" . $_SERVER['SERVER_NAME'] . $port . $requestUri;
    return $_fullUrl;
}



$full_url = getFullUrl();



#echo $url;

header("fullnat_port: ".$_SERVER['REMOTE_PORT']);
header("rewrite_host: ".$_SERVER['HTTP_HOST']);
header("rewrite_referer: ".$_SERVER['HTTP_REFERER']);
header("rewrite_min_url: ".$url);
header("rewrite_url: ".$full_url);
header("x-forwarded-for: ".$_SERVER['HTTP_X_FORWARDED_FOR']);

#header("zjs_info: "."r_url=".$url." "."client_address=".$_SERVER["REMOTE_ADDR"]." "."client_port=".$_SERVER["REMOTE_PORT"]." "."host=".$_SERVER["HTTP_HOST"]." "."referer=".$_SERVER["HTTP_REFERER"]);

?>

<h1>hello, zjs-server2--10.0.8.202,it is RS1</h1>
<br>
<p><a href="sub-link.html">sub-link</a></p>
<br>
<p><a href="sub-link2.html">sub-link2</a></p>

<br>
<p><a href="sub-link3.html">sub-link3</a></p>

<img src="1.png" width="104" height="142" />


</body>
</html>
