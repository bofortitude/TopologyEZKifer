#!/usr/bin/env python
from optparse import OptionParser
from ftplib import FTP
from subprocess import Popen,PIPE
from re import search
from sys import exit,stdout,argv
from pexpect import spawn,EOF
from os import chdir,getcwd

usage = '''

jiasheng_update program_name  ftpserver:port/direction -u anonymous:pass@aa

For example:
jiasheng_update http_test  -s 10.0.0.11:21/jiasheng_tool -u anonymous:pass@aa

The script will ftp to 10.0.0.11 with anonymous:pass@aa, CD to /jiasheng/http_test, then downloading the latest version according to updated_program name


'''

parser = OptionParser(usage=usage,version="%prog 1.0")

parser.add_option("-u", "--username", dest="user", help='''Sepefic the username and password. 
                         Usage: -u 'ftp_user:ftp_pass'. 
                         If this paratemeter is not set,
                         The program will login with anonymous''')
parser.add_option("-s", "--server", dest="server", help='''Sepefic update_server and path. 
                         Usage: -u '1.1.1.1:21/directory/'. 
                         If this paratemeter is not set,
                         default update server will be 10.0.0.11/jiasheng_tool''')

options, args = parser.parse_args()
if len(argv) < 2:
    parser.print_help()
   # my_print( "Please add parameter (-h or --help) for help"
    exit()
program_name=args[0]
#ServerPort=args[1]
try:
    if '-s' in argv:
        server_path = options.server
    else:
        server_path = '10.0.0.11:21/jiasheng_tool'
    if '/' in server_path:
        server,path_1 = server_path.split('/')
        path = path_1 + '/' + program_name
        if ':' in server:
            server_ip,server_port = server.split(':')
        else:
            server_ip, server_port = server, 21
    else:
        path = program_name
        if ':' in server_path:
            server_ip,server_port = server.split(':')
        else:
            server_ip, server_port = server, 21  
         
        
    
    if '-u' in argv:
        username,password = options.user.split(':')
    else:
        username,password = 'anonymous','aa@ff'
        
    def my_print(str):
        print '%s %s \n' % ('UPDATE_DEBUG::',str)
        
    
    current_version_all,error = Popen('ls /bin/%s -la' % program_name,shell=True,stdout=PIPE).communicate()
    cur_v = ''
    down_dir = ''
    if '->' in current_version_all:
        current_version = current_version_all.split('->')[1].strip()
        if search('%s_(.+).py' % program_name,current_version) is not None:
            
            cur_v = search('%s_(.+).py' % program_name,current_version).group(1)
            down_dir = search('(.*)%s' % program_name,current_version).group(1)
        else:
            my_print( 'The version info from "ls -la" error, still go on to install.')
        
    else:
        my_print( 'You has not install %s, will start to install' % program_name)
        
        
    #myserver = '10.0.0.11'
    #ServerPort = 21
    
    if down_dir:
        chdir(down_dir)


    mytimeout = 5
    f = FTP(timeout = mytimeout)
    #f.set_debuglevel(1)
    def my_close():
        f.close()
        exit()
        
        
    try:
        f.connect(server_ip,server_port)
    except Exception, e:
        my_print( "Couldn't connect to %s:%s,due to %s" % (server_ip,server_port,e))
        exit()
        
    else:
        my_print( "Connect to %s:%s successfully" % (server_ip,server_port))
    try:
        f.login(username,password)
    except Exception, e:
        my_print( "Couldn't login to server with %s:%s,due to %s" % (username,password,e))
        my_close()
    else:
        my_print( "Login to server successfully") 
        
    
    try:
        
        f.cwd(path)
    except Exception, e:
        my_print( "Cound't enter into the %s" % path)
        my_close()
        
    else:
        my_print( "CD to %s successfully" % path)
    
    file_list = f.nlst()
    if file_list:
        for i in file_list:
            if 'install' in i:
                install_file = i 
            my_print( 'Find the %s in server' % i)
    else:
        my_print( 'There are not any file in server')
        my_close()
    
    
    remote_v = search('\d*\.\d',install_file).group()
    my_print( 'The program version in ftp server is %s' % remote_v)
    my_print( 'The program version in local is %s' % cur_v)
    if remote_v > cur_v:
        for i in file_list:
            my_print( 'Start to donwload file %s' % i)
            try:
                f.retrbinary('RETR %s' % i, file(i,'wb').write)
            except Exception, e:
                my_print( "Couldn't download %s ,due to %s" % (i,e))
                my_close()
                
            else: 
                my_print( 'donwload file %s over' % i)
    
    else:
        my_print( 'you have latest version')
        my_close()
    
    cmd = 'python %s' % install_file
    #cmd = 'ping 10.0.0.1 -c 5'
    cmd_process = spawn(cmd,logfile=stdout)
    cmd_process.expect(EOF,timeout=None)
        
    my_close()
except KeyboardInterrupt:
    print "the update process is closed by manully"